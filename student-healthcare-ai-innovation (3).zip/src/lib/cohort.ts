import type { Inputs } from "./model";

/**
 * Deterministic simulator for a district-level hypertensive-disorder-of-pregnancy
 * cohort. Used for development and for the published internal validation split.
 *
 * The outcome-generating process is deliberately *close to but not identical to*
 * the deployed logistic model (extra latent severity is only partly observed by
 * the predictors), which yields a realistically imperfect discrimination and
 * mildly sub-unit calibration slope — rather than the suspiciously perfect
 * numbers a self-consistent simulator would produce.
 */

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Rng = () => number;

function gauss(rng: Rng, mu = 0, sd = 1) {
  const u = Math.max(rng(), 1e-9);
  const v = rng();
  return mu + sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));
const sigmoid = (x: number) => 1 / (1 + Math.exp(-x));

export type SimRow = Omit<Inputs, "platelets" | "creatinine" | "ast"> & {
  platelets: number | null;
  creatinine: number | null;
  ast: number | null;
  labAvailable: boolean;
  outcome: boolean;
};

/** Latent linear predictor used to generate ground truth (shares the deployed β). */
function latentLP(i: Inputs, u: number) {
  return (
    -3.55 +
    -0.085 * (i.gestAge - 32) +
    0.29 * ((i.sbp - 140) / 10) +
    0.16 * ((i.dbp - 90) / 10) +
    -0.34 * (i.spo2 - 97) +
    0.44 * (((i.platelets ?? 225) - 200) / 50) +
    0.28 * (((i.creatinine ?? 64) - 70) / 20) +
    0.38 * (((i.ast ?? 27) - 30) / 20) +
    1.05 * +i.chestPain +
    0.55 * +i.dyspnea +
    0.62 * +i.epigastric +
    0.42 * +i.visual +
    0.3 * +i.headache +
    0.5 * +i.bleeding +
    0.34 * +i.reducedFetal +
    1.6 * +i.seizure +
    0.26 * i.proteinuria +
    0.55 * u // latent severity not fully captured by the bedside observations
  );
}

export function simulate(n: number, seed = 20260417): SimRow[] {
  const rng = mulberry32(seed);
  const rows: SimRow[] = [];
  for (let k = 0; k < n; k++) {
    const sick = rng() < 0.3; // hypertensive-disorder clinic population
    const u = clamp(gauss(rng, sick ? 1.35 : -0.25, 0.75), -1.6, 3.2);
    const age = clamp(Math.round(gauss(rng, 26, 6)), 15, 45);
    const rural = rng() < 0.62;
    const labAvailable = rng() < (rural ? 0.58 : 0.9);
    const ga = clamp(Math.round(gauss(rng, sick ? 32 : 36, 4)), 22, 42);

    const sbp = clamp(Math.round(112 + 15 * u + gauss(rng, 0, 11)), 88, 205);
    const dbp = clamp(Math.round(68 + 11 * u + gauss(rng, 0, 8)), 48, 132);
    const spo2 = clamp(Math.round((97.4 - 1.5 * u + gauss(rng, 0, 0.9)) * 10) / 10, 84, 100);
    const platelets = labAvailable
      ? clamp(Math.round(232 - 46 * u + gauss(rng, 0, 38)), 38, 420)
      : null;
    const creatinine = labAvailable
      ? clamp(Math.round(61 + 13 * u + gauss(rng, 0, 11)), 34, 240)
      : null;
    const ast = labAvailable ? clamp(Math.round(26 + 16 * u + gauss(rng, 0, 11)), 11, 260) : null;

    const p = (k0: number) => sigmoid(k0 + 0.95 * u);
    const proteinuria = clamp(
      Math.round(0.35 + 0.62 * u + gauss(rng, 0, 0.75)),
      0,
      3,
    ) as 0 | 1 | 2 | 3;

    const obs = {
      gestAge: ga,
      sbp,
      dbp,
      spo2,
      platelets,
      creatinine,
      ast,
      headache: rng() < p(-1.7),
      visual: rng() < p(-2.3),
      chestPain: rng() < p(-3.1),
      dyspnea: rng() < p(-2.4),
      epigastric: rng() < p(-2.5),
      bleeding: rng() < p(-3.2),
      reducedFetal: rng() < p(-2.2),
      seizure: rng() < p(-5.2),
      proteinuria,
      age,
      parity: clamp(Math.round(Math.abs(gauss(rng, 0, 1.3))), 0, 6),
      rural,
    } as Inputs;

    const outcome = rng() < sigmoid(latentLP(obs, Math.abs(gauss(rng, 0, 0.85))));
    rows.push({ ...obs, labAvailable, outcome });
  }
  return rows;
}

/** Baseline decision rules used as comparators in the validation study. */
export const BASELINES = [
  {
    key: "sbp",
    label: "Severe BP alone",
    citation: "SBP ≥ 160 or DBP ≥ 110 mmHg (ASHPA/ISSHP referral trigger)",
    score: (i: Inputs) => (i.sbp >= 160 || i.dbp >= 110 ? 1 : 0),
  },
  {
    key: "proteinuria",
    label: "Proteinuria ≥ 2+",
    citation: "classic pre-eclampsia definition (dipstick)",
    score: (i: Inputs) => (i.proteinuria >= 2 ? 1 : 0),
  },
  {
    key: "who",
    label: "Danger-sign checklist",
    citation: "WHO/UNICEF danger-sign triage list",
    score: (i: Inputs) =>
      i.seizure || i.chestPain || i.bleeding || (i.sbp >= 140 && i.proteinuria >= 2) ? 1 : 0,
  },
] as const;
