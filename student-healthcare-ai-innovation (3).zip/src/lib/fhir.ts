import type { Finding, Guardrail, Modality } from "./codes";
import type { Coded } from "./codes";
import { MODEL_REGISTRY } from "./codes";

/** HL7 FHIR v4.0.1 bundle builder (DiagnosticReport + Observations + Condition). */
export function buildFhirBundle(args: {
  runId: string;
  sessionId: string;
  patientRef: string;
  modality: Modality;
  performedAt: string;
  findings: Finding[];
  guardrails: Guardrail[];
  device: string;
}) {
  const subject = { reference: `Patient/${args.patientRef}`, display: "pseudonymous booklet code" };
  const obsIds = args.findings.slice(0, 5).map((f, i) => `obs-${args.runId.toLowerCase()}-${i}`);
  const model = MODEL_REGISTRY[args.modality];

  const entries: unknown[] = [
    {
      fullUrl: `urn:uuid:pat-${args.patientRef}`,
      resource: {
        resourceType: "Patient",
        id: `pat-${args.patientRef}`,
        identifier: [{ system: "urn:oid:1.3.6.1.4.1.pulsenova.booklet", value: args.patientRef }],
        gender: "unknown",
        // deliberately no name, birthDate, address or telecom
      },
    },
    {
      fullUrl: `urn:uuid:dr-${args.runId}`,
      resource: {
        resourceType: "DiagnosticReport",
        id: `dr-${args.runId}`,
        status: "preliminary",
        category: [
          {
            coding: [{ system: "http://terminology.hl7.org/CodeSystem/v2-0074", code: "IMG", display: "Imaging" }],
          },
        ],
        code: {
          coding: [
            {
              system: "http://loinc.org",
              code: args.modality === "xray" ? "36642-7" : args.modality === "derm" ? "72133-1" : "34117-2",
              display: `${model.name} automated interpretation`,
            },
          ],
          text: model.name,
        },
        subject,
        effectiveDateTime: args.performedAt,
        issued: args.performedAt,
        performer: [{ display: `${model.name} ${model.version} (software)` }],
        conclusion:
          args.findings[0] !== undefined
            ? `${args.findings[0].label} — ${Math.round(args.findings[0].p * 100)}% (95% CI ${Math.round(
                args.findings[0].ci[0] * 100,
              )}–${Math.round(args.findings[0].ci[1] * 100)}%). Automated decision support; requires clinician confirmation.`
            : "No findings recorded.",
        result: obsIds.map((id) => ({ reference: `Observation/${id}` })),
      },
    },
  ];

  args.findings.slice(0, 5).forEach((f, i) => {
    entries.push({
      fullUrl: `urn:uuid:obs-${args.runId}-${i}`,
      resource: {
        resourceType: "Observation",
        id: obsIds[i],
        status: "preliminary",
        category: [
          {
            coding: [
              { system: "http://terminology.hl7.org/CodeSystem/observation-category", code: "laboratory" },
            ],
          },
        ],
        code: {
          coding: f.codes.map((c: Coded) => ({
            system:
              c.system === "ICD-10-CM"
                ? "http://hl7.org/fhir/sid/icd-10-cm"
                : "http://snomed.info/sct",
            code: c.code,
                display: c.display,
          })),
          text: f.label,
        },
        subject,
        effectiveDateTime: args.performedAt,
        valueQuantity: {
          value: Number((f.p * 100).toFixed(1)),
          unit: "% probability",
          system: "http://unitsofmeasure.org",
          code: "%",
        },
        interpretation: [
          {
            coding: [
              {
                system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
                code: f.urgency === "urgent" ? "AA" : f.urgency === "soon" ? "H" : "N",
                display: f.urgency === "urgent" ? "Critical" : f.urgency === "soon" ? "High" : "Normal",
              },
            ],
          },
        ],
        referenceRange: [
          {
            low: { value: Math.round(f.ci[0] * 100), unit: "%" },
            high: { value: Math.round(f.ci[1] * 100), unit: "%" },
            text: "95% model confidence interval",
          },
        ],
      },
    });
  });

  args.guardrails.slice(0, 4).forEach((g, i) => {
    entries.push({
      fullUrl: `urn:uuid:flag-${args.runId}-${i}`,
      resource: {
        resourceType: "Flag",
        id: `flag-${args.runId}-${i}`,
        status: "active",
        category: [
          {
            coding: [{ system: "http://terminology.hl7.org/CodeSystem/flag-category", code: "safety" }],
          },
        ],
        code: { text: `${g.message} — ${g.action}` },
        subject,
      },
    });
  });

  return {
    resourceType: "Bundle",
    id: `bundle-${args.runId.toLowerCase()}`,
    meta: { lastUpdated: args.performedAt },
    type: "collection",
    timestamp: args.performedAt,
    entry: entries,
  };
}
