export type Labeled = { score: number; y: boolean; strata?: Record<string, string | number | boolean> };

/** Rank-based (Mann–Whitney) AUC with tie handling. */
export function auc(rows: { score: number; y: boolean }[]): number {
  const n = rows.length;
  const nPos = rows.filter((r) => r.y).length;
  const nNeg = n - nPos;
  if (nPos === 0 || nNeg === 0) return NaN;
  const sorted = [...rows].sort((a, b) => a.score - b.score);
  let i = 0;
  let rankSum = 0;
  while (i < n) {
    let j = i;
    while (j + 1 < n && sorted[j + 1].score === sorted[i].score) j++;
    const avgRank = (i + j) / 2 + 1;
    for (let k = i; k <= j; k++) if (sorted[k].y) rankSum += avgRank;
    i = j + 1;
  }
  return (rankSum - (nPos * (nPos + 1)) / 2) / (nPos * nNeg);
}

export function rocPoints(rows: { score: number; y: boolean }[], grid = 120) {
  const pos = rows.filter((r) => r.y).length;
  const neg = rows.length - pos;
  const sorted = [...rows].sort((a, b) => b.score - a.score);
  const pts: { fpr: number; tpr: number; threshold: number }[] = [{ fpr: 0, tpr: 0, threshold: Infinity }];
  let tp = 0;
  let fp = 0;
  let prev = Infinity;
  for (const r of sorted) {
    if (r.y) tp++;
    else fp++;
    prev = r.score;
    pts.push({ fpr: fp / neg, tpr: tp / pos, threshold: prev });
  }
  if (grid && pts.length > grid) {
    const out: typeof pts = [];
    const step = (pts.length - 1) / (grid - 1);
    for (let k = 0; k < grid; k++) out.push(pts[Math.round(k * step)]);
    return out;
  }
  return pts;
}

export function confusion(rows: { score: number; y: boolean }[], t: number) {
  let tp = 0;
  let fp = 0;
  let tn = 0;
  let fn = 0;
  for (const r of rows) {
    const pred = r.score >= t;
    if (pred && r.y) tp++;
    else if (pred) fp++;
    else if (r.y) fn++;
    else tn++;
  }
  return {
    tp,
    fp,
    tn,
    fn,
    sens: tp + fn ? tp / (tp + fn) : NaN,
    spec: tn + fp ? tn / (tn + fp) : NaN,
    ppv: tp + fp ? tp / (tp + fp) : NaN,
    npv: tn + fn ? tn / (tn + fn) : NaN,
  };
}

/** Threshold on `rows` whose sensitivity is closest to (but not below) target. */
export function thresholdAtSensitivity(rows: { score: number; y: boolean }[], target = 0.95) {
  const sorted = [...rows].sort((a, b) => b.score - a.score);
  const pos = rows.filter((r) => r.y).length;
  let tp = 0;
  for (const r of sorted) {
    tp += r.y ? 1 : 0;
    if (tp / pos >= target) return r.score;
  }
  return sorted[sorted.length - 1]?.score ?? 0;
}

export function calibrationBins(rows: { score: number; y: boolean }[], bins = 10) {
  const out: { lo: number; hi: number; pred: number; obs: number; n: number }[] = [];
  for (let b = 0; b < bins; b++) {
    const lo = b / bins;
    const hi = (b + 1) / bins;
    const set = rows.filter((r) => r.score >= lo && (b === bins - 1 ? r.score <= hi : r.score < hi));
    if (!set.length) continue;
    out.push({
      lo,
      hi,
      pred: set.reduce((s, r) => s + r.score, 0) / set.length,
      obs: set.filter((r) => r.y).length / set.length,
      n: set.length,
    });
  }
  return out;
}

/** Logistic calibration slope + intercept-in-the-large by Newton–Raphson on logit(pred). */
export function calibrationFit(rows: { score: number; y: boolean }[]) {
  let a = 0;
  let b = 1;
  for (let it = 0; it < 60; it++) {
    let g0 = 0;
    let g1 = 0;
    let h00 = 0;
    let h01 = 0;
    let h11 = 0;
    for (const r of rows) {
      const x = Math.log(Math.min(0.999, Math.max(0.001, r.score)) / (1 - Math.min(0.999, Math.max(0.001, r.score))));
      const p = 1 / (1 + Math.exp(-(a + b * x)));
      const w = Math.max(1e-6, p * (1 - p));
      const e = (r.y ? 1 : 0) - p;
      g0 += e;
      g1 += e * x;
      h00 += w;
      h01 += w * x;
      h11 += w * x * x;
    }
    const det = h00 * h11 - h01 * h01;
    if (Math.abs(det) < 1e-9) break;
    const da = (h11 * g0 - h01 * g1) / det;
    const db = (h00 * g1 - h01 * g0) / det;
    a += da;
    b += db;
    if (Math.abs(da) + Math.abs(db) < 1e-8) break;
  }
  return { intercept: a, slope: b };
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Percentile bootstrap CI for a statistic. */
export function bootstrapCI(
  rows: { score: number; y: boolean }[],
  stat: (r: { score: number; y: boolean }[]) => number,
  reps = 400,
  seed = 7,
): [number, number] {
  const rng = mulberry32(seed);
  const vals: number[] = [];
  const n = rows.length;
  for (let k = 0; k < reps; k++) {
    const sample: { score: number; y: boolean }[] = [];
    for (let j = 0; j < n; j++) sample.push(rows[(rng() * n) | 0]);
    const v = stat(sample);
    if (!Number.isNaN(v)) vals.push(v);
  }
  vals.sort((x, y) => x - y);
  return [vals[Math.floor(vals.length * 0.025)] ?? NaN, vals[Math.floor(vals.length * 0.975)] ?? NaN];
}
