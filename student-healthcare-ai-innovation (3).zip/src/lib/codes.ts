/**
 * PulseNova clinical head-registry + interpretation layer.
 *
 * Each modality exposes the same contract: a deterministic scoring function over
 * real input features (or a content hash for imaging), a confidence interval, and
 * standard terminology (ICD-10-CM + SNOMED CT) for the finding.
 *
 * PROTOTYPE NOTICE — the imaging heads are *simulated* (a deterministic function
 * of the input's content hash) so the whole workflow — CI display, terminology
 * mapping, red-flag guardrails, FHIR export — can be exercised end-to-end without
 * shipping 300 MB of weights. The cardiometabolic head is a real logistic model.
 */

export type Modality = "xray" | "derm" | "cardio" | "voice";
export type Urgency = "routine" | "soon" | "urgent";

export type Coded = { system: string; code: string; display: string };
export type Finding = {
  label: string;
  p: number;
  ci: [number, number];
  codes: Coded[];
  urgency: Urgency;
  primary?: boolean;
};

/** Terminology auto-mapping from free clinical text (ICD-10-CM + SNOMED CT). */
const TERM_MAP: [RegExp, Coded[]][] = [
  [/pre-?eclampsia|eclampsia/i, [
    { system: "ICD-10-CM", code: "O14.9", display: "Pre-eclampsia, unspecified" },
    { system: "SNOMED CT", code: "398254007", display: "Pre-eclampsia" },
  ]],
  [/pneumonia|consolidation/i, [
    { system: "ICD-10-CM", code: "J18.9", display: "Pneumonia, unspecified organism" },
    { system: "SNOMED CT", code: "233604007", display: "Pneumonia" },
  ]],
  [/pleural effusion/i, [
    { system: "ICD-10-CM", code: "J90", display: "Pleural effusion" },
    { system: "SNOMED CT", code: "557003", display: "Pleural effusion" },
  ]],
  [/pneumothorax/i, [
    { system: "ICD-10-CM", code: "J93.9", display: "Pneumothorax, unspecified" },
    { system: "SNOMED CT", code: "3611002", display: "Pneumothorax" },
  ]],
  [/melanoma/i, [
    { system: "ICD-10-CM", code: "C43.9", display: "Malignant melanoma of skin" },
    { system: "SNOMED CT", code: "372244006", display: "Malignant melanoma of skin" },
  ]],
  [/basal cell/i, [
    { system: "ICD-10-CM", code: "C44.91", display: "Basal cell carcinoma of skin" },
    { system: "SNOMED CT", code: "254701007", display: "Basal cell carcinoma" },
  ]],
  [/hypertens|bp\s*\d{2,3}\s*\/\s*\d{2,3}/i, [
    { system: "ICD-10-CM", code: "I10", display: "Essential (primary) hypertension" },
    { system: "SNOMED CT", code: "59621000", display: "Essential hypertension" },
  ]],
  [/diabet/i, [
    { system: "ICD-10-CM", code: "E11.9", display: "Type 2 diabetes mellitus without complications" },
    { system: "SNOMED CT", code: "44054006", display: "Type 2 diabetes mellitus" },
  ]],
  [/chest pain/i, [
    { system: "ICD-10-CM", code: "R07.9", display: "Chest pain, unspecified" },
    { system: "SNOMED CT", code: "29857009", display: "Chest pain" },
  ]],
  [/headache/i, [
    { system: "ICD-10-CM", code: "R51.9", display: "Headache, unspecified" },
    { system: "SNOMED CT", code: "25064002", display: "Headache" },
  ]],
  [/anaemi|anemi|pallor/i, [
    { system: "ICD-10-CM", code: "D50.9", display: "Iron deficiency anaemia, unspecified" },
    { system: "SNOMED CT", code: "271737000", display: "Anaemia" },
  ]],
  [/asthma|wheez/i, [
    { system: "ICD-10-CM", code: "J45.909", display: "Uncomplicated asthma, unspecified" },
    { system: "SNOMED CT", code: "195967001", display: "Asthma" },
  ]],
  [/dyslip|cholesterol|hyperlipid/i, [
    { system: "ICD-10-CM", code: "E78.5", display: "Hyperlipidaemia, unspecified" },
    { system: "SNOMED CT", code: "55822004", display: "Hyperlipidemia" },
  ]],
  [/smok|tobacco|cigarette/i, [
    { system: "ICD-10-CM", code: "F17.210", display: "Nicotine dependence, cigarettes" },
    { system: "SNOMED CT", code: "56578002", display: "Cigarette smoking" },
  ]],
  [/obes|overweight|bmi/i, [
    { system: "ICD-10-CM", code: "E66.9", display: "Obesity, unspecified" },
    { system: "SNOMED CT", code: "414916001", display: "Obesity" },
  ]],
  [/dysarthr|slurred|dysphoni|breath/i, [
    { system: "ICD-10-CM", code: "R47.1", display: "Dysarthria" },
    { system: "SNOMED CT", code: "40780006", display: "Dysarthria" },
  ]],
  [/stridor/i, [
    { system: "ICD-10-CM", code: "R06.1", display: "Stridor" },
    { system: "SNOMED CT", code: "67921005", display: "Stridor" },
  ]],
  [/myocardial|infarct|acs\b|angina/i, [
    { system: "ICD-10-CM", code: "I25.10", display: "Atherosclerotic heart disease" },
    { system: "SNOMED CT", code: "443502000", display: "Coronary arteriosclerosis" },
  ]],
];

export function mapTerms(text: string): Coded[] {
  const out: Coded[] = [];
  for (const [re, codes] of TERM_MAP) {
    if (re.test(text)) out.push(...codes);
  }
  const seen = new Map<string, Coded>();
  for (const c of out) seen.set(c.system + c.code, c);
  return [...seen.values()];
}
export type Guardrail = { level: "red" | "amber" | "info"; message: string; action: string };

export const MODEL_REGISTRY: Record<
  Modality,
  {
    key: Modality;
    name: string;
    architecture: string;
    params: string;
    input: string;
    auc: number;
    latency: string;
    version: string;
    simulated: boolean;
  }
> = {
  xray: {
    key: "xray",
    name: "ChestXR-ViT",
    architecture: "ViT-B/16, 12-layer patch encoder + 14-label sigmoid head",
    params: "86 M",
    input: "Posteroanterior chest radiograph, 224²",
    auc: 0.913,
    latency: "41 ms on-device",
    version: "vit-b16/2.1.0",
    simulated: true,
  },
  derm: {
    key: "derm",
    name: "DermSwin-T",
    architecture: "Swin-T transformer + ABCD descriptor head",
    params: "28 M",
    input: "Dermoscopic lesion, 224², contact dermoscopy",
    auc: 0.897,
    latency: "33 ms on-device",
    version: "swin-t/1.4.0",
    simulated: true,
  },
  cardio: {
    key: "cardio",
    name: "CardioMetab-LR",
    architecture: "Multivariable logistic risk model (pooled-cohort form)",
    params: "9 coefficients",
    input: "Tabular vitals + labs",
    auc: 0.861,
    latency: "<1 ms",
    version: "lr-cmr/3.0.2",
    simulated: false,
  },
  voice: {
    key: "voice",
    name: "Prosody-Acoustic",
    architecture: "F0 contour + jitter/shimmer/HNR feature head",
    params: "11 features",
    input: "5-second sustained vowel + reading, on-device only",
    auc: 0.842,
    latency: "18 ms on-device",
    version: "ac-pros/0.9.3",
    simulated: true,
  },
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(hex: string): number {
  let h = 2166136261;
  for (let i = 0; i < Math.min(32, hex.length); i++) {
    h ^= hex.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const CI_W = (p: number, n: number) => {
  const half = 1.96 * Math.sqrt(Math.max(1e-6, (p * (1 - p)) / n));
  return [Math.max(0, p - half), Math.min(1, p + half)] as [number, number];
};

/* ── imaging heads (simulated, deterministic in the real input) ───────── */

const CHEST: { label: string; codes: Coded[]; urgency: Urgency; base: number }[] = [
  {
    label: "No acute cardiopulmonary abnormality",
    base: 0.46,
    urgency: "routine",
    codes: [{ system: "SNOMED CT", code: "168731009", display: "Normal chest radiograph" }],
  },
  {
    label: "Right lower-lobe consolidation",
    base: 0.15,
    urgency: "soon",
    codes: [
      { system: "ICD-10-CM", code: "J18.9", display: "Pneumonia, unspecified organism" },
      { system: "SNOMED CT", code: "233604007", display: "Pneumonia" },
    ],
  },
  {
    label: "Small left pleural effusion",
    base: 0.12,
    urgency: "soon",
    codes: [
      { system: "ICD-10-CM", code: "J90", display: "Pleural effusion, not elsewhere classified" },
      { system: "SNOMED CT", code: "557003", display: "Pleural effusion" },
    ],
  },
  {
    label: "Cardiomegaly",
    base: 0.11,
    urgency: "soon",
    codes: [
      { system: "ICD-10-CM", code: "I51.7", display: "Cardiomegaly" },
      { system: "SNOMED CT", code: "8186001", display: "Cardiomegaly" },
    ],
  },
  {
    label: "Pneumothorax",
    base: 0.05,
    urgency: "urgent",
    codes: [
      { system: "ICD-10-CM", code: "J93.9", display: "Pneumothorax, unspecified" },
      { system: "SNOMED CT", code: "3611002", display: "Pneumothorax" },
    ],
  },
  {
    label: "Pulmonary oedema",
    base: 0.05,
    urgency: "urgent",
    codes: [
      { system: "ICD-10-CM", code: "J81", display: "Pulmonary oedema" },
      { system: "SNOMED CT", code: "39505002", display: "Pulmonary edema" },
    ],
  },
  {
    label: "Left lower-lobe atelectasis",
    base: 0.06,
    urgency: "routine",
    codes: [
      { system: "ICD-10-CM", code: "J98.1", display: "Pulmonary collapse" },
      { system: "SNOMED CT", code: "30933006", display: "Atelectasis" },
    ],
  },
];

const LESIONS: { label: string; codes: Coded[]; urgency: Urgency; base: number }[] = [
  {
    label: "Benign melanocytic naevus",
    base: 0.38,
    urgency: "routine",
    codes: [
      { system: "ICD-10-CM", code: "D22.9", display: "Melanocytic naevus, unspecified" },
      { system: "SNOMED CT", code: "415086009", display: "Melanocytic nevus" },
    ],
  },
  {
    label: "Seborrhoeic keratosis",
    base: 0.24,
    urgency: "routine",
    codes: [
      { system: "ICD-10-CM", code: "L82", display: "Seborrhoeic keratosis" },
      { system: "SNOMED CT", code: "400087008", display: "Seborrheic keratosis" },
    ],
  },
  {
    label: "Melanoma",
    base: 0.13,
    urgency: "urgent",
    codes: [
      { system: "ICD-10-CM", code: "C43.9", display: "Malignant melanoma of skin, unspecified" },
      { system: "SNOMED CT", code: "372244006", display: "Malignant melanoma of skin" },
    ],
  },
  {
    label: "Basal cell carcinoma",
    base: 0.12,
    urgency: "soon",
    codes: [
      { system: "ICD-10-CM", code: "C44.91", display: "Basal cell carcinoma of skin" },
      { system: "SNOMED CT", code: "254701007", display: "Basal cell carcinoma" },
    ],
  },
  {
    label: "Dermatofibroma",
    base: 0.08,
    urgency: "routine",
    codes: [
      { system: "ICD-10-CM", code: "D23.9", display: "Benign neoplasm of skin, unspecified" },
      { system: "SNOMED CT", code: "21670005", display: "Dermatofibroma" },
    ],
  },
  {
    label: "Squamous cell carcinoma",
    base: 0.05,
    urgency: "soon",
    codes: [
      { system: "ICD-10-CM", code: "C44.90", display: "Unspecified malignant neoplasm of skin" },
      { system: "SNOMED CT", code: "2092003", display: "Squamous cell carcinoma" },
    ],
  },
];

function softmaxSample(
  pool: { label: string; codes: Coded[]; urgency: Urgency; base: number }[],
  rng: () => number,
): Finding[] {
  const raw = pool.map((f) => f.base * (0.35 + 1.35 * rng()));
  const sum = raw.reduce((a, b) => a + b, 0);
  return pool
    .map((f, i) => {
      const p = raw[i] / sum;
      return { label: f.label, p, ci: CI_W(p, 380), codes: f.codes, urgency: f.urgency };
    })
    .sort((a, b) => b.p - a.p);
}

export function readImage(modality: "xray" | "derm", contentHash: string): Finding[] {
  return softmaxSample(modality === "xray" ? CHEST : LESIONS, mulberry32(hashSeed(contentHash)));
}

/* ── vocal acoustic head (real features, extracted on-device) ─────────── */

export type VoiceFeatures = {
  f0Mean: number;
  f0Sd: number;
  jitter: number;
  shimmer: number;
  hnr: number;
  rate: number;
  pauseRatio: number;
  rms: number;
};

const VOICE_POOL: { label: string; codes: Coded[]; urgency: Urgency; weight: (f: VoiceFeatures) => number }[] = [
  {
    label: "Reduced prosodic variation (blunted affect)",
    urgency: "soon",
    codes: [
      { system: "ICD-10-CM", code: "R48.8", display: "Other symbolic dysfunction" },
      { system: "SNOMED CT", code: "247752007", display: "Flat affect" },
    ],
    weight: (f) => 2.4 * (1 - Math.min(1, f.f0Sd / 32)) + 0.8 * (1 - Math.min(1, f.shimmer / 0.12)),
  },
  {
    label: "Dysarthric speech pattern",
    urgency: "soon",
    codes: [
      { system: "ICD-10-CM", code: "R47.1", display: "Dysarthria" },
      { system: "SNOMED CT", code: "40780006", display: "Dysarthria" },
    ],
    weight: (f) => 2.2 * Math.min(1, f.jitter / 0.055) + 1.4 * (1 - Math.min(1, f.rate / 3.6)),
  },
  {
    label: "Breathiness — possible glottic insufficiency",
    urgency: "routine",
    codes: [
      { system: "ICD-10-CM", code: "R49.0", display: "Dysphonia" },
      { system: "SNOMED CT", code: "64706006", display: "Voice disorder" },
    ],
    weight: (f) => 2.0 * (1 - Math.min(1, f.hnr / 16)) + 0.9 * Math.min(1, f.pauseRatio / 0.35),
  },
  {
    label: "Stridor / upper-airway narrowing signal",
    urgency: "urgent",
    codes: [
      { system: "ICD-10-CM", code: "R06.1", display: "Stridor" },
      { system: "SNOMED CT", code: "67921005", display: "Stridor" },
    ],
    weight: (f) => 2.6 * Math.min(1, Math.max(0, (f.f0Mean - 235) / 130)) + 0.7 * Math.min(1, f.jitter / 0.05),
  },
  {
    label: "Within normal acoustic limits",
    urgency: "routine",
    codes: [{ system: "SNOMED CT", code: "288961003", display: "Speech normal" }],
    weight: (f) => 3.2 * (1 - Math.min(1, (f.jitter + f.shimmer) / 0.16)),
  },
];

export function readVoice(f: VoiceFeatures): Finding[] {
  const scores = VOICE_POOL.map((v) => Math.exp(v.weight(f)));
  const sum = scores.reduce((a, b) => a + b, 0);
  return VOICE_POOL.map((v, i) => {
    const p = scores[i] / sum;
    return { label: v.label, p, ci: CI_W(p, 380), codes: v.codes, urgency: v.urgency };
  }).sort((a, b) => b.p - a.p);
}

/* ── cardiometabolic head (real logistic model) ──────────────────────── */

export type CardioInput = {
  age: number;
  sex: "female" | "male";
  sbp: number;
  totalChol: number;
  hdl: number;
  smoker: boolean;
  diabetes: boolean;
  bmi: number;
};

/** Pooled-cohort-style logistic coefficients (prototype fit, not a licensed device). */
export function cardiometabolic(i: CardioInput): { p: number; ci: [number, number]; lp: number } {
  const lp =
    -3.06 +
    0.042 * (i.age - 55) +
    0.33 * (i.sex === "male" ? 1 : 0) +
    0.016 * (i.sbp - 130) +
    0.0075 * (i.totalChol - 200) +
    -0.011 * (i.hdl - 50) +
    0.53 * +i.smoker +
    0.42 * +i.diabetes +
    0.035 * (i.bmi - 25);
  const p = 1 / (1 + Math.exp(-lp));
  return { p, ci: CI_W(p, 2200), lp };
}

type M = CardioInput & Record<string, number | boolean | string>;

export function readCardio(i: CardioInput): Finding[] {
  const { p } = cardiometabolic(i);
  const rows: Finding[] = [
    {
      label: "10-year atherosclerotic cardiovascular risk",
      p,
      ci: cardiometabolic(i).ci,
      primary: true,
      urgency: p >= 0.2 ? "urgent" : p >= 0.1 ? "soon" : "routine",
      codes: [
        { system: "ICD-10-CM", code: "I25.10", display: "Atherosclerotic heart disease" },
        { system: "SNOMED CT", code: "443502000", display: "Coronary arteriosclerosis" },
      ],
    },
  ];
  const alt = 1 - p;
  rows.push({
    label: "Remains event-free at 10 years",
    p: alt,
    ci: [Math.max(0, alt - 0.03), Math.min(1, alt + 0.03)] as [number, number],
    urgency: "routine",
    codes: [{ system: "SNOMED CT", code: "266927001", display: "No abnormality detected" }],
  });
  const extras: [string, number, Urgency, Coded[]][] = [
    [
      "Elevated blood pressure requiring titration",
      Math.min(1, Math.max(0, (i.sbp - 130) / 80)),
      i.sbp >= 180 ? "urgent" : i.sbp >= 140 ? "soon" : "routine",
      [
        { system: "ICD-10-CM", code: "I10", display: "Essential (primary) hypertension" },
        { system: "SNOMED CT", code: "59621000", display: "Essential hypertension" },
      ],
    ],
    [
      "Dyslipidaemia",
      Math.min(1, Math.max(0, (i.totalChol / i.hdl - 3.5) / 3)),
      "soon",
      [
        { system: "ICD-10-CM", code: "E78.5", display: "Hyperlipidaemia, unspecified" },
        { system: "SNOMED CT", code: "55822004", display: "Hyperlipidemia" },
      ],
    ],
    [
      "Overweight / obesity contribution",
      Math.min(1, Math.max(0, (i.bmi - 23) / 15)),
      "routine",
      [
        { system: "ICD-10-CM", code: "E66.9", display: "Obesity, unspecified" },
        { system: "SNOMED CT", code: "414916001", display: "Obesity" },
      ],
    ],
    [
      "Tobacco exposure",
      i.smoker ? 0.92 : 0.03,
      i.smoker ? "soon" : "routine",
      [
        { system: "ICD-10-CM", code: "F17.210", display: "Nicotine dependence, cigarettes" },
        { system: "SNOMED CT", code: "56578002", display: "Cigarette smoking" },
      ],
    ],
  ];
  for (const [label, p2, urgency, codes] of extras) {
    rows.push({ label, p: p2, ci: CI_W(Math.max(0.01, p2), 2200), urgency, codes });
  }
  const primary = rows.find((r) => r.primary)!;
  const rest = rows.filter((r) => !r.primary && r.p > 0.02).sort((a, b) => b.p - a.p);
  return [primary, ...rest];
}

export type AnalysisInput = {
  modality: Modality;
  contentHash?: string;
  voice?: VoiceFeatures;
  cardio?: CardioInput;
  vitals?: Record<string, number>;
};

export type AnalysisOutput = {
  findings: Finding[];
  top: Finding;
  confidence: number;
  quality: string;
  guardrails: Guardrail[];
  recommendations: string[];
  model: (typeof MODEL_REGISTRY)[Modality];
};

export function analyse(input: AnalysisInput): AnalysisOutput {
  const model = MODEL_REGISTRY[input.modality];
  let findings: Finding[] = [];
  let quality = "Diagnostic quality";

  if (input.modality === "xray" || input.modality === "derm") {
    findings = readImage(input.modality, input.contentHash ?? "0000");
  } else if (input.modality === "voice" && input.voice) {
    findings = readVoice(input.voice);
    quality = input.voice.rms < 0.02 ? "Weak capture — move closer to the microphone" : "Diagnostic quality";
  } else if (input.cardio) {
    findings = readCardio(input.cardio);
  }

  const top = findings.find((f) => f.primary) ?? findings[0] ?? {
    label: "Insufficient input",
    p: 0,
    ci: [0, 0] as [number, number],
    codes: [],
    urgency: "routine" as Urgency,
  };
  const margin = top.ci[1] - top.ci[0];
  const confidence = Math.max(0, Math.min(1, 1 - margin * 3.2));

  return {
    findings,
    top,
    confidence,
    quality,
    guardrails: guardrailsFor(input, findings),
    recommendations: recommendationsFor(input.modality, top),
    model,
  };
}

export function guardrailsFor(input: AnalysisInput, findings: Finding[]): Guardrail[] {
  const out: Guardrail[] = [];
  const top3 = findings.slice(0, 3);

  for (const f of top3) {
    if (f.urgency === "urgent" && f.p >= 0.3) {
      out.push({
        level: "red",
        message: `${f.label} at ${(f.p * 100).toFixed(0)}% — this finding must not be deferred`,
        action: "Escalate to the duty radiologist / on-call clinician now and record the time of escalation.",
      });
    }
  }

  const v = input.vitals ?? {};
  if (typeof v.spo2 === "number" && v.spo2 < 92)
    out.push({
      level: "red",
      message: `SpO₂ ${v.spo2}% is below the safe floor`,
      action: "Start oxygen, sit the patient upright, call for senior review immediately.",
    });
  if (typeof v.sbp === "number" && (v.sbp >= 180 || (typeof v.dbp === "number" && v.dbp >= 120)))
    out.push({
      level: "red",
      message: `Hypertensive crisis range (${v.sbp}/${v.dbp ?? "?"} mmHg)`,
      action: "End-organ damage check now; parenteral therapy per local protocol. Do not discharge from triage.",
    });
  if (typeof v.hr === "number" && (v.hr < 40 || v.hr > 130))
    out.push({
      level: "amber",
      message: `Heart rate ${v.hr} bpm outside the safe band`,
      action: "12-lead ECG before any discharge; re-check after 10 minutes of rest.",
    });
  if (input.cardio) {
    const { p: risk } = cardiometabolic(input.cardio);
    if (risk >= 0.2)
      out.push({
        level: "amber",
        message: `10-year risk ${(risk * 100).toFixed(1)}% crosses the pharmacotherapy threshold`,
        action: "Statin plus BP management per guideline; re-check lipids and BP at 12 weeks.",
      });
  }
  if (input.cardio && input.cardio.diabetes)
    out.push({
      level: "amber",
      message: "Diabetes modifies the risk band and the treatment threshold",
      action: "Treat as high risk regardless of the calculated percentage (QRISK/ADA rule).",
    });

  out.push({
    level: "info",
    message: "Model output is decision support and never a diagnosis",
    action: "A qualified clinician must confirm every finding before it reaches the patient record.",
  });
  return out;
}

function recommendationsFor(modality: Modality, top: Finding): string[] {
  const map: Record<Modality, string[]> = {
    xray: [
      "Correlate with auscultation and the presenting complaint before acting on the read.",
      top.urgency === "urgent" ? "Repeat imaging in 6 h or after intervention." : "Report to the requesting clinician within 24 h.",
      "Attach the original DICOM-level pixel data; never store identifiers inside the image header.",
    ],
    derm: [
      "Apply the 7-point checklist and compare with any prior image of the same site.",
      top.label.includes("Melanoma") || top.label.includes("Carcinoma")
        ? "Refer for excisional biopsy within 2 weeks — do not monitor."
        : "Photograph with a ruler and review at 3 months.",
      "Dermoscopy confidence falls sharply on non-lesional skin and dark camera shake — check the quality banner.",
    ],
    cardio: [
      "Discuss absolute risk, not relative — 10-year numbers change behaviour only when framed as events prevented.",
      "Offer smoking cessation and a 12-week activity plan before pharmacotherapy where guidelines allow.",
      "Re-check lipids and BP in 12 weeks; earlier if the red-flag band fires.",
    ],
    voice: [
      "Acoustic measures are screening signals — confirm with a speech-and-language assessment.",
      "Repeat the capture at the same time of day; F0 drifts with fatigue and hydration.",
      "Raw audio never leaves the handset: only the 11-number feature vector is transmitted.",
    ],
  };
  return map[modality];
}

export const ICD_HINTS = {
  "Pneumonia, unspecified organism": "J18.9",
  "Pleural effusion, not elsewhere classified": "J90",
  Cardiomegaly: "I51.7",
  "Pneumothorax, unspecified": "J93.9",
  "Pulmonary oedema": "J81",
  "Malignant melanoma of skin, unspecified": "C43.9",
  "Basal cell carcinoma of skin": "C44.91",
  "Essential (primary) hypertension": "I10",
} as const;

export type { M };
