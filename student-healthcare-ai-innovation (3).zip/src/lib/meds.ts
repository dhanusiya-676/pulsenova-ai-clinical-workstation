/**
 * EMBER formulary — the counselling layer that answers "when and where do I take
 * this?" in the words a health worker uses at the door.
 *
 * Every entry carries the three things a woman actually asks: WHEN (clock slot
 * and relation to food), WHERE (home / facility / labour room), and WHAT HAPPENS
 * IF I DON'T (why + what to watch). Content follows WHO & ISSHP regimens for
 * hypertensive disorders of pregnancy; it is a counselling aid for a registered
 * prescriber, never a prescription generator.
 */

export type Slot = "morning" | "noon" | "evening" | "night" | "stat" | "once";

export const SLOTS: { key: Slot; label: string; time: string }[] = [
  { key: "morning", label: "Morning", time: "08:00" },
  { key: "noon", label: "Midday", time: "13:00" },
  { key: "evening", label: "Evening", time: "18:00" },
  { key: "night", label: "Night", time: "22:00" },
  { key: "stat", label: "Now (stat)", time: "on arrival" },
  { key: "once", label: "One course", time: "as written" },
];

export const PLACE = {
  home: "At home",
  facility: "At the facility",
  theatre: "Labour room only",
} as const;

export type Med = {
  id: string;
  name: string;
  klass: string;
  strength: string;
  dose: string;
  route: string;
  slots: Slot[];
  food: string;
  place: string;
  duration: string;
  why: string;
  warn: string;
  severe?: boolean;
};

export const FORMULARY: Med[] = [
  {
    id: "magnesium",
    name: "Magnesium sulphate",
    klass: "Anticonvulsant — the drug that stops the fit",
    strength: "50% 2 ml ampoule",
    dose: "Loading 4 g IV over 20 min, then 5 g IM into each buttock · maintenance 1 g/hour IV",
    route: "IV / IM",
    slots: ["stat", "night"],
    food: "Any — never on an empty stomach concern; given by drip",
    place: PLACE.theatre,
    duration: "Continue for 24 hours after the last fit or after delivery",
    why: "More than halves the risk of eclampsia. It is the single highest-value dose in this whole chart.",
    warn: "NEVER at home. Check breathing rate and knee jerks before every dose; hold if breathing < 16/min or jerks are gone. Calcium gluconate 1 g IV must be in the room as the antidote.",
    severe: true,
  },
  {
    id: "labetalol",
    name: "Labetalol",
    klass: "Beta blocker — first line for severe BP",
    strength: "200 mg tablet",
    dose: "200 mg twice daily (max 1.2 g/day) · severe: 20 mg IV, doubling every 30 min",
    route: "Oral (IV in facility)",
    slots: ["morning", "evening"],
    food: "After food",
    place: PLACE.home,
    duration: "Until delivery, then reassess at day 3",
    why: "Brings the systolic down within 30 minutes and holds it steady between visits.",
    warn: "Tell the doctor if she has asthma or slow pulse — do not give the IV form in asthma. Never stop suddenly at home without advice.",
  },
  {
    id: "nifedipine",
    name: "Nifedipine (slow release)",
    klass: "Calcium channel blocker",
    strength: "30 mg SR capsule",
    dose: "30 mg once daily · up to 90–120 mg/day in divided doses",
    route: "Oral",
    slots: ["morning"],
    food: "After food, swallow whole — never bite or crush",
    place: PLACE.home,
    duration: "Until delivery",
    why: "Steady 24-hour cover from one capsule, useful when twice-daily dosing is forgotten.",
    warn: "Avoid grapefruit juice. Expect a warm flush and headache in the first week — this is common and settles.",
  },
  {
    id: "methyldopa",
    name: "Methyldopa",
    klass: "Central alpha agonist — pregnancy-safe maintenance",
    strength: "250 mg tablet",
    dose: "250 mg two to three times daily (max 3 g/day)",
    route: "Oral",
    slots: ["morning", "noon", "evening"],
    food: "After food",
    place: PLACE.home,
    duration: "Until delivery; stop after delivery and switch agent",
    why: "The longest safety record of any BP drug in pregnancy.",
    warn: "Causes sleepiness in the first fortnight — do not take the evening dose late if she has to travel. Report yellowing of eyes or dark urine.",
  },
  {
    id: "hydralazine",
    name: "Hydralazine",
    klass: "Vasodilator — severe hypertension, second line",
    strength: "20 mg ampoule",
    dose: "5–10 mg IV slowly over 2 minutes, repeat every 20 minutes",
    route: "IV",
    slots: ["stat"],
    food: "Not applicable",
    place: PLACE.facility,
    duration: "Single doses until systolic < 150 mmHg",
    why: "Used when labetalol is contraindicated, to bring BP down over 20–30 minutes.",
    warn: "Facility only — needs continuous BP monitoring. Over-treatment drops fetal blood flow; never push faster than 5 mg per 2 minutes.",
    severe: true,
  },
  {
    id: "aspirin",
    name: "Low-dose aspirin",
    klass: "Prevention — for the next pregnancy too",
    strength: "75–81 mg tablet",
    dose: "75–81 mg once daily at night",
    route: "Oral",
    slots: ["night"],
    food: "After food, at bedtime",
    place: PLACE.home,
    duration: "From 12 weeks until 36 weeks or delivery",
    why: "Cuts the risk of pre-eclampsia by around 60% in women with a previous episode, chronic hypertension, kidney disease or diabetes.",
    warn: "Not before 12 weeks. Stop at 36 weeks. Never add ibuprofen or other NSAIDs on top of it.",
  },
  {
    id: "calcium",
    name: "Calcium carbonate",
    klass: "Supplement",
    strength: "500 mg tablet",
    dose: "500 mg twice daily (total 1.5–2 g elemental calcium/day)",
    route: "Oral",
    slots: ["morning", "night"],
    food: "With or just after food — never with tea or iron",
    place: PLACE.home,
    duration: "Throughout pregnancy and 6 months of breastfeeding",
    why: "Where dietary calcium is low this is one of the cheapest proven ways to reduce eclampsia risk.",
    warn: "Keep 3–4 hours apart from iron and thyroid tablets — they block each other.",
  },
  {
    id: "ironfolate",
    name: "Iron + folic acid",
    klass: "Supplement",
    strength: "100 mg elemental iron + 0.5 mg folic acid",
    dose: "One tablet once daily",
    route: "Oral",
    slots: ["morning"],
    food: "On an empty stomach, 1 hour before food, with a squeeze of lemon",
    place: PLACE.home,
    duration: "180 days through pregnancy and after delivery",
    why: "Treats and prevents anaemia, which makes every haorrhage safer to survive.",
    warn: "Black stool is expected. Do not take with milk, tea or calcium. Report vomiting or severe constipation.",
  },
  {
    id: "paracetamol",
    name: "Paracetamol (acetaminophen)",
    klass: "Analgesic — the only routine painkiller here",
    strength: "500 mg tablet",
    dose: "500–1000 mg up to four times daily (max 4 g in 24 hours)",
    route: "Oral",
    slots: ["stat"],
    food: "After food",
    place: PLACE.home,
    duration: "No more than 3 days without review",
    why: "Safe for headache and body ache in pregnancy at correct doses.",
    warn: "A headache that does not respond to paracetamol is itself a danger sign — call the facility, do not add ibuprofen.",
  },
  {
    id: "betamethasone",
    name: "Betamethasone",
    klass: "Antenatal steroid — matures the baby's lungs",
    strength: "12 mg IM injection",
    dose: "12 mg IM, two injections 24 hours apart",
    route: "IM",
    slots: ["once"],
    food: "Not applicable",
    place: PLACE.facility,
    duration: "One course, 24 hours apart — never repeat within 7 days",
    why: "Given when the baby may be born before 34 weeks; reduces newborn breathing difficulty and brain injury.",
    warn: "Facility only. Not beneficial beyond 34 weeks. Two doses only — a third dose is harmful.",
    severe: true,
  },
];

/** Safe in most situations but worth confirming at every visit. */
export const WATCH_WITH = [
  { name: "Insulin / metformin", note: "dose needs adjusting weekly — review, do not stop" },
  { name: "Levothyroxine", note: "needs 25–50% more in pregnancy; take 4 h apart from iron/calcium" },
  { name: "Antiretrovirals / TB treatment", note: "continue uninterrupted; tell the prescriber before anything new" },
];

/** Never in pregnancy, and never with pre-eclampsia. Shown as a printed red block. */
export const NEVER_IN_PREGNANCY: { name: string; why: string }[] = [
  { name: "Enalapril, captopril, ramipril (ACE inhibitors)", why: "damages the baby's kidneys and skull" },
  { name: "Losartan, valsartan (ARBs)", why: "same harm as ACE inhibitors" },
  { name: "Warfarin", why: "causes fetal bleeding and bone malformation" },
  { name: "Ibuprofen, diclofenac and other NSAIDs (after 20 weeks)", why: "damages fetal kidneys and closes the ductus arteriosus" },
  { name: "Furosemide and other diuretics", why: "shrinks plasma volume — the opposite of what she needs" },
  { name: "Ergometrine / methylergometrine", why: "drives BP up sharply" },
  { name: "Isotretinoin", why: "severe birth defects; requires documented contraception" },
];

export const MISSED_DOSE = [
  "Remembered within 4 hours of the written time — take it now, then carry on as normal.",
  "More than 4 hours late, and the next dose is near — skip it. Never take two together to make up.",
  "Two or more doses missed in a row — call the facility before restarting; BP control has been lost.",
  "Vomited within 30 minutes of swallowing — repeat the dose once. After 30 minutes, do not repeat.",
];

export function slotsOf(med: Med) {
  return SLOTS.filter((s) => med.slots.includes(s.key));
}
