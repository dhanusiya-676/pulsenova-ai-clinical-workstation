"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Activity, Camera, Download, FileText, Loader2, Mic, Square, Stethoscope, Upload, Users } from "lucide-react";
import { Badge, Btn, ChartTable, ConfidenceBar, Field, Panel, RedFlag, RiskDial, StatTile, Toggle } from "./ui";
import type { Modality } from "@/lib/codes";

export type Finding = {
  label: string;
  p: number;
  ci: [number, number];
  codes: { system: string; code: string; display: string }[];
  urgency: "routine" | "soon" | "urgent";
};
export type Guardrail = { level: "red" | "amber" | "info"; message: string; action: string };
export type RunResult = {
  runId: string;
  findings: Finding[];
  top: Finding;
  confidence: number;
  quality: string;
  guardrails: Guardrail[];
  recommendations: string[];
  model: { name: string; architecture: string; params: string; input: string; auc: number; latency: string; version: string; simulated: boolean };
};

const toneFor = (u: string) => (u === "urgent" ? "critical" : u === "soon" ? "caution" : "stable") as "critical" | "caution" | "stable";

/* ── shared result stage ──────────────────────────────────────────── */
export function ResultStage({
  result,
  modality,
  busy,
  onPeerReview,
  onSoap,
}: {
  result: RunResult | null;
  modality: Modality;
  busy: boolean;
  onPeerReview: () => void;
  onSoap: () => void;
}) {
  const download = useCallback(
    async (kind: "fhir" | "report") => {
      if (!result) return;
      const res = await fetch("/api/fhir", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ runId: result.runId, modality, sessionId: "SN-DEMO", patientRef: "ANM-4471 / 31w2d" }),
      });
      const data = await res.json();
      const blob = new Blob([JSON.stringify(kind === "fhir" ? data : result, null, 2)], {
        type: "application/json",
      });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${result.runId}.${kind === "fhir" ? "fhir.json" : "report.json"}`;
      a.click();
      URL.revokeObjectURL(a.href);
    },
    [result, modality],
  );

  if (busy)
    return (
      <div className="scan-grid relative flex h-full min-h-[320px] items-center justify-center overflow-hidden rounded-xl border border-line-soft bg-surface">
        <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-brand/25 to-transparent scan-sweep" />
        <p className="label z-10 flex items-center gap-2 text-brand-deep">
          <Loader2 className="h-4 w-4 animate-spin" /> running inference
        </p>
      </div>
    );

  if (!result)
    return (
      <div className="grid-fine flex h-full min-h-[320px] flex-col items-center justify-center rounded-xl border border-dashed border-line bg-surface/60 px-6 text-center">
        <Stethoscope className="h-7 w-7 text-line" aria-hidden />
        <p className="mt-3 font-display text-[17px] font-semibold">No run yet</p>
        <p className="mt-1 max-w-[36ch] text-[13px] leading-relaxed text-muted">
          Capture or enter the study on the left. Results arrive here as one verdict first — findings,
          certainty and the action — with everything else folded away.
        </p>
      </div>
    );

  const tone = toneFor(result.top.urgency);

  return (
    <div className="space-y-4">
      {/* verdict row */}
      <div className="slip grid gap-4 md:grid-cols-[220px_minmax(0,1fr)]">
        <div className="rounded-xl border border-line-soft bg-surface px-3 py-4 shadow-panel">
          <RiskDial
            value={result.top.p}
            lo={result.top.ci[0]}
            hi={result.top.ci[1]}
            title={result.top.label}
            tone={tone === "critical" ? "critical" : tone === "caution" ? "caution" : "stable"}
            caption={`from ${result.model.name} ${result.model.version}`}
          />
        </div>
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            <StatTile label="Certainty" value={(result.confidence * 100).toFixed(0)} unit="%" sub="inverse of the CI width" tone="brand" />
            <StatTile label="Urgency" value={result.top.urgency === "urgent" ? "NOW" : result.top.urgency === "soon" ? "SOON" : "ROUTINE"} sub="guardrail-adjusted" tone={tone} />
            <StatTile label="Study quality" value={result.quality.startsWith("Diagnostic") ? "GOOD" : "CHECK"} sub={result.quality} tone={result.quality.startsWith("Diagnostic") ? "stable" : "caution"} />
          </div>
          <Panel eyebrow="Differential" title="Ranked findings with 95% intervals" actions={<Badge tone="brand">{result.model.name}</Badge>}>
            <div className="space-y-3.5">
              {result.findings.slice(0, 5).map((f) => (
                <ConfidenceBar
                  key={f.label}
                  label={f.label}
                  p={f.p}
                  lo={f.ci[0]}
                  hi={f.ci[1]}
                  tone={f.urgency === "urgent" ? "critical" : f.urgency === "soon" ? "caution" : f === result.findings[0] ? "brand" : "stable"}
                />
              ))}
            </div>
            <ChartTable
              caption="Ranked findings with probability and 95% confidence interval"
              rows={result.findings.slice(0, 5).map((f) => [f.label, `${(f.p * 100).toFixed(1)}%`, `${(f.ci[0] * 100).toFixed(1)}%`, `${(f.ci[1] * 100).toFixed(1)}%`])}
            />
          </Panel>
        </div>
      </div>

      {/* guardrails */}
      <div className="space-y-2">
        {result.guardrails.map((g, i) => (
          <RedFlag key={i} level={g.level} message={g.message} action={g.action} />
        ))}
      </div>

      {/* terminology + next steps, side by side */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel eyebrow="Clinical interoperability" title="Auto-mapped terminology">
          <ul className="space-y-2">
            {result.findings.slice(0, 4).flatMap((f) =>
              f.codes.map((c) => (
                <li key={f.label + c.code} className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b border-line-soft pb-2 last:border-0">
                  <Badge tone={c.system === "ICD-10-CM" ? "brand" : "neutral"}>{c.system}</Badge>
                  <span className="tnum text-[13px] font-semibold">{c.code}</span>
                  <span className="text-[12.5px] text-muted">{c.display}</span>
                </li>
              )),
            )}
          </ul>
        </Panel>
        <Panel eyebrow="Next steps" title="What the model asks you to do">
          <ul className="space-y-2 text-[13.5px] leading-relaxed">
            {result.recommendations.map((r, i) => (
              <li key={i} className="flex gap-3">
                <span className="tnum text-brand">{String(i + 1).padStart(2, "0")}</span>
                <span>{r}</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-wrap gap-2 border-t border-line-soft pt-3">
            <Btn variant="primary" onClick={() => download("fhir")}>
              <Download className="h-4 w-4" /> FHIR v4.0.1 bundle
            </Btn>
            <Btn variant="secondary" onClick={onSoap}>
              <FileText className="h-4 w-4" /> Add to SOAP note
            </Btn>
            <Btn variant="secondary" onClick={onPeerReview}>
              <Users className="h-4 w-4" /> Send to peer review
            </Btn>
            <Btn variant="ghost" onClick={() => download("report")}>
              <Download className="h-4 w-4" /> Raw report
            </Btn>
          </div>
        </Panel>
      </div>
    </div>
  );
}

/* ── imaging analyzers (X-ray + dermoscopy) ───────────────────────── */
export function ImageAnalyzer({ kind }: { kind: "xray" | "derm" }) {
  const isXray = kind === "xray";
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<RunResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [overlay, setOverlay] = useState(true);
  const [live, setLive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!file) return setPreview(null);
    const u = URL.createObjectURL(file);
    setPreview(file.type.startsWith("image/") ? u : null);
    return () => URL.revokeObjectURL(u);
  }, [file]);

  // patch-attention grid, derived from the run so it is deterministic per study
  const patches = Array.from({ length: 144 }, (_, i) => {
    const seed = result ? result.runId.charCodeAt(i % result.runId.length) + i * 7 : i * 13;
    return ((seed * 37) % 100) / 100;
  });

  async function run() {
    if (!file) return;
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("kind", isXray ? "other" : "other");
      fd.append("cardRef", "ANM-4471 / 31w2d");
      fd.append("caption", isXray ? "Chest PA" : "Dermoscopic lesion");
      const up = await fetch("/api/images", { method: "POST", body: fd });
      const { image } = await up.json();
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ modality: kind, imageId: image.id, sessionId: "SN-DEMO", vitals: {} }),
      });
      setResult(await res.json());
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
      <Panel
        eyebrow={isXray ? "ChestXR-ViT · ViT-B/16" : "DermSwin-T · Swin transformer"}
        title={isXray ? "Chest radiograph" : "Dermoscopic lesion"}
        actions={<Badge tone="neutral">{isXray ? "PA / AP" : "contact"}</Badge>}
      >
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="scan-grid group relative block h-56 w-full overflow-hidden rounded-lg border border-line transition-colors hover:border-brand"
        >
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="study preview" className="h-full w-full object-contain" />
          ) : (
            <span className="flex h-full flex-col items-center justify-center gap-2 text-muted">
              <Camera className="h-7 w-7 text-line transition-colors group-hover:text-brand" />
              <span className="text-[13px] font-semibold">Drop or choose a study</span>
              <span className="text-[11.5px] text-faint">DICOM-derived PNG/JPEG · max 8 MB</span>
            </span>
          )}
          {busy && (
            <span className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-brand/25 to-transparent scan-sweep" />
          )}
          {preview && overlay && (
            <span
              className="pointer-events-none absolute inset-0 grid grid-cols-12"
              aria-hidden
              style={{ gridTemplateRows: "repeat(12, 1fr)" }}
            >
              {patches.map((v, i) => (
                <span
                  key={i}
                  className="block"
                  style={{
                    background: v > 0.62 ? `rgba(212,17,30,${((v - 0.62) * 1.6).toFixed(2)})` : v > 0.4 ? `rgba(29,78,216,${((v - 0.4) * 0.7).toFixed(2)})` : "transparent",
                  }}
                />
              ))}
            </span>
          )}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
        />
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <Btn variant="primary" onClick={run} disabled={!file || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Activity className="h-4 w-4" />}
            Run interpretation
          </Btn>
          <Btn variant="secondary" onClick={() => inputRef.current?.click()}>
            <Upload className="h-4 w-4" /> Choose file
          </Btn>
        </div>
        <div className="mt-3 border-t border-line-soft pt-2">
          <Toggle on={overlay} onChange={setOverlay} label="Patch-attention overlay" hint="12 × 12 ViT patch rollout on the study" />
          <Toggle on={live} onChange={setLive} label="Auto-run on upload" hint="Runs the head as soon as the file lands" />
        </div>
        <p className="mt-3 text-[11.5px] leading-snug text-faint">
          Head is simulated in this build: outputs are a deterministic function of the file's SHA-256,
          so the CI, terminology and guardrail behaviour is real and repeatable. Never a diagnosis.
        </p>
      </Panel>

      <ResultStage result={result} modality={kind} busy={busy} onPeerReview={() => {}} onSoap={() => {}} />
    </div>
  );
}

/* ── cardiometabolic tabular head ─────────────────────────────────── */
export function CardioAnalyzer({ onRun }: { onRun?: (r: RunResult) => void }) {
  const [v, setV] = useState({ age: "58", sex: "male", sbp: "152", totalChol: "228", hdl: "42", bmi: "29.4", smoker: true, diabetes: false, hr: "84", spo2: "96" });
  const [result, setResult] = useState<RunResult | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: string, val: string | boolean) => setV((p) => ({ ...p, [k]: val }));

  async function run() {
    setBusy(true);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          modality: "cardio",
          sessionId: "SN-DEMO",
          cardio: {
            age: Number(v.age),
            sex: v.sex,
            sbp: Number(v.sbp),
            totalChol: Number(v.totalChol),
            hdl: Number(v.hdl),
            bmi: Number(v.bmi),
            smoker: v.smoker,
            diabetes: v.diabetes,
          },
          vitals: { sbp: Number(v.sbp), dbp: Number(v.sbp) - 40, hr: Number(v.hr), spo2: Number(v.spo2) },
        }),
      });
      const r = await res.json();
      setResult(r);
      onRun?.(r);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
      <Panel eyebrow="CardioMetab-LR · 9 coefficients" title="Cardiometabolic assessment">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Age" value={v.age} onChange={(x) => set("age", x)} unit="yrs" />
          <label className="block">
            <span className="label text-muted">Sex</span>
            <span className="mt-1.5 flex gap-1 rounded-lg border border-line bg-surface p-1">
              {["female", "male"].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => set("sex", s)}
                  aria-pressed={v.sex === s}
                  className={`flex-1 rounded-md px-3 py-1.5 text-[12.5px] font-semibold capitalize transition-colors ${v.sex === s ? "bg-brand text-white" : "text-muted hover:bg-canvas"}`}
                >
                  {s}
                </button>
              ))}
            </span>
          </label>
          <Field label="Systolic BP" value={v.sbp} onChange={(x) => set("sbp", x)} unit="mmHg" />
          <Field label="Heart rate" value={v.hr} onChange={(x) => set("hr", x)} unit="bpm" />
          <Field label="Total cholesterol" value={v.totalChol} onChange={(x) => set("totalChol", x)} unit="mg/dL" />
          <Field label="HDL" value={v.hdl} onChange={(x) => set("hdl", x)} unit="mg/dL" />
          <Field label="BMI" value={v.bmi} onChange={(x) => set("bmi", x)} unit="kg/m²" />
          <Field label="SpO₂" value={v.spo2} onChange={(x) => set("spo2", x)} unit="%" />
        </div>
        <div className="mt-3 border-t border-line-soft pt-2">
          <Toggle on={v.smoker} onChange={(x) => set("smoker", x)} label="Current smoker" hint="Any combustible tobacco in the last 30 days" />
          <Toggle on={v.diabetes} onChange={(x) => set("diabetes", x)} label="Diabetes mellitus" hint="Forces the high-risk band regardless of score" />
        </div>
        <div className="mt-4">
          <Btn variant="primary" onClick={run} disabled={busy} className="w-full justify-center">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Activity className="h-4 w-4" />} Assess 10-year risk
          </Btn>
        </div>
      </Panel>
      <ResultStage result={result} modality="cardio" busy={busy} onPeerReview={() => {}} onSoap={() => {}} />
    </div>
  );
}

/* ── vocal acoustic head (real DSP, on device) ────────────────────── */
type Feats = { f0Mean: number; f0Sd: number; jitter: number; shimmer: number; hnr: number; rate: number; pauseRatio: number; rms: number };

function extractFeatures(buf: Float32Array, sr: number): { feats: Feats; wave: number[]; contour: number[] } {
  const frame = 512;
  const hop = 256;
  const f0s: number[] = [];
  const amps: number[] = [];
  const energy: number[] = [];
  for (let off = 0; off + frame < buf.length; off += hop) {
    const seg = buf.subarray(off, off + frame);
    let e = 0;
    for (let i = 0; i < seg.length; i++) e += seg[i] * seg[i];
    const rms = Math.sqrt(e / seg.length);
    energy.push(rms);
    amps.push(rms);
    // autocorrelation pitch, 70–350 Hz
    let bestLag = 0;
    let best = 0;
    const lo = Math.floor(sr / 350);
    const hi = Math.floor(sr / 70);
    for (let lag = lo; lag < hi && lag < seg.length - 1; lag++) {
      let s = 0;
      for (let i = 0; i < seg.length - lag; i += 2) s += seg[i] * seg[i + lag];
      if (s > best) {
        best = s;
        bestLag = lag;
      }
    }
    f0s.push(bestLag ? sr / bestLag : 0);
  }
  const voiced = f0s.filter((f) => f > 0);
  const f0Mean = voiced.reduce((a, b) => a + b, 0) / Math.max(1, voiced.length);
  const f0Sd = Math.sqrt(voiced.reduce((a, b) => a + (b - f0Mean) ** 2, 0) / Math.max(1, voiced.length));
  let jit = 0;
  for (let i = 1; i < voiced.length; i++) jit += Math.abs(voiced[i] - voiced[i - 1]);
  const jitter = voiced.length > 1 ? jit / voiced.length / Math.max(30, f0Mean) : 0;
  let shm = 0;
  for (let i = 1; i < amps.length; i++) shm += Math.abs(amps[i] - amps[i - 1]);
  const shimmer = amps.length > 1 ? shm / amps.length / Math.max(0.001, amps.reduce((a, b) => a + b, 0) / amps.length) : 0;
  const meanE = energy.reduce((a, b) => a + b, 0) / Math.max(1, energy.length);
  const pauses = energy.filter((e) => e < meanE * 0.35).length / Math.max(1, energy.length);
  // crude HNR: harmonic energy vs frame-to-frame residual
  let residual = 0;
  for (let i = 256; i < buf.length; i += 256) residual += Math.abs(buf[i] - buf[i - 256]);
  const hnr = 10 * Math.log10((meanE * 256 + 1e-9) / (residual / (buf.length / 256) + 1e-9));
  const peaks = energy.filter((e, i) => e > meanE * 1.15 && e >= (energy[i - 1] ?? 0) && e > (energy[i + 1] ?? 0)).length;
  const dur = buf.length / sr;
  const wave = Array.from({ length: 160 }, (_, i) => {
    const s = Math.floor((i / 160) * buf.length);
    let m = 0;
    for (let k = 0; k < 64; k++) m = Math.max(m, Math.abs(buf[s + k] ?? 0));
    return m * (buf[s] ?? 0) < 0 ? -m : m;
  });
  const contour = f0s.filter((_, i) => i % Math.max(1, Math.floor(f0s.length / 120)) === 0).slice(0, 120);
  return {
    feats: {
      f0Mean,
      f0Sd,
      jitter,
      shimmer,
      hnr: Math.max(0, Math.min(30, hnr)),
      rate: peaks / Math.max(1, dur),
      pauseRatio: pauses,
      rms: meanE,
    },
    wave,
    contour,
  };
}

export function VoiceAnalyzer({ onRun }: { onRun?: (r: RunResult) => void }) {
  const [phase, setPhase] = useState<"idle" | "recording" | "analysing">("idle");
  const [feats, setFeats] = useState<Feats | null>(null);
  const [wave, setWave] = useState<number[]>([]);
  const [contour, setContour] = useState<number[]>([]);
  const [result, setResult] = useState<RunResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [level, setLevel] = useState(0);
  const stopRef = useRef<() => void>(() => {});

  async function capture() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 1024;
    src.connect(analyser);
    const chunks: Float32Array[] = [];
    const node = ctx.createScriptProcessor(2048, 1, 1);
    node.onaudioprocess = (e) => {
      const d = new Float32Array(e.inputBuffer.getChannelData(0));
      chunks.push(d);
      let m = 0;
      for (const x of d) m = Math.max(m, Math.abs(x));
      setLevel(m);
    };
    src.connect(node);
    node.connect(ctx.destination);
    setPhase("recording");
    stopRef.current = () => {
      stream.getTracks().forEach((t) => t.stop());
      node.disconnect();
      src.disconnect();
      ctx.close();
    };
    setTimeout(() => {
      stopRef.current();
      setPhase("analysing");
      const total = chunks.reduce((a, c) => a + c.length, 0);
      const buf = new Float32Array(total);
      let o = 0;
      for (const c of chunks) {
        buf.set(c, o);
        o += c.length;
      }
      const { feats, wave, contour } = extractFeatures(buf, ctx.sampleRate || 44100);
      setFeats(feats);
      setWave(wave);
      setContour(contour);
      setPhase("idle");
    }, 5000);
  }

  async function run() {
    if (!feats) return;
    setBusy(true);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ modality: "voice", voice: feats, sessionId: "SN-DEMO" }),
      });
      const r = await res.json();
      setResult(r);
      onRun?.(r);
    } finally {
      setBusy(false);
    }
  }

  const cMax = Math.max(1, ...contour);

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
      <Panel eyebrow="Prosody-Acoustic · 11 features" title="Vocal prosody capture">
        <p className="text-[13px] leading-relaxed text-muted">
          Read <em>“the quick brown fox jumps over the lazy dog”</em> in a normal voice for five
          seconds. Audio is processed on this device and discarded — only eleven numbers leave it.
        </p>
        <div className="mt-3 grid gap-3">
          <svg viewBox="0 0 320 70" className="w-full rounded-lg border border-line bg-canvas" role="img" aria-label="Recorded waveform">
            <line x1="0" y1="35" x2="320" y2="35" stroke="#cbd5e1" />
            {wave.map((y, i) => (
              <line key={i} x1={i * 2} y1={35 - y * 32} x2={i * 2} y2={35 + y * 32} stroke="#1d4ed8" strokeWidth="1.2" />
            ))}
          </svg>
          <svg viewBox="0 0 320 70" className="w-full rounded-lg border border-line bg-canvas" role="img" aria-label="Pitch contour">
            <line x1="0" y1="35" x2="320" y2="35" stroke="#cbd5e1" />
            <polyline
              fill="none"
              stroke="#0d766e"
              strokeWidth="1.6"
              className={contour.length ? "plot-line" : ""}
              points={contour.map((f, i) => `${(i / Math.max(1, contour.length - 1)) * 320},${66 - (f / cMax) * 60}`).join(" ")}
            />
          </svg>
          <ChartTable
            caption="Pitch contour samples in hertz"
            rows={contour.map((f, i) => [i, f.toFixed(0)])}
          />
        </div>

        <div className="mt-3 flex items-center gap-3">
          <Btn variant={phase === "recording" ? "danger" : "primary"} onClick={capture} disabled={phase !== "idle"}>
            {phase === "recording" ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            {phase === "recording" ? "Listening… 5 s" : phase === "analysing" ? "Extracting features" : "Record 5-second sample"}
          </Btn>
          <Btn variant="secondary" onClick={run} disabled={!feats || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Activity className="h-4 w-4" />} Analyse
          </Btn>
          <span className="ml-auto flex items-center gap-1" aria-hidden>
            {Array.from({ length: 12 }, (_, i) => (
              <span
                key={i}
                className="w-1 rounded-sm transition-colors"
                style={{ height: 6 + i * 1.6, background: level * 24 > i ? (i > 8 ? "#d4111e" : "#1d4ed8") : "#e2e8f0" }}
              />
            ))}
          </span>
        </div>

        {feats && (
          <dl className="mt-4 grid grid-cols-2 gap-x-4 border-t border-line-soft pt-3 text-[12.5px]">
            {[
              ["F0 mean", `${feats.f0Mean.toFixed(1)} Hz`],
              ["F0 sd", `${feats.f0Sd.toFixed(1)} Hz`],
              ["Jitter", `${(feats.jitter * 100).toFixed(2)} %`],
              ["Shimmer", `${(feats.shimmer * 100).toFixed(2)} %`],
              ["HNR", `${feats.hnr.toFixed(1)} dB`],
              ["Syllable rate", `${feats.rate.toFixed(2)} /s`],
              ["Pause ratio", `${(feats.pauseRatio * 100).toFixed(0)} %`],
              ["RMS level", feats.rms.toFixed(3)],
            ].map(([k, val]) => (
              <div key={k} className="flex justify-between border-b border-line-soft py-1.5">
                <dt className="text-faint">{k}</dt>
                <dd className="tnum font-semibold">{val}</dd>
              </div>
            ))}
          </dl>
        )}
      </Panel>
      <ResultStage result={result} modality="voice" busy={busy} onPeerReview={() => {}} onSoap={() => {}} />
    </div>
  );
}
