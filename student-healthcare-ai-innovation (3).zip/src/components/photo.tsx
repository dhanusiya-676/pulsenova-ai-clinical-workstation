"use client";

import { useState } from "react";

/**
 * Photograph with a designed fallback: if the asset fails to load we degrade to
 * a printed chart-paper surface rather than leaving a hole in the layout.
 */
export function Photo({
  src,
  alt,
  className = "",
  imgClassName = "",
  position = "center",
}: {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  position?: string;
}) {
  const [failed, setFailed] = useState(false);
  if (failed)
    return (
      <div
        className={`grid-paper bg-stock ${className}`}
        role="img"
        aria-label={alt}
        style={{ backgroundColor: "#E9DFCE" }}
      />
    );
  return (
    <div className={`relative overflow-hidden bg-stock ${className}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={alt}
        onError={() => setFailed(true)}
        className={`h-full w-full object-cover ${imgClassName}`}
        style={{ objectPosition: position }}
      />
    </div>
  );
}
