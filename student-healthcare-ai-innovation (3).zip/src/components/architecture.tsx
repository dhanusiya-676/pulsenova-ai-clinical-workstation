const NODES = [
  {
    x: 30,
    y: 128,
    w: 182,
    h: 116,
    t: "Handset (offline)",
    s: ["Community phone, no signal", "Vitals + symptoms + dipstick", "Runs ember-lr/0.4.2 locally"],
    tone: "#16211f",
  },
  {
    x: 262,
    y: 128,
    w: 176,
    h: 116,
    t: "Encrypted SQLite queue",
    s: ["AES-256, key in StrongBox", "Feature vector only", "No name, no ID, no GPS"],
    tone: "#16211f",
  },
  {
    x: 488,
    y: 40,
    w: 176,
    h: 112,
    t: "Pseudonymising relay",
    s: ["Stores-and-forwards", "K-anonymity k ≥ 5", "IP + timestamp truncated"],
    tone: "#0E6B5C",
  },
  {
    x: 488,
    y: 196,
    w: 176,
    h: 112,
    t: "Referral dispatch",
    s: ["SMS/USSD fallback", "Facility + ETA + band", "Two-way status receipt"],
    tone: "#C63A21",
  },
  {
    x: 714,
    y: 40,
    w: 176,
    h: 112,
    t: "Audit ledger (append-only)",
    s: ["Postgres, hash-chained", "Every inference recorded", "Exportable for review"],
    tone: "#0E6B5C",
  },
  {
    x: 714,
    y: 196,
    w: 176,
    h: 112,
    t: "Model registry",
    s: ["Signed weights, versioned", "Rollback on drift", "No auto-update in the field"],
    tone: "#C63A21",
  },
];

const ARROWS = [
  { x1: 212, y1: 186, x2: 262, y2: 186, label: "write" },
  { x1: 438, y1: 168, x2: 488, y2: 110, label: "sync when uplink" },
  { x1: 438, y1: 204, x2: 488, y2: 242, label: "urgent band" },
  { x1: 664, y1: 96, x2: 714, y2: 96, label: "hash chain" },
  { x1: 664, y1: 252, x2: 714, y2: 252, label: "signed v" },
  { x1: 576, y1: 152, x2: 576, y2: 196, label: "" },
];

export function Architecture() {
  return (
    <figure className="border border-ink/25 bg-paper">
      <svg viewBox="0 0 920 380" className="w-full" role="img" aria-label="EMBER data flow and privacy architecture">
        <defs>
          <marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">
            <path d="M0 0 L10 5 L0 10 z" fill="#16211f" />
          </marker>
          <pattern id="hatch" width="6" height="6" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
            <line x1="0" y1="0" x2="0" y2="6" stroke="#C63A21" strokeWidth="1" opacity="0.18" />
          </pattern>
        </defs>

        {/* boundary of the device — nothing to the left of it is identifiable */}
        <rect x="14" y="18" width="440" height="344" fill="url(#hatch)" stroke="#C63A21" strokeDasharray="5 4" />
        <text x="24" y="42" className="label" fill="#C63A21" fontFamily="IBM Plex Mono" fontSize="10" letterSpacing="1.6">
          TRUST BOUNDARY · AIR-GAPPED FIELD DEVICE
        </text>
        <rect x="466" y="18" width="440" height="344" fill="none" stroke="#16211f" strokeOpacity="0.3" strokeDasharray="2 5" />
        <text x="476" y="42" className="label" fill="#8A8071" fontFamily="IBM Plex Mono" fontSize="10" letterSpacing="1.6">
          DISTRICT SERVER ROOM · NO DIRECT IDENTIFIERS
        </text>

        {ARROWS.map((a, i) => (
          <g key={i}>
            <line x1={a.x1} y1={a.y1} x2={a.x2} y2={a.y2} stroke="#16211f" strokeWidth="1.4" markerEnd="url(#ar)" />
            {a.label ? (
              <text
                x={(a.x1 + a.x2) / 2}
                y={Math.min(a.y1, a.y2) - 7}
                textAnchor="middle"
                fill="#8A8071"
                fontFamily="IBM Plex Mono"
                fontSize="9"
                letterSpacing="0.8"
              >
                {a.label}
              </text>
            ) : null}
          </g>
        ))}

        {NODES.map((n) => (
          <g key={n.t}>
            <rect x={n.x + 3} y={n.y + 3} width={n.w} height={n.h} fill="#16211f" opacity="0.08" />
            <rect x={n.x} y={n.y} width={n.w} height={n.h} fill="#F4EEE3" stroke={n.tone} strokeWidth="1.4" />
            <rect x={n.x} y={n.y} width={n.w} height="26" fill={n.tone} opacity="0.12" />
            <text
              x={n.x + 12}
              y={n.y + 18}
              fill={n.tone}
              fontFamily="IBM Plex Mono"
              fontSize="11.5"
              letterSpacing="0.6"
              fontWeight="600"
            >
              {n.t}
            </text>
            {n.s.map((line, k) => (
              <text
                key={line}
                x={n.x + 12}
                y={n.y + 46 + k * 18}
                fill="#3d4744"
                fontFamily="IBM Plex Sans"
                fontSize="11.5"
              >
                {line}
              </text>
            ))}
          </g>
        ))}

        {/* invariants */}
        <text x="24" y="330" fill="#16211f" fontFamily="IBM Plex Mono" fontSize="10.5" letterSpacing="0.8">
          INVARIANT 1 — inference never leaves the handset; the model travels to the data.
        </text>
        <text x="24" y="348" fill="#16211f" fontFamily="IBM Plex Mono" fontSize="10.5" letterSpacing="0.8">
          INVARIANT 2 — only {`{band, risk, feature vector, pseudonym}`} are ever written upstream.
        </text>
      </svg>
      <figcaption className="border-t border-ink/25 px-4 py-3 text-[12.5px] leading-relaxed text-ink-soft">
        <span className="label mr-2 text-vermilion">Fig. 1</span>
        End-to-end flow from doorstep to district server. Retraining draws only from the DP-noised
        aggregate store (ε = 1.6 per quarter, k-anonymity k ≥ 5); raw feature vectors are deleted
        after 180 days under the retention policy. Threat notes: a lost handset exposes only the
        encrypted queue; a compromised relay cannot re-identify a woman without the booklet, which
        never travels.
      </figcaption>
    </figure>
  );
}
