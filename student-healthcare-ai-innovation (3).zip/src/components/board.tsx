"use client";

import { useCallback, useEffect, useState } from "react";
import { Phone, PhoneOff } from "lucide-react";
import type { Referral } from "@/db/schema";

const TONES: Record<string, string> = {
  EMERGENCY: "#8E1D12",
  URGENT: "#C63A21",
  WATCH: "#C8862A",
  ROUTINE: "#0E6B5C",
};
const FLOW = ["QUEUED", "CALLED", "TRANSFERRED", "CLOSED"];
const COLS = [
  "Band",
  "Card ref (pseudonym)",
  "Receiving facility",
  "Risk",
  "Transport ETA",
  "Call-back number",
  "Opened by",
  "Status",
];

function ContactCell({ row, onSaved }: { row: Referral; onSaved: () => void }) {
  const [draft, setDraft] = useState(row.phone ?? "");
  const [saving, setSaving] = useState(false);

  if (row.phone) {
    return (
      <div>
        <a
          href={`tel:${row.phone}`}
          className="tnum flex items-center gap-1.5 text-vermilion underline underline-offset-2 hover:text-deepred"
        >
          <Phone className="h-3.5 w-3.5" />
          {row.phone}
        </a>
        <p className="text-[11px] leading-snug text-warmgrey">
          {row.contactName || "no name given"}
          {row.callNote ? ` · ${row.callNote}` : ""}
        </p>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <span className="label flex items-center gap-1 text-ochre">
        <PhoneOff className="h-3.5 w-3.5" /> no number
      </span>
      <input
        type="tel"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        placeholder="add number"
        className="tnum w-24 border-b border-ink/25 bg-transparent py-0.5 text-[12px] outline-none focus:border-vermilion"
      />
      <button
        type="button"
        disabled={saving || !draft.trim()}
        onClick={async () => {
          setSaving(true);
          await fetch("/api/referrals", {
            method: "PATCH",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ id: row.id, phone: draft, consentToCall: true, status: "QUEUED" }),
          }).catch(() => null);
          setSaving(false);
          onSaved();
        }}
        className="label border border-ink/30 px-1.5 py-1 transition-colors hover:border-vermilion hover:text-vermilion disabled:opacity-40"
      >
        save
      </button>
    </div>
  );
}

export function ReferralDesk() {
  const [rows, setRows] = useState<Referral[] | null>(null);

  const load = useCallback(() => {
    fetch("/api/referrals")
      .then((r) => r.json())
      .then((d) => setRows(d.referrals))
      .catch(() => setRows([]));
  }, []);

  useEffect(load, [load]);

  async function advance(row: Referral) {
    const next = FLOW[Math.min(FLOW.length - 1, FLOW.indexOf(row.status) + 1)];
    setRows((prev) =>
      prev ? prev.map((r) => (r.id === row.id ? { ...r, status: next } : r)) : prev,
    );
    await fetch("/api/referrals", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: row.id, status: next }),
    }).catch(load);
  }

  const missing = (rows ?? []).filter((r) => !r.phone && r.status !== "CLOSED").length;

  return (
    <div className="border border-ink/25 bg-paper">
      <div className="flex flex-wrap items-baseline justify-between gap-3 border-b-2 border-ink px-5 py-3">
        <h3 className="font-display text-3xl leading-none">Referral desk — live queue</h3>
        <p className="label text-warmgrey">
          {missing > 0 ? (
            <span className="text-ochre">{missing} without a call-back number</span>
          ) : (
            "every open referral is callable"
          )}
          <span className="ml-3 inline-block h-2 w-2 animate-pulse bg-vermilion align-middle" />
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[980px] border-collapse text-[13.5px]">
          <thead>
            <tr className="border-b border-ink/30">
              {COLS.map((h) => (
                <th key={h} className="label px-4 py-2.5 text-left text-warmgrey">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(rows ?? []).map((r) => (
              <tr key={r.id} className="border-b border-ink/15 transition-colors hover:bg-stock/50">
                <td className="px-4 py-3">
                  <span className="stamp px-2 py-1 text-[9.5px]" style={{ color: TONES[r.band] ?? "#16211f" }}>
                    {r.band}
                  </span>
                </td>
                <td className="tnum px-4 py-3">{r.cardRef}</td>
                <td className="px-4 py-3">{r.facility}</td>
                <td className="tnum px-4 py-3">{(r.risk * 100).toFixed(1)}%</td>
                <td className="tnum px-4 py-3">{r.etaMinutes > 0 ? `${r.etaMinutes} min` : "—"}</td>
                <td className="px-4 py-3">
                  <ContactCell row={r} onSaved={load} />
                </td>
                <td className="px-4 py-3 text-warmgrey">{r.openedBy}</td>
                <td className="px-4 py-3">
                  <button
                    type="button"
                    onClick={() => advance(r)}
                    className="label border border-ink/30 px-2.5 py-1.5 transition-colors hover:border-vermilion hover:text-vermilion"
                  >
                    {r.status} →
                  </button>
                </td>
              </tr>
            ))}
            {rows && rows.length === 0 && (
              <tr>
                <td colSpan={COLS.length} className="label px-5 py-8 text-center text-warmgrey">
                  Queue clear — no open referrals
                </td>
              </tr>
            )}
            {!rows && (
              <tr>
                <td colSpan={COLS.length} className="label animate-pulse px-5 py-8 text-center text-warmgrey">
                  Loading queue…
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="border-t border-ink/25 px-5 py-3 text-[12px] leading-relaxed text-warmgrey">
        A referral with <span className="text-ochre">no call-back number</span> cannot be actioned by
        phone — the desk has to send someone. That is exactly what the number field in section E
        fixes. Card references stay pseudonymous: only the receiving ANM can resolve one to a name,
        from the booklet in the woman&apos;s hand.
      </p>
    </div>
  );
}
