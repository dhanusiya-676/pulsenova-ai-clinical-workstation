"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, Plus, Printer, Trash2 } from "lucide-react";
import { FORMULARY, MISSED_DOSE, NEVER_IN_PREGNANCY, PLACE, SLOTS, WATCH_WITH, type Med, type Slot } from "@/lib/meds";
import { Stamp } from "./ui";

type Item = { med: Med; slots: Slot[]; place: string; duration: string; note: string };

const SCHEDULE = SLOTS.filter((s) => s.key === "morning" || s.key === "noon" || s.key === "evening" || s.key === "night");
const ALL_SLOTS = SLOTS;

const inDays = (n: number) => {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d;
};

export function PrescriptionBuilder() {
  const [items, setItems] = useState<Item[]>(() =>
    FORMULARY.filter((m) => ["labetalol", "calcium"].includes(m.id)).map((med) => ({
      med,
      slots: med.slots,
      place: med.place,
      duration: med.duration,
      note: "",
    })),
  );
  const [head, setHead] = useState({
    cardRef: "",
    contactName: "",
    phone: "",
    gestAge: 34,
    diagnosis: "Pre-eclampsia without severe features (O14.0)",
    prescriber: "",
    regNo: "",
    facility: "CHC Bargaon",
    reviewInDays: 7,
    notes: "",
  });
  const [saved, setSaved] = useState<
    { rxCode: string; id: number; cardRef: string; diagnosis: string; prescriber: string; facility: string; reviewInDays: number; createdAt: string; items: { drug: string; slots: string[]; place: string; food: string; dose: string; duration: string; note: string; strength: string; route: string }[] }[]
  >([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/prescriptions")
      .then((r) => r.json())
      .then((d) => setSaved(d.prescriptions ?? []))
      .catch(() => setSaved([]));
  }, []);

  const toggle = (med: Med) =>
    setItems((prev) =>
      prev.some((i) => i.med.id === med.id)
        ? prev.filter((i) => i.med.id !== med.id)
        : [...prev, { med, slots: med.slots, place: med.place, duration: med.duration, note: "" }],
    );

  const setSlot = (id: string, slot: Slot) =>
    setItems((prev) =>
      prev.map((i) =>
        i.med.id === id
          ? {
              ...i,
              slots: i.slots.includes(slot) ? i.slots.filter((s) => s !== slot) : [...i.slots, slot],
            }
          : i,
      ),
    );

  const reviewDate = useMemo(() => inDays(head.reviewInDays), [head.reviewInDays]);

  async function save() {
    setMsg(null);
    if (!items.length) return setMsg("Pick at least one medicine.");
    if (!head.prescriber.trim() || !head.regNo.trim())
      return setMsg("A registered prescriber and registration number are required before this sheet can be issued.");
    setBusy(true);
    try {
      const res = await fetch("/api/prescriptions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ...head,
          items: items.map((i) => ({
            drug: i.med.id,
            slots: i.slots,
            place: i.place,
            duration: i.duration,
            note: i.note || i.med.warn,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "could not save");
      setSaved((prev) => [data.prescription, ...prev]);
      setMsg(`Issued as ${data.prescription.rxCode} and stored in the database.`);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,30rem)]">
      {/* ── builder ────────────────────────────────────── */}
      <div className="grain relative border border-ink/25 bg-paper px-5 py-6 sm:px-8">
        <div className="flex flex-wrap items-baseline justify-between gap-3 border-b-2 border-ink pb-2">
          <h3 className="font-display text-3xl leading-none">Write the chart</h3>
          <p className="label text-warmgrey">Prescriber section · to be signed</p>
        </div>

        <div className="grid gap-x-10 gap-y-2 pt-5 sm:grid-cols-2">
          {[
            ["Booklet ref", "cardRef"],
            ["Woman's name (optional)", "contactName"],
            ["Phone for the call-back", "phone"],
            ["Registration no.", "regNo"],
            ["Prescriber", "prescriber"],
            ["Facility", "facility"],
          ].map(([label, key]) => (
            <label key={key} className="rule-field flex items-baseline gap-3 py-2.5">
              <span className="label shrink-0 text-ink-soft">{label}</span>
              <input
                className="ml-auto w-40 bg-transparent text-right text-[15px] outline-none focus:text-vermilion"
                value={String((head as Record<string, string | number>)[key] ?? "")}
                onChange={(e) =>
                  setHead((h) => ({ ...h, [key]: e.target.value }) as typeof h)
                }
              />
            </label>
          ))}
          <label className="rule-field flex items-baseline gap-3 py-2.5">
            <span className="label shrink-0 text-ink-soft">Gestation (wk)</span>
            <input
              type="number"
              min={20}
              max={42}
              className="tnum ml-auto w-20 bg-transparent text-right text-[15px] outline-none"
              value={head.gestAge}
              onChange={(e) => setHead((h) => ({ ...h, gestAge: Number(e.target.value) }))}
            />
          </label>
          <label className="rule-field flex items-baseline gap-3 py-2.5">
            <span className="label shrink-0 text-ink-soft">Review in (days)</span>
            <input
              type="number"
              min={0}
              max={90}
              className="tnum ml-auto w-20 bg-transparent text-right text-[15px] outline-none"
              value={head.reviewInDays}
              onChange={(e) => setHead((h) => ({ ...h, reviewInDays: Number(e.target.value) }))}
            />
          </label>
          <label className="rule-field col-span-full flex items-baseline gap-3 py-2.5">
            <span className="label shrink-0 text-ink-soft">Working diagnosis</span>
            <input
              className="ml-auto w-full max-w-[24rem] bg-transparent text-right text-[15px] outline-none focus:text-vermilion"
              value={head.diagnosis}
              onChange={(e) => setHead((h) => ({ ...h, diagnosis: e.target.value }))}
            />
          </label>
        </div>

        <p className="label mt-8 text-vermilion">Pick medicines · then set when &amp; where</p>
        <div className="mt-3 grid gap-px bg-ink/15 sm:grid-cols-2">
          {FORMULARY.map((m) => {
            const on = items.some((i) => i.med.id === m.id);
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => toggle(m)}
                className={`flex items-start gap-3 px-3 py-3 text-left transition-colors ${
                  on ? "bg-ink text-paper" : "bg-paper hover:bg-stock"
                }`}
              >
                <span
                  className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center border ${
                    on ? "border-paper bg-paper" : "border-ink/40"
                  }`}
                >
                  {on && <Check className="h-3 w-3 text-ink" />}
                </span>
                <span>
                  <span className="block text-[14px] font-medium leading-tight">{m.name}</span>
                  <span className={`block text-[11px] leading-snug ${on ? "text-paper/70" : "text-warmgrey"}`}>
                    {m.strength} · {m.klass}
                  </span>
                </span>
              </button>
            );
          })}
        </div>

        {items.map((i) => (
          <div key={i.med.id} className="slip mt-5 border border-ink/25 bg-stock/40 px-4 py-4">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <p className="font-display text-2xl leading-none">{i.med.name}</p>
              <button
                type="button"
                onClick={() => toggle(i.med)}
                className="label flex items-center gap-1 text-warmgrey hover:text-vermilion"
              >
                <Trash2 className="h-3.5 w-3.5" /> remove
              </button>
            </div>
            <p className="mt-2 text-[13.5px] leading-relaxed">
              <span className="label text-warmgrey">Dose</span> {i.med.dose}{" "}
              <span className="text-warmgrey">({i.med.route})</span>
              <br />
              <span className="label text-warmgrey">Why</span> {i.med.why}
            </p>

            <p className="label mt-4 text-vermilion">When to take it</p>
            <div className="mt-2 flex flex-wrap gap-px bg-ink/15">
              {ALL_SLOTS.map((s) => {
                const on = i.slots.includes(s.key);
                return (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => setSlot(i.med.id, s.key)}
                    className={`label px-3 py-2 transition-colors ${
                      on ? "bg-vermilion text-paper" : "bg-paper text-ink-soft hover:bg-stock"
                    }`}
                  >
                    {s.label} <span className="tnum ml-1 opacity-70">{s.time}</span>
                  </button>
                );
              })}
            </div>

            <div className="mt-3 grid gap-3 sm:grid-cols-[minmax(0,1fr)_minmax(0,14rem)]">
              <label>
                <span className="label block text-warmgrey">With food</span>
                <input
                  className="w-full border-b border-ink/25 bg-transparent py-1.5 text-[13.5px] outline-none focus:text-vermilion"
                  value={i.med.food}
                  onChange={(e) =>
                    setItems((prev) =>
                      prev.map((x) => (x.med.id === i.med.id ? { ...x, med: { ...x.med, food: e.target.value } } : x)),
                    )
                  }
                />
              </label>
              <label>
                <span className="label block text-warmgrey">Where it is taken</span>
                <select
                  className="w-full border-b border-ink/25 bg-transparent py-1.5 text-[13.5px] outline-none"
                  value={i.place}
                  onChange={(e) =>
                    setItems((prev) => prev.map((x) => (x.med.id === i.med.id ? { ...x, place: e.target.value } : x)))
                  }
                >
                  {Object.values(PLACE).map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </label>
              <label className="sm:col-span-2">
                <span className="label block text-warmgrey">For how long</span>
                <input
                  className="w-full border-b border-ink/25 bg-transparent py-1.5 text-[13.5px] outline-none focus:text-vermilion"
                  value={i.duration}
                  onChange={(e) =>
                    setItems((prev) =>
                      prev.map((x) => (x.med.id === i.med.id ? { ...x, duration: e.target.value } : x)),
                    )
                  }
                />
              </label>
            </div>

            <p className="mt-3 border-l-2 border-ochre bg-ochre/8 px-3 py-2 text-[12.5px] leading-relaxed">
              <span className="label text-ochre">Watch out</span> {i.med.warn}
            </p>
          </div>
        ))}

        <label className="mt-5 block">
          <span className="label block text-warmgrey">Counselling note to the woman</span>
          <textarea
            rows={2}
            className="mt-1 w-full border border-ink/25 bg-transparent px-3 py-2 text-[14px] outline-none focus:border-vermilion"
            placeholder="Anything said out loud at the door — in her language."
            value={head.notes}
            onChange={(e) => setHead((h) => ({ ...h, notes: e.target.value }))}
          />
        </label>

        <div className="mt-6 flex flex-wrap items-center gap-4 border-t-2 border-ink pt-5">
          <button
            type="button"
            onClick={save}
            disabled={busy}
            className="flex items-center gap-2 bg-vermilion px-5 py-3.5 text-paper transition-colors hover:bg-deepred disabled:opacity-60"
          >
            <Plus className="h-4 w-4" />
            <span className="label text-[11px]">Issue &amp; store prescription</span>
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="label flex items-center gap-2 border border-ink px-5 py-3.5 transition-colors hover:bg-stock"
          >
            <Printer className="h-4 w-4" /> Print the card
          </button>
          {msg && <p className="slip text-[13px] text-vermilion">{msg}</p>}
        </div>
      </div>

      {/* ── the printed card: when & where ─────────────── */}
      <aside className="lg:sticky lg:top-24 lg:self-start">
        <div className="print-area grain relative border border-ink/35 bg-[#faf5ea] shadow-[6px_6px_0_rgba(22,33,31,0.1)]">
          <div className="flex items-start justify-between border-b border-ink/25 px-4 py-3">
            <div>
              <p className="label text-vermilion">Medicine chart — keep this</p>
              <p className="font-display text-xl leading-tight">When &amp; where to take it</p>
            </div>
            <Stamp tone="clinic">Signed</Stamp>
          </div>

          <div className="grid-fine px-4 py-3 text-[12.5px]">
            <p className="tnum text-warmgrey">
              {head.cardRef || "ANM-···· / ——w·d"} · {head.gestAge} wk ·{" "}
              {head.contactName || "name on booklet"}
            </p>
            <p className="mt-1 leading-snug">{head.diagnosis}</p>
          </div>

          <div className="overflow-x-auto border-t border-ink/25">
            <table className="w-full min-w-[26rem] border-collapse text-[12.5px]">
              <thead>
                <tr className="border-b border-ink/30">
                  <th className="label px-3 py-2 text-left text-warmgrey">Medicine</th>
                  {SCHEDULE.map((s) => (
                    <th key={s.key} className="label px-1 py-2 text-center text-warmgrey">
                      {s.time}
                    </th>
                  ))}
                  <th className="label px-2 py-2 text-left text-warmgrey">Where</th>
                </tr>
              </thead>
              <tbody>
                {items.map((i) => (
                  <tr key={i.med.id} className="border-b border-ink/15 align-top">
                    <td className="px-3 py-2.5">
                      <span className="block font-medium leading-tight">{i.med.name}</span>
                      <span className="block text-[10.5px] leading-snug text-warmgrey">
                        {i.med.dose.split("·")[0].trim()} · {i.med.food}
                      </span>
                    </td>
                    {SCHEDULE.map((s) => (
                      <td key={s.key} className="px-1 py-2.5 text-center">
                        {i.slots.includes(s.key) ? (
                          <span className="inline-block h-2.5 w-2.5 rounded-full bg-vermilion" />
                        ) : (
                          <span className="inline-block h-px w-3 bg-ink/20 align-middle" />
                        )}
                      </td>
                    ))}
                    <td className="px-2 py-2.5 text-[11.5px] leading-snug">{i.place}</td>
                  </tr>
                ))}
                {items.length === 0 && (
                  <tr>
                    <td colSpan={6} className="label px-3 py-6 text-center text-warmgrey">
                      Pick a medicine to start the chart
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <ul className="space-y-1.5 border-t border-ink/25 px-4 py-3 text-[12px] leading-relaxed">
            {items.map((i) => (
              <li key={i.med.id}>
                <span className="label text-vermilion">{i.med.name}</span> — {i.duration}
              </li>
            ))}
            <li className="text-warmgrey">
              Next review:{" "}
              <span className="tnum text-ink">
                {reviewDate.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" })}
              </span>{" "}
              at {head.facility}. Bring this chart and the booklet.
            </li>
            {head.notes && <li className="pt-1 italic">“{head.notes}”</li>}
          </ul>

          <div className="border-t border-ink/25 px-4 py-3">
            <p className="tnum text-[12px]">
              {head.prescriber || "— prescriber —"} · Reg {head.regNo || "————"}
            </p>
            <p className="label mt-2 text-warmgrey">
              PulseNova AI counselling aid · not a substitute for the prescriber's judgement
            </p>
          </div>
        </div>

        <div className="mt-5 border border-ink/25 bg-stock/50 px-4 py-4">
          <p className="label text-vermilion">If a dose is missed</p>
          <ol className="mt-2 space-y-1.5 text-[12.5px] leading-relaxed text-ink-soft">
            {MISSED_DOSE.map((m, k) => (
              <li key={m} className="flex gap-2">
                <span className="tnum text-warmgrey">{k + 1}</span>
                {m}
              </li>
            ))}
          </ol>
        </div>
      </aside>

      {/* ── never-take block + saved prescriptions ────── */}
      <div className="lg:col-span-2">
        <div className="grid gap-8 lg:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
          <div className="border border-vermilion bg-vermilion/6 px-5 py-6">
            <Stamp tone="vermilion">Never in pregnancy</Stamp>
            <p className="mt-3 text-[13px] leading-relaxed text-ink-soft">
              Show this block to every woman who carries another prescription, and check her bag
              before she leaves.
            </p>
            <ul className="mt-4 space-y-2 text-[13px] leading-snug">
              {NEVER_IN_PREGNANCY.map((n) => (
                <li key={n.name} className="border-b border-vermilion/25 pb-2">
                  <span className="block font-medium">{n.name}</span>
                  <span className="block text-warmgrey">{n.why}</span>
                </li>
              ))}
            </ul>
            <p className="label mt-4 text-warmgrey">Ask at every visit</p>
            <ul className="mt-2 space-y-1.5 text-[12.5px] leading-snug text-ink-soft">
              {WATCH_WITH.map((w) => (
                <li key={w.name}>
                  <strong className="text-ink">{w.name}</strong> — {w.note}
                </li>
              ))}
            </ul>
          </div>

          <div className="border border-ink/25 bg-paper">
            <div className="flex items-baseline justify-between border-b-2 border-ink px-5 py-3">
              <h3 className="font-display text-3xl leading-none">Issued prescriptions</h3>
              <p className="label tnum text-warmgrey">{saved.length} in the database</p>
            </div>
            {saved.length === 0 ? (
              <p className="label px-5 py-12 text-center text-warmgrey">Nothing issued yet</p>
            ) : (
              <ul className="divide-y divide-ink/15">
                {saved.map((p) => (
                  <li key={p.rxCode} className="px-5 py-4">
                    <div className="flex flex-wrap items-baseline justify-between gap-3">
                      <p className="tnum text-[15px]">{p.rxCode}</p>
                      <p className="label text-warmgrey">
                        {new Date(p.createdAt).toLocaleDateString(undefined, {
                          day: "2-digit",
                          month: "short",
                        })}{" "}
                        · review in {p.reviewInDays} d
                      </p>
                    </div>
                    <p className="mt-1 text-[13px] leading-snug text-ink-soft">
                      {p.cardRef} · {p.diagnosis} · {p.prescriber}, {p.facility}
                    </p>
                    <ul className="mt-2 grid gap-1 sm:grid-cols-2">
                      {p.items.map((it) => (
                        <li key={it.drug} className="text-[12.5px] leading-snug">
                          <span className="label text-vermilion">{it.drug}</span> — {it.dose.split("·")[0]}
                          <span className="block text-warmgrey">
                            {it.slots.map((s) => SLOTS.find((x) => x.key === s)?.label ?? s).join(" · ")} ·{" "}
                            {it.food} · {it.place}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            )}
            <p className="border-t border-ink/25 px-5 py-3 text-[12px] leading-relaxed text-warmgrey">
              Every issue is written to the database with the prescriber's registration number and
              the full dosing schedule, so a nurse at 2 a.m. can read exactly what she was told to
              take and when.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
