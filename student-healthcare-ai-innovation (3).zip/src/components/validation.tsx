"use client";

import { useEffect, useRef, useState } from "react";
import type { ValidationPayload } from "@/app/api/validation/route";

const f2 = (x: number) => (Number.isFinite(x) ? x.toFixed(2) : "—");
const f3 = (x: number) => (Number.isFinite(x) ? x.toFixed(3) : "—");
const pc = (x: number) => (Number.isFinite(x) ? `${(x * 100).toFixed(1)}%` : "—");

function useInView<T extends Element>() {
  const ref = useRef<T | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setSeen(true);
          io.disconnect();
        }
      },
      { rootMargin: "-40px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return { ref, seen };
}

function Panel({ title, sub, children }: { title: string; sub: string; children: React.ReactNode }) {
  return (
    <figure className="border border-ink/25 bg-paper">
      <figcaption className="border-b border-ink/25 px-4 py-2">
        <p className="label text-vermilion">{title}</p>
        <p className="mt-0.5 text-[12px] text-warmgrey">{sub}</p>
      </figcaption>
      <div className="grid-paper p-3">{children}</div>
    </figure>
  );
}

function RocPlot({ roc, seen }: { roc: ValidationPayload["roc"]; seen: boolean }) {
  const S = 300;
  const pad = 34;
  const x = (f: number) => pad + f * (S - pad - 10);
  const y = (t: number) => S - pad - t * (S - pad - 10);
  const d = roc.map((p, i) => `${i ? "L" : "M"}${x(p.fpr).toFixed(1)} ${y(p.tpr).toFixed(1)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${S} ${S}`} className="w-full">
      <rect x={pad} y={10} width={S - pad - 10} height={S - pad - 10} fill="#F4EEE3" fillOpacity="0.75" stroke="#16211f" strokeOpacity="0.3" />
      {[0.25, 0.5, 0.75].map((g) => (
        <g key={g}>
          <line x1={x(g)} y1={10} x2={x(g)} y2={y(0)} stroke="#16211f" strokeOpacity="0.12" />
          <line x1={pad} y1={y(g)} x2={x(1)} y2={y(g)} stroke="#16211f" strokeOpacity="0.12" />
        </g>
      ))}
      <line x1={x(0)} y1={y(0)} x2={x(1)} y2={y(1)} stroke="#8A8071" strokeDasharray="4 4" />
      <path
        d={d}
        fill="none"
        stroke="#C63A21"
        strokeWidth="2.4"
        strokeLinejoin="round"
        className={seen ? "plot-line" : ""}
        style={seen ? undefined : { strokeDasharray: 1400, strokeDashoffset: 1400 }}
      />
      <text x={x(0.5)} y={S - 8} textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="9" fill="#8A8071" letterSpacing="1">
        1 − SPECIFICITY
      </text>
      <text x={10} y={y(0.5)} textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="9" fill="#8A8071" letterSpacing="1" transform={`rotate(-90 10 ${y(0.5)})`}>
        SENSITIVITY
      </text>
    </svg>
  );
}

function CalPlot({
  bins,
  fit,
  seen,
}: {
  bins: ValidationPayload["calibration"];
  fit: ValidationPayload["calibrationFit"];
  seen: boolean;
}) {
  const S = 300;
  const pad = 34;
  const max = 0.8;
  const x = (f: number) => pad + (f / max) * (S - pad - 10);
  const y = (t: number) => S - pad - (t / max) * (S - pad - 10);
  const pts = bins.map((b) => ({ x: x(b.pred), y: y(b.obs), n: b.n }));
  const d = pts.map((p, i) => `${i ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${S} ${S}`} className="w-full">
      <rect x={pad} y={10} width={S - pad - 10} height={S - pad - 10} fill="#F4EEE3" fillOpacity="0.75" stroke="#16211f" strokeOpacity="0.3" />
      {[0.2, 0.4, 0.6].map((g) => (
        <g key={g}>
          <line x1={x(g)} y1={10} x2={x(g)} y2={y(0)} stroke="#16211f" strokeOpacity="0.12" />
          <line x1={pad} y1={y(g)} x2={x(max)} y2={y(g)} stroke="#16211f" strokeOpacity="0.12" />
        </g>
      ))}
      <line x1={x(0)} y1={y(0)} x2={x(max)} y2={y(max)} stroke="#8A8071" strokeDasharray="4 4" />
      <path
        d={d}
        fill="none"
        stroke="#C63A21"
        strokeWidth="2"
        className={seen ? "plot-line" : ""}
        style={seen ? undefined : { strokeDasharray: 1400, strokeDashoffset: 1400 }}
      />
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={3 + Math.min(6, p.n / 22)} fill="#F4EEE3" stroke="#16211f" strokeWidth="1.4" />
      ))}
      <text x={x(max / 2)} y={S - 8} textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="9" fill="#8A8071" letterSpacing="1">
        PREDICTED RISK (DECILES)
      </text>
      <text x={10} y={y(max / 2)} textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="9" fill="#8A8071" letterSpacing="1" transform={`rotate(-90 10 ${y(max / 2)})`}>
        OBSERVED
      </text>
    </svg>
  );
}

export function Validation() {
  const [data, setData] = useState<ValidationPayload | null>(null);
  const [err, setErr] = useState(false);
  const { ref, seen } = useInView<HTMLDivElement>();

  useEffect(() => {
    fetch("/api/validation")
      .then((r) => r.json())
      .then(setData)
      .catch(() => setErr(true));
  }, []);

  if (err)
    return (
      <p className="border border-vermilion bg-vermilion/8 px-5 py-6 text-[14px] text-vermilion">
        The validation harness could not reach the cohort store. Reload to retry.
      </p>
    );
  if (!data)
    return (
      <div className="grid-paper flex h-72 items-center justify-center border border-ink/25">
        <p className="label animate-pulse text-warmgrey">Fitting on held-out split…</p>
      </div>
    );

  const rows = [
    {
      label: data.model.label,
      note: `operating point p ≥ ${f3(data.model.threshold)} (fixed on dev at 95% sensitivity)`,
      auc: data.model.auc,
      ci: data.model.aucCI,
      sens: data.model.sens,
      spec: data.model.spec,
      ppv: data.model.ppv,
      npv: data.model.npv,
      hero: true,
    },
    {
      label: "EMBER — lab-free handset mode",
      note: "no pathology available; missing labs imputed to normal priors",
      auc: data.labFree.auc,
      ci: [NaN, NaN] as [number, number],
      sens: data.labFree.sens,
      spec: data.labFree.spec,
      ppv: data.labFree.ppv,
      npv: data.labFree.npv,
      hero: false,
    },
    ...data.baselines.map((b) => ({
      label: b.label,
      note: b.citation,
      auc: b.auc,
      ci: b.aucCI,
      sens: b.sens,
      spec: b.spec,
      ppv: b.ppv,
      npv: b.npv,
      hero: false,
    })),
  ];

  return (
    <div ref={ref} className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <div className="border border-ink/25 bg-paper">
        <div className="flex flex-wrap items-baseline justify-between gap-3 border-b-2 border-ink px-5 py-3">
          <h3 className="font-display text-3xl leading-none">Table 1 — head-to-head, held-out split</h3>
          <p className="tnum text-[12px] text-warmgrey">
            n = {data.cohort.test} · events = {data.cohort.positives} ({pc(data.cohort.prevalence)})
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] border-collapse text-[13.5px]">
            <thead>
              <tr className="border-b border-ink/30">
                <th className="label px-5 py-2.5 text-left text-warmgrey">Rule / model</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">AUC</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">Sens</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">Spec</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">PPV</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">NPV</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr
                  key={r.label}
                  className={`border-b border-ink/15 align-top ${r.hero ? "bg-vermilion/6" : ""}`}
                  style={r.hero ? { boxShadow: "inset 3px 0 0 #C63A21" } : undefined}
                >
                  <td className="px-5 py-3">
                    <span className={`block ${r.hero ? "font-semibold text-vermilion" : ""}`}>
                      {r.label}
                    </span>
                    <span className="mt-0.5 block text-[11.5px] leading-snug text-warmgrey">
                      {r.note}
                    </span>
                  </td>
                  <td className="tnum px-3 py-3 text-right">
                    {f2(r.auc)}
                    <span className="block text-[10.5px] text-warmgrey">
                      {Number.isFinite(r.ci[0]) ? `${f2(r.ci[0])}–${f2(r.ci[1])}` : "—"}
                    </span>
                  </td>
                  <td className="tnum px-3 py-3 text-right">{pc(r.sens)}</td>
                  <td className="tnum px-3 py-3 text-right">{pc(r.spec)}</td>
                  <td className="tnum px-3 py-3 text-right">{pc(r.ppv)}</td>
                  <td className="tnum px-3 py-3 text-right">{pc(r.npv)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="border-t border-ink/25 px-5 py-3 text-[12px] leading-relaxed text-warmgrey">
          Discrimination with percentile-bootstrap 95% CI (400 resamples). Baselines are binary
          rules, so their operating point is a single position on the ROC plane. Synthetic cohort from
          a deterministic simulator — <span className="text-vermilion">internal validation only</span>;
          external prospective validation in two district hospitals is the next milestone.
        </p>
      </div>

      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-1">
        <Panel title="Fig. 2 — ROC" sub="EMBER on the 800-record held-out split">
          <RocPlot roc={data.roc} seen={seen} />
        </Panel>
        <Panel
          title="Fig. 3 — calibration"
          sub={`slope ${f2(data.calibrationFit.slope)} · intercept ${f2(data.calibrationFit.intercept)}`}
        >
          <CalPlot bins={data.calibration} fit={data.calibrationFit} seen={seen} />
        </Panel>
      </div>

      <div className="border border-ink/25 bg-paper lg:col-span-2">
        <div className="flex flex-wrap items-baseline justify-between gap-3 border-b-2 border-ink px-5 py-3">
          <h3 className="font-display text-3xl leading-none">Table 2 — equity audit</h3>
          <p className="label text-warmgrey">Pre-registered subgroups · held-out split</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[680px] border-collapse text-[13.5px]">
            <thead>
              <tr className="border-b border-ink/30">
                <th className="label px-5 py-2.5 text-left text-warmgrey">Subgroup</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">n</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">Events</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">AUC</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">Sens @op.</th>
                <th className="label px-3 py-2.5 text-right text-warmgrey">Δ vs complement</th>
              </tr>
            </thead>
            <tbody>
              {data.subgroup.map((g) => {
                const gap = g.tprGap;
                const tone = Math.abs(gap) < 0.05 ? "#0E6B5C" : Math.abs(gap) < 0.1 ? "#C8862A" : "#C63A21";
                return (
                  <tr key={g.label} className="border-b border-ink/15">
                    <td className="px-5 py-3">{g.label}</td>
                    <td className="tnum px-3 py-3 text-right">{g.n}</td>
                    <td className="tnum px-3 py-3 text-right">{g.positives}</td>
                    <td className="tnum px-3 py-3 text-right">
                      {f2(g.auc)}
                      <span className="block text-[10.5px] text-warmgrey">
                        {f2(g.aucCI[0])}–{f2(g.aucCI[1])}
                      </span>
                    </td>
                    <td className="tnum px-3 py-3 text-right">{pc(g.tpr)}</td>
                    <td className="tnum px-3 py-3 text-right" style={{ color: tone }}>
                      {gap > 0 ? "+" : ""}
                      {f3(gap)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="border-t border-ink/25 px-5 py-3 text-[12px] leading-relaxed text-warmgrey">
          A pre-registered equal-opportunity tolerance of ±0.05 on sensitivity is enforced at
          release. Subgroups failing it block the release build in CI and force either a recalibrated
          threshold per stratum or a documented, clinician-signed exception.
          {(() => {
            const failing = data.subgroup.filter((g) => Math.abs(g.tprGap) > 0.05);
            if (!failing.length)
              return (
                <p className="mt-2 text-clinic">
                  <span className="label">Release gate · cleared</span> — every pre-registered
                  stratum sits inside the tolerance.
                </p>
              );
            return (
              <p className="mt-2 text-vermilion">
                <span className="label">Release gate · blocked</span> — {failing.length} of{" "}
                {data.subgroup.length} strata breach the tolerance (
                {failing
                  .map((g) => `${g.label.toLowerCase()} ${g.tprGap > 0 ? "+" : ""}${f3(g.tprGap)}`)
                  .join(", ")}
                ). v0.4.2 must not ship to the field until per-stratum recalibration lands.
              </p>
            );
          })()}
        </div>
      </div>
    </div>
  );
}
