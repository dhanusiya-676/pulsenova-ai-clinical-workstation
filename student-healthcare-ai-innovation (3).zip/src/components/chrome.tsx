import { ledgerCount } from "@/lib/seed";

export function Mark({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} role="img" aria-label="EMBER mark">
      {/* seal ring with a gap — a rubber stamp on a record card */}
      <circle
        cx="24"
        cy="24"
        r="21.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeDasharray="108 27"
        strokeLinecap="round"
        transform="rotate(-45 24 24)"
        opacity="0.55"
      />
      {/* flame */}
      <path
        d="M24 6.5 C 30 14.5, 34 19.6, 34 25.8 C 34 32.7 29.5 37.5 24 37.5 C 18.5 37.5 14 32.7 14 25.8 C 14 19.6 18 14.5 24 6.5 Z"
        fill="currentColor"
      />
      {/* inner ember, knocked out in paper colour */}
      <path
        d="M24 19.2 C 26.8 23.4, 28.4 25.3, 28.4 27.9 C 28.4 30.6 26.4 32.6 24 32.6 C 21.6 32.6 19.6 30.6 19.6 27.9 C 19.6 25.3 21.2 23.4 24 19.2 Z"
        fill="#f4eee3"
      />
      {/* the record card's fold */}
      <path d="M24 24.4 C 24 27.2 25.6 28.4 27.4 29.4" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

export async function Masthead() {
  let ledger = 0;
  try {
    ledger = await ledgerCount();
  } catch {
    ledger = 0;
  }
  const nav = [
    ["/", "Workstation"],
    ["/prescription", "Prescriptions"],
    ["/design", "Design system"],
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-ink/25 bg-paper/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1320px] items-center gap-5 px-5 py-2.5">
        <a href="#top" className="flex items-center gap-3 text-ink">
          <Mark className="h-8 w-8 shrink-0" />
          <span className="leading-none">
            <span className="block font-display text-2xl leading-none tracking-tight">
              PulseNova AI
            </span>
            <span className="label block pt-1 text-warmgrey">Prescriptions</span>
          </span>
        </a>
        <nav className="ml-auto hidden items-center gap-6 md:flex">
          {nav.map(([href, label]) => (
            <a
              key={href}
              href={href}
              className="label border-b border-transparent pb-0.5 text-ink-soft transition-colors hover:border-vermilion hover:text-vermilion"
            >
              {label}
            </a>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-3 md:ml-0">
          <span className="label hidden text-warmgrey lg:inline">Audit ledger</span>
          <span className="tnum border border-ink/30 px-2 py-1 text-[11px] leading-none">
            {String(ledger).padStart(4, "0")} entries
          </span>
          <span className="label bg-vermilion px-2 py-1.5 leading-none text-paper">
            Prototype · not a device
          </span>
        </div>
      </div>
    </header>
  );
}

export function SectionHead({
  index,
  kicker,
  title,
  lede,
  id,
}: {
  index: string;
  kicker: string;
  title: string;
  lede: string;
  id?: string;
}) {
  return (
    <div id={id} className="grid-paper border-y border-ink/25 bg-stock/60">
      <div className="mx-auto grid max-w-[1320px] gap-x-10 gap-y-4 px-5 py-10 md:grid-cols-[8rem_1fr_minmax(0,26rem)] md:py-14">
        <div className="label pt-2 text-vermilion">
          <span className="tnum block text-4xl leading-none text-ink/25">{index}</span>
          <span className="mt-2 block">{kicker}</span>
        </div>
        <h2 className="font-display text-5xl leading-[0.95] tracking-tight md:text-6xl">{title}</h2>
        <p className="max-w-[34rem] self-end text-[15px] leading-relaxed text-ink-soft">{lede}</p>
      </div>
    </div>
  );
}

export { Stamp } from "./ui";

export function Footer() {
  return (
    <footer className="border-t border-ink/25 bg-stock/70">
      <div className="mx-auto grid max-w-[1320px] gap-8 px-5 py-12 md:grid-cols-[1fr_auto]">
        <div className="flex gap-5">
          <Mark className="h-12 w-12 shrink-0 text-vermilion" />
          <div className="max-w-[46rem]">
            <p className="font-display text-2xl leading-tight">
              PulseNova AI — prescribing &amp; dosing counselling.
            </p>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">
              Formulary content follows WHO and ISSHP regimens for hypertensive disorders of
              pregnancy. Built by a five-student team from the B.Sc. Health Informatics cohort (2026)
              with a district maternal-health officer and two ANMs who tested every screen. Model
              code MIT licensed; the synthetic cohort, the validation harness and this page are
              CC BY-SA 4.0. Not affiliated with WHO or any regulator.
            </p>
          </div>
        </div>
        <div className="label space-y-2 text-warmgrey md:text-right">
          <p>pulsenova / 1.0.0</p>
          <p>Deterministic simulator v3</p>
          <p>Held-out n = 800</p>
          <p className="text-vermilion">No PHI leaves the handset</p>
        </div>
      </div>
    </footer>
  );
}
