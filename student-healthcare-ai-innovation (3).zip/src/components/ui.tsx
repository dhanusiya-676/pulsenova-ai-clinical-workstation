import type { ReactNode } from "react";

/* ───────────────────────────────────────────────────────────────
   PulseNova design system — primitives.
   Server-safe (no hooks) so they can be used from client and server
   components alike. State lives with the caller; these are pure view.
   ─────────────────────────────────────────────────────────────── */

export function Stamp({
  children,
  tone = "vermilion",
  className = "",
}: {
  children: ReactNode;
  tone?: "vermilion" | "clinic" | "ochre" | "ink";
  className?: string;
}) {
  const tones = {
    vermilion: "text-critical",
    clinic: "text-stable",
    ochre: "text-caution",
    ink: "text-ink",
  } as const;
  return (
    <span className={`stamp inline-block px-2.5 py-1.5 text-[10px] leading-none ${tones[tone]} ${className}`}>
      {children}
    </span>
  );
}

export function Panel({
  title,
  eyebrow,
  actions,
  children,
  className = "",
  tone = "plain",
}: {
  title?: string;
  eyebrow?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  tone?: "plain" | "console" | "alert";
}) {
  const tones = {
    plain: "bg-surface border-line-soft",
    console: "bg-console text-white border-console",
    alert: "bg-surface border-critical/50 ring-1 ring-critical/20",
  } as const;
  return (
    <section className={`rounded-xl border shadow-panel ${tones[tone]} ${className}`}>
      {(title || eyebrow || actions) && (
        <header className="flex flex-wrap items-end justify-between gap-3 border-b border-line-soft px-5 py-3.5">
          <div>
            {eyebrow && <p className="label text-brand">{eyebrow}</p>}
            {title && (
              <h2 className="mt-1 font-display text-[19px] font-semibold leading-tight tracking-tight">{title}</h2>
            )}
          </div>
          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className="px-5 py-4">{children}</div>
    </section>
  );
}

/** Primary / secondary / ghost action with press feedback. */
export function Btn({
  children,
  onClick,
  variant = "primary",
  disabled,
  type = "button",
  className = "",
  ariaLabel,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
  ariaLabel?: string;
}) {
  const styles = {
    primary:
      "bg-brand text-white hover:bg-brand-deep active:translate-y-px disabled:bg-line disabled:text-faint",
    secondary:
      "bg-surface text-ink border border-line hover:border-brand hover:text-brand active:translate-y-px disabled:opacity-50",
    ghost: "text-muted hover:bg-brand-soft hover:text-brand-deep active:translate-y-px disabled:opacity-50",
    danger:
      "bg-critical text-white hover:bg-critical-deep active:translate-y-px disabled:opacity-50",
  } as const;
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-[13px] font-semibold tracking-tight transition-all duration-150 ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

/** Big, calm number with a unit, a delta and an accessible text alternative. */
export function StatTile({
  label,
  value,
  unit,
  sub,
  tone = "neutral",
  icon,
}: {
  label: string;
  value: string;
  unit?: string;
  sub?: string;
  tone?: "neutral" | "critical" | "caution" | "stable" | "brand";
  icon?: ReactNode;
}) {
  const accent = {
    neutral: "text-ink",
    critical: "text-critical",
    caution: "text-caution",
    stable: "text-stable",
    brand: "text-brand-deep",
  } as const;
  const bar = {
    neutral: "bg-line",
    critical: "bg-critical",
    caution: "bg-caution",
    stable: "bg-stable",
    brand: "bg-brand",
  } as const;
  return (
    <div className="relative overflow-hidden rounded-xl border border-line-soft bg-surface px-4 py-3.5 shadow-panel">
      <span className={`absolute inset-y-0 left-0 w-1 ${bar[tone]}`} aria-hidden />
      <p className="label flex items-center gap-1.5 pl-1 text-faint">
        {icon}
        {label}
      </p>
      <p className={`tnum mt-1.5 pl-1 text-[30px] leading-none font-semibold tracking-tight ${accent[tone]}`}>
        {value}
        {unit && <span className="ml-1 text-[13px] font-medium text-faint">{unit}</span>}
      </p>
      {sub && <p className="mt-1.5 pl-1 text-[12px] leading-snug text-muted">{sub}</p>}
    </div>
  );
}

/** Point estimate with a 95% confidence whisker — replaces a bare percentage. */
export function ConfidenceBar({
  p,
  lo,
  hi,
  label,
  tone = "brand",
}: {
  p: number;
  lo: number;
  hi: number;
  label: string;
  tone?: "brand" | "critical" | "caution" | "stable";
}) {
  const pct = (x: number) => `${Math.max(0, Math.min(100, x * 100)).toFixed(1)}%`;
  const fill = {
    brand: "bg-brand",
    critical: "bg-critical",
    caution: "bg-caution",
    stable: "bg-stable",
  }[tone];
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="label text-muted">{label}</span>
        <span className="tnum text-[13px] font-semibold">
          {pct(p)}
          <span className="ml-1.5 text-[11px] font-normal text-faint">
            CI {pct(lo)}–{pct(hi)}
          </span>
        </span>
      </div>
      <div className="relative mt-2 h-2.5 rounded-full bg-line-soft">
        <div className={`rise h-full rounded-full ${fill}`} style={{ width: pct(p) }} />
        <span
          className="absolute top-1/2 h-4 w-px -translate-y-1/2 bg-ink/50"
          style={{ left: pct(lo) }}
          aria-hidden
        />
        <span
          className="absolute top-1/2 h-4 w-px -translate-y-1/2 bg-ink/50"
          style={{ left: pct(hi) }}
          aria-hidden
        />
        <span
          className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-surface bg-ink"
          style={{ left: pct(p) }}
          aria-hidden
        />
      </div>
    </div>
  );
}

/** Arc gauge with a settling needle and an uncertainty arc. */
export function RiskDial({
  value,
  lo,
  hi,
  title,
  caption,
  tone = "brand",
}: {
  value: number;
  lo: number;
  hi: number;
  title: string;
  caption?: string;
  tone?: "brand" | "critical" | "caution" | "stable";
}) {
  const color = {
    brand: "#1d4ed8",
    critical: "#d4111e",
    caution: "#b45309",
    stable: "#0d766e",
  }[tone];
  const cx = 110;
  const cy = 108;
  const r = 82;
  const a = (v: number) => Math.PI * (1 - Math.min(1, Math.max(0, v)));
  const pt = (v: number, rr = r) => `${cx + rr * Math.cos(a(v))} ${cy - rr * Math.sin(a(v))}`;
  const arc = (v0: number, v1: number, rr = r) =>
    `M ${pt(v0, rr)} A ${rr} ${rr} 0 ${v1 - v0 > 0.5 ? 1 : 0} 1 ${pt(v1, rr)}`;
  const deg = -180 + value * 180;

  return (
    <figure className="text-center">
      <svg viewBox="0 0 220 140" className="mx-auto w-full max-w-[260px]" role="img" aria-labelledby="dial-t">
        <title id="dial-t">
          {title}: {(value * 100).toFixed(1)} percent, 95 percent interval {(lo * 100).toFixed(1)} to{" "}
          {(hi * 100).toFixed(1)} percent
        </title>
        <path d={arc(0, 1)} fill="none" stroke="#e2e8f0" strokeWidth="16" strokeLinecap="round" />
        <path d={arc(Math.max(0, lo), Math.min(1, hi))} fill="none" stroke={color} strokeWidth="16" strokeLinecap="round" opacity="0.22" />
        <path d={arc(0, Math.max(0.005, value))} fill="none" stroke={color} strokeWidth="16" strokeLinecap="round" />
        <g
          className="needle-settle"
          style={{ ["--from" as string]: "-28deg", ["--to" as string]: `${deg}deg` }}
        >
          <line x1={cx} y1={cy} x2={cx} y2={cy - 58} stroke="#0f172a" strokeWidth="3" strokeLinecap="round" />
        </g>
        <circle cx={cx} cy={cy} r="7" fill="#0f172a" />
        {[0, 0.25, 0.5, 0.75, 1].map((t) => (
          <text
            key={t}
            x={cx + (r + 14) * Math.cos(a(t))}
            y={cy - (r + 14) * Math.sin(a(t)) + 4}
            textAnchor="middle"
            fontFamily="IBM Plex Mono"
            fontSize="9"
            fill="#64748b"
          >
            {t * 100}
          </text>
        ))}
      </svg>
      <figcaption>
        <p className="tnum -mt-2 text-[34px] leading-none font-semibold tracking-tight" style={{ color }}>
          {(value * 100).toFixed(1)}
          <span className="text-[15px]">%</span>
        </p>
        <p className="mt-1 text-[13px] font-medium">{title}</p>
        <p className="tnum mt-0.5 text-[11px] text-faint">
          95% CI {(lo * 100).toFixed(1)}–{(hi * 100).toFixed(1)}
        </p>
        {caption && <p className="mx-auto mt-2 max-w-[24ch] text-[12px] leading-snug text-muted">{caption}</p>}
      </figcaption>
    </figure>
  );
}

/** Sliding-underline segmented control (keyboard: arrow keys via native radios). */
export function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: { key: T; label: string; hint?: string }[];
  value: T;
  onChange: (v: T) => void;
  label: string;
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-1 rounded-xl bg-canvas p-1">
      {options.map((o) => {
        const on = o.key === value;
        return (
          <button
            key={o.key}
            role="radio"
            aria-checked={on}
            tabIndex={on ? 0 : -1}
            onClick={() => onChange(o.key)}
            className={`rounded-lg px-3.5 py-2 text-[12.5px] font-semibold tracking-tight transition-all duration-150 ${
              on
                ? "bg-surface text-brand-deep shadow-panel ring-1 ring-line-soft"
                : "text-muted hover:bg-surface/70 hover:text-ink"
            }`}
          >
            {o.label}
            {o.hint && <span className="ml-1.5 text-[10.5px] font-normal text-faint">{o.hint}</span>}
          </button>
        );
      })}
    </div>
  );
}

export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "critical" | "caution" | "stable" | "brand";
}) {
  const t = {
    neutral: "bg-canvas text-muted ring-line",
    critical: "bg-critical/10 text-critical-deep ring-critical/40",
    caution: "bg-caution/10 text-caution ring-caution/40",
    stable: "bg-stable/10 text-stable ring-stable/40",
    brand: "bg-brand-soft text-brand-deep ring-brand/30",
  }[tone];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold tracking-tight ring-1 ${t}`}>
      {children}
    </span>
  );
}

/** Red-flag guardrail banner — AAA contrast, never colour-only (icon + text). */
export function RedFlag({
  level,
  message,
  action,
}: {
  level: "red" | "amber" | "info";
  message: string;
  action: string;
}) {
  const map = {
    red: {
      box: "border-critical bg-critical/8",
      tag: "bg-critical text-white",
      text: "text-critical-deep",
      label: "Red flag",
    },
    amber: {
      box: "border-caution bg-caution/8",
      tag: "bg-caution text-white",
      text: "text-caution",
      label: "Caution",
    },
    info: {
      box: "border-info bg-info/8",
      tag: "bg-info text-white",
      text: "text-info",
      label: "Note",
    },
  }[level];
  return (
    <div className={`slip flex gap-3 rounded-lg border-l-4 ${map.box} px-4 py-3`}>
      <span className={`label h-fit shrink-0 rounded px-2 py-1 ${map.tag}`}>{map.label}</span>
      <div>
        <p className={`text-[13.5px] font-semibold leading-snug ${map.text}`}>{message}</p>
        <p className="mt-1 text-[12.5px] leading-snug text-muted">{action}</p>
      </div>
    </div>
  );
}

export function Field({
  label,
  value,
  onChange,
  unit,
  type = "number",
  placeholder,
  hint,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  unit?: string;
  type?: string;
  placeholder?: string;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="label text-muted">{label}</span>
      <span className="mt-1.5 flex items-center gap-2 rounded-lg border border-line bg-surface px-3 py-2 transition-colors focus-within:border-brand">
        <input
          type={type}
          value={value}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className="tnum w-full bg-transparent text-[15px] outline-none placeholder:text-faint/70"
        />
        {unit && <span className="label shrink-0 text-faint">{unit}</span>}
      </span>
      {hint && <span className="mt-1 block text-[11.5px] leading-snug text-faint">{hint}</span>}
    </label>
  );
}

export function Toggle({
  on,
  onChange,
  label,
  hint,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className="flex w-full items-start gap-3 rounded-lg px-1 py-1.5 text-left transition-colors hover:bg-canvas"
    >
      <span
        className={`mt-0.5 h-5 w-9 shrink-0 rounded-full p-0.5 transition-colors duration-200 ${
          on ? "bg-stable" : "bg-line"
        }`}
      >
        <span
          className={`block h-4 w-4 rounded-full bg-white shadow transition-transform duration-200 ${
            on ? "translate-x-4" : ""
          }`}
        />
      </span>
      <span>
        <span className="block text-[13px] font-semibold leading-tight">{label}</span>
        {hint && <span className="mt-0.5 block text-[11.5px] leading-snug text-faint">{hint}</span>}
      </span>
    </button>
  );
}

/** Screen-reader table backing every chart (WCAG 1.1.1 / AAA). */
export function ChartTable({ caption, rows }: { caption: string; rows: (string | number)[][] }) {
  return (
    <table className="sr-only">
      <caption>{caption}</caption>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i}>
            {r.map((c, j) => (
              <td key={j}>{c}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function CodeBlock({ title, code }: { title: string; code: string }) {
  return (
    <div className="overflow-hidden rounded-xl border border-console/25 bg-console">
      <p className="label border-b border-white/10 px-4 py-2.5 text-[#8fb6ff]">{title}</p>
      <pre className="overflow-x-auto px-4 py-3.5 text-[12px] leading-relaxed text-[#d7e3f8]">
        <code>{code}</code>
      </pre>
    </div>
  );
}
