"use client";

import { useMemo, useState } from "react";
import { AlertTriangle, Loader2, Radio } from "lucide-react";
import {
  BAND_META,
  DEFAULT_INPUTS,
  MODEL_VERSION,
  predict,
  type Band,
  type Inputs,
} from "@/lib/model";
import { Stamp } from "./ui";

type Posted = {
  auditId: string;
  referral: { id: number; facility: string; etaMinutes: number; cardRef: string; status: string } | null;
};

const SYMPTOMS: { key: keyof Inputs; label: string; note: string }[] = [
  { key: "headache", label: "Severe headache", note: "not relieved by paracetamol" },
  { key: "visual", label: "Visual disturbance", note: "flashing lights, blurring, spots" },
  { key: "epigastric", label: "Epigastric / RUQ pain", note: "burning, under the ribs" },
  { key: "chestPain", label: "Chest pain", note: "tightness or pain on breathing" },
  { key: "dyspnea", label: "Shortness of breath", note: "at rest or climbing one flight" },
  { key: "bleeding", label: "Vaginal bleeding", note: "any show after 20 weeks" },
  { key: "reducedFetal", label: "Reduced fetal movement", note: "less than 10 in 2 hours" },
  { key: "seizure", label: "Fit / seizure", note: "this visit or on the way" },
];

function Field({
  label,
  unit,
  value,
  onChange,
  min,
  max,
  step = 1,
  placeholder,
}: {
  label: string;
  unit: string;
  value: number | null;
  onChange: (n: number | null) => void;
  min: number;
  max: number;
  step?: number;
  placeholder?: string;
}) {
  return (
    <label className="rule-field flex items-baseline gap-3 py-2.5">
      <span className="label shrink-0 text-ink-soft">{label}</span>
      <span className="ml-auto flex items-baseline gap-2">
        <input
          type="number"
          className="tnum w-24 bg-transparent text-right text-lg outline-none placeholder:text-warmgrey/60 focus:text-vermilion"
          value={value ?? ""}
          min={min}
          max={max}
          step={step}
          placeholder={placeholder}
          onChange={(e) => {
            const raw = e.target.value;
            onChange(raw === "" ? null : Math.min(max, Math.max(min, Number(raw))));
          }}
        />
        <span className="label w-12 shrink-0 text-warmgrey">{unit}</span>
      </span>
    </label>
  );
}

export function Assessor() {
  const [v, setV] = useState<Inputs>(DEFAULT_INPUTS);
  const [posted, setPosted] = useState<Posted | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [contact, setContact] = useState({ name: "", phone: "", consent: true });

  const set = <K extends keyof Inputs>(k: K, val: Inputs[K]) => {
    setV((p) => ({ ...p, [k]: val }));
    setPosted(null);
    setError(null);
  };

  const r = useMemo(() => predict(v), [v]);
  const meta = BAND_META[r.band];
  const pct = r.risk * 100;
  const oneIn = Math.max(2, Math.round(1 / Math.max(r.risk, 0.0005)));
  const maxContrib = Math.max(...r.contributions.map((c) => Math.abs(c.contribution)), 0.35);

  async function record() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/assess", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ...v,
          contactName: contact.name,
          phone: contact.phone,
          consentToCall: contact.consent,
        }),
      });
      if (!res.ok) throw new Error("ledger unavailable");
      const data = (await res.json()) as Posted;
      setPosted(data);
    } catch {
      setError("Audit ledger unreachable — the risk reading above is still valid, but the referral was not dispatched. Call the facility on the toll-free line.");
    } finally {
      setBusy(false);
    }
  }

  const labFree = v.platelets === null || v.creatinine === null || v.ast === null;

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,23rem)_minmax(0,1fr)] lg:gap-14">
      {/* ── the record card ───────────────────────────────── */}
      <div className="lg:sticky lg:top-24 lg:self-start">
        <div className="grain relative border border-ink/35 bg-[#faf5ea] shadow-[6px_6px_0_rgba(22,33,31,0.1)]">
          <div className="flex items-start justify-between border-b border-ink/25 px-4 py-3">
            <div>
              <p className="label text-vermilion">Risk addendum</p>
              <p className="font-display text-xl leading-tight">Antenatal record card</p>
            </div>
            <span className="label tnum pt-1 text-warmgrey">{MODEL_VERSION}</span>
          </div>

          <dl className="grid grid-cols-2 gap-x-4 px-4 py-3 text-[13px]">
            {[
              ["Gestation", `${v.gestAge.toFixed(1)} wk`],
              ["Age / parity", `${v.age} y · P${v.parity}`],
              ["BP", `${v.sbp}/${v.dbp}`],
              ["SpO₂", `${v.spo2} %`],
              ["Platelets", v.platelets === null ? "—" : `${v.platelets}`],
              ["Creatinine", v.creatinine === null ? "—" : `${v.creatinine}`],
              ["AST", v.ast === null ? "—" : `${v.ast}`],
              ["Proteinuria", ["neg", "1+", "2+", "3+"][v.proteinuria]],
              ["Residence", v.rural ? "Rural" : "Urban"],
              ["Mode", labFree ? "Lab-free" : "Panel"],
            ].map(([k, val]) => (
              <div key={k} className="rule-field flex items-baseline justify-between py-1.5">
                <dt className="label text-warmgrey">{k}</dt>
                <dd className="tnum">{val}</dd>
              </div>
            ))}
          </dl>

          <div className="grid-fine relative min-h-[168px] border-t border-ink/25 px-4 py-5">
            <p className="label text-warmgrey">
              P(adverse maternal outcome ≤ 48 h)
            </p>
            <p className="tnum mt-1 text-[64px] leading-none tracking-tight" style={{ color: meta.hex }}>
              {pct < 10 ? pct.toFixed(1) : pct.toFixed(0)}
              <span className="text-2xl">%</span>
            </p>
            <p className="mt-1 text-[12.5px] text-ink-soft">
              about 1 in {oneIn} · {meta.window}
            </p>

            <div
              key={`${r.band}-${Math.round(r.risk * 1000)}`}
              className="stamp-drop absolute right-3 bottom-3 origin-center"
            >
              <div
                className="stamp px-3 py-2 text-center"
                style={{ color: meta.hex, transform: "rotate(-2deg)" }}
              >
                <span className="block text-[13px] font-semibold">{meta.label}</span>
                <span className="mt-1 block text-[9px] opacity-80">
                  {r.overridden ? "safety override" : `risk ${pct < 10 ? pct.toFixed(1) : pct.toFixed(0)}%`}
                </span>
              </div>
            </div>
          </div>
        </div>

        <p className="label mt-3 text-warmgrey">
          Card ref {posted?.referral?.cardRef ?? "ANM-···· / ——w·d"} · audit{" "}
          {posted?.auditId ?? "pending"}
        </p>
      </div>

      {/* ── the form, printed as a ruled sheet ────────────── */}
      <div className="grain relative border border-ink/25 bg-paper px-5 py-6 sm:px-8">
        <div className="flex flex-wrap items-baseline justify-between gap-3 border-b-2 border-ink pb-2">
          <h3 className="font-display text-3xl leading-none">The 40-second check</h3>
          <p className="label text-warmgrey">Sheet 1 of 1 · field triage</p>
        </div>

        <div className="grid gap-x-12 gap-y-8 pt-7 md:grid-cols-2">
          <section>
            <p className="label mb-2 text-vermilion">A · Observations</p>
            <label className="rule-field block py-2.5">
              <span className="label flex items-baseline justify-between text-ink-soft">
                Gestational age
                <span className="tnum text-lg text-ink">{v.gestAge.toFixed(1)} wk</span>
              </span>
              <input
                type="range"
                min={20}
                max={42}
                step={0.5}
                value={v.gestAge}
                onChange={(e) => set("gestAge", Number(e.target.value))}
                className="mt-3 w-full"
                aria-label="Gestational age in weeks"
              />
            </label>
            <Field label="Systolic BP" unit="mmHg" value={v.sbp} min={70} max={260} onChange={(n) => set("sbp", n ?? 120)} />
            <Field label="Diastolic BP" unit="mmHg" value={v.dbp} min={30} max={180} onChange={(n) => set("dbp", n ?? 80)} />
            <Field label="SpO₂ (room air)" unit="%" value={v.spo2} min={70} max={100} onChange={(n) => set("spo2", n ?? 98)} />
            <Field label="Maternal age" unit="yrs" value={v.age} min={12} max={55} onChange={(n) => set("age", n ?? 26)} />
            <Field label="Parity" unit="P" value={v.parity} min={0} max={8} onChange={(n) => set("parity", n ?? 1)} />

            <div className="mt-4 flex items-center gap-3">
              <span className="label text-ink-soft">Residence</span>
              <div className="ml-auto flex border border-ink/30">
                {[
                  [true, "Rural"],
                  [false, "Urban"],
                ].map(([val, lab]) => (
                  <button
                    key={String(val)}
                    type="button"
                    onClick={() => set("rural", val as boolean)}
                    className={`label px-3 py-2 transition-colors ${
                      v.rural === val ? "bg-ink text-paper" : "text-ink-soft hover:bg-stock"
                    }`}
                  >
                    {lab as string}
                  </button>
                ))}
              </div>
            </div>
          </section>

          <section>
            <p className="label mb-2 text-vermilion">B · Symptoms today</p>
            <ul>
              {SYMPTOMS.map((s) => {
                const on = v[s.key] as boolean;
                return (
                  <li key={s.key}>
                    <button
                      type="button"
                      onClick={() => set(s.key, !on as never)}
                      aria-pressed={on}
                      className={`rule-field flex w-full items-center gap-3 py-2.5 text-left transition-colors ${
                        on ? "bg-vermilion/8" : "hover:bg-stock/50"
                      }`}
                    >
                      <span
                        className={`grid h-4 w-4 shrink-0 place-items-center border ${
                          on ? "border-vermilion bg-vermilion" : "border-ink/40"
                        }`}
                      >
                        {on && (
                          <svg viewBox="0 0 10 10" className="h-2.5 w-2.5">
                            <path d="M1 5 L4 8 L9 1.5" fill="none" stroke="#F4EEE3" strokeWidth="2" />
                          </svg>
                        )}
                      </span>
                      <span className="leading-tight">
                        <span className="block text-[14px] font-medium">{s.label}</span>
                        <span className="block text-[11.5px] text-warmgrey">{s.note}</span>
                      </span>
                      {on && <span className="label ml-auto text-vermilion">flagged</span>}
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>

          <section>
            <p className="label mb-2 text-vermilion">C · Urine dipstick</p>
            <div className="flex border border-ink/30">
              {["neg", "1+", "2+", "3+"].map((lab, i) => (
                <button
                  key={lab}
                  type="button"
                  onClick={() => set("proteinuria", i as Inputs["proteinuria"])}
                  className={`label flex-1 py-3 transition-colors ${
                    v.proteinuria === i ? "bg-ink text-paper" : "text-ink-soft hover:bg-stock"
                  }`}
                >
                  {lab}
                </button>
              ))}
            </div>
            <p className="mt-2 text-[12px] leading-relaxed text-warmgrey">
              Protein/creatinine ratio if your unit has it; dipstick is acceptable at the doorstep.
            </p>
          </section>

          <section>
            <div className="mb-2 flex items-center justify-between">
              <p className="label text-vermilion">D · Bloods (optional)</p>
              <button
                type="button"
                onClick={() =>
                  labFree
                    ? (set("platelets", 210), set("creatinine", 68), set("ast", 29))
                    : (set("platelets", null), set("creatinine", null), set("ast", null))
                }
                className="label border border-ink/30 px-2 py-1.5 transition-colors hover:bg-stock"
              >
                {labFree ? "Enter panel" : "No lab this visit"}
              </button>
            </div>
            {labFree ? (
              <div className="border border-dashed border-ochre/60 bg-ochre/8 px-4 py-5">
                <p className="text-[13px] leading-relaxed text-ink-soft">
                  <span className="label text-ochre">Lab-free mode</span>
                  <br />
                  Missing values are imputed to normal-range priors and the handset states its wider
                  uncertainty honestly rather than guessing at liver or renal involvement.
                </p>
              </div>
            ) : (
              <>
                <Field label="Platelets" unit="×10⁹/L" value={v.platelets} min={20} max={600} onChange={(n) => set("platelets", n)} />
                <Field label="Creatinine" unit="µmol/L" value={v.creatinine} min={20} max={400} onChange={(n) => set("creatinine", n)} />
                <Field label="AST" unit="U/L" value={v.ast} min={5} max={500} onChange={(n) => set("ast", n)} />
              </>
            )}
          </section>
        </div>

        {/* E · who to call back */}
        <div className="mt-8 border-t-2 border-ink pt-5">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <p className="label text-vermilion">E · Call-back number</p>
            <span className="label text-warmgrey">Stored in the database against this referral</span>
          </div>
          <div className="mt-2 grid gap-x-12 sm:grid-cols-2">
            <label className="rule-field flex items-baseline gap-3 py-2.5">
              <span className="label shrink-0 text-ink-soft">Name</span>
              <input
                className="ml-auto w-44 bg-transparent text-right text-[15px] outline-none placeholder:text-warmgrey/60 focus:text-vermilion"
                placeholder="who answers the phone"
                value={contact.name}
                onChange={(e) => {
                  setContact((c) => ({ ...c, name: e.target.value }));
                  setPosted(null);
                }}
              />
            </label>
            <label className="rule-field flex items-baseline gap-3 py-2.5">
              <span className="label shrink-0 text-ink-soft">Mobile</span>
              <input
                type="tel"
                inputMode="tel"
                className="tnum ml-auto w-44 bg-transparent text-right text-[15px] outline-none placeholder:text-warmgrey/60 focus:text-vermilion"
                placeholder="10-digit number"
                value={contact.phone}
                onChange={(e) => {
                  setContact((c) => ({ ...c, phone: e.target.value }));
                  setPosted(null);
                }}
              />
            </label>
          </div>
          <button
            type="button"
            onClick={() => setContact((c) => ({ ...c, consent: !c.consent }))}
            aria-pressed={contact.consent}
            className="mt-3 flex w-full items-start gap-3 text-left"
          >
            <span
              className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center border ${
                contact.consent ? "border-clinic bg-clinic" : "border-ink/40"
              }`}
            >
              {contact.consent && (
                <svg viewBox="0 0 10 10" className="h-2.5 w-2.5">
                  <path d="M1 5 L4 8 L9 1.5" fill="none" stroke="#F4EEE3" strokeWidth="2" />
                </svg>
              )}
            </span>
            <span className="text-[12.5px] leading-relaxed text-ink-soft">
              She agrees to be called on this number by the referral desk and the receiving facility.
              The number is the only personal data EMBER stores; without the tick it is never written
              to the database — and without it, <span className="text-vermilion">nobody can call her back</span>.
            </span>
          </button>
          {r.band !== "ROUTINE" && !contact.phone.trim() && (
            <p className="mt-3 border-l-2 border-ochre bg-ochre/8 px-3 py-2 text-[12.5px] text-ochre">
              No number given — this referral will sit in the queue until a worker physically reaches
              her. Add the number to get the call-back.
            </p>
          )}
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-4 border-t-2 border-ink pt-5">
          <button
            type="button"
            onClick={record}
            disabled={busy}
            className="group flex items-center gap-3 bg-vermilion px-5 py-3.5 text-paper transition-colors hover:bg-deepred disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Radio className="h-4 w-4" />}
            <span className="label text-[11px]">Record &amp; dispatch referral</span>
          </button>
          <p className="max-w-[26rem] text-[12px] leading-relaxed text-warmgrey">
            Writes the feature vector to the append-only ledger and opens a referral at{" "}
            <span className="text-ink">
              {r.band === "EMERGENCY"
                ? "District Hospital"
                : v.rural
                  ? "CHC Bargaon"
                  : "SDH Kusunda"}
            </span>
            . Nothing else leaves this handset.
          </p>
        </div>

        {error && (
          <p className="slip mt-4 flex items-start gap-2 border-l-2 border-vermilion bg-vermilion/8 px-3 py-2 text-[13px] text-vermilion">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </p>
        )}
      </div>

      {/* ── verdict + explanation, full width ─────────────── */}
      <div className="grid gap-8 lg:col-span-2 lg:grid-cols-[minmax(0,1fr)_minmax(0,26rem)]">
        <div className="border border-ink/25 bg-paper px-5 py-6 sm:px-8">
          <p className="label text-warmgrey">What the handset says to do</p>
          <h4 className="mt-1 font-display text-3xl leading-tight" style={{ color: meta.hex }}>
            {meta.label}
          </h4>
          <p className="mt-3 max-w-[46rem] text-[15px] leading-relaxed">{meta.action}</p>

          {r.overridden && (
            <div className="slip mt-5 border border-vermilion bg-vermilion/10 px-4 py-3">
              <p className="label text-vermilion">Safety override — score cannot downgrade this</p>
              <ul className="mt-2 space-y-1 text-[13.5px] leading-relaxed">
                {r.dangerSigns.map((d) => (
                  <li key={d} className="flex gap-2">
                    <span className="text-vermilion">—</span>
                    {d}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-7">
            <p className="label text-warmgrey">Why — top contributions to the log-odds</p>
            <ul className="mt-3 space-y-1.5">
              {r.contributions.map((c) => {
                const w = (Math.abs(c.contribution) / maxContrib) * 46;
                const up = c.contribution > 0;
                return (
                  <li key={c.label} className="grid grid-cols-[minmax(0,11rem)_1fr_4.5rem] items-center gap-3">
                    <span className="truncate text-[13px]">{c.label}</span>
                    <span className="relative block h-3 bg-stock/70">
                      <span className="absolute inset-y-0 left-1/2 w-px bg-ink/25" />
                      <span
                        className="absolute inset-y-0"
                        style={{
                          width: `${w}%`,
                          left: up ? "50%" : `${50 - w}%`,
                          background: up ? "#C63A21" : "#0E6B5C",
                        }}
                      />
                    </span>
                    <span className="tnum text-right text-[12px] text-warmgrey">
                      {c.contribution > 0 ? "+" : ""}
                      {c.contribution.toFixed(2)}
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <aside className="flex flex-col gap-4 border border-ink/25 bg-stock/60 px-5 py-6">
          <div>
            <p className="label text-warmgrey">Audit trail</p>
            <p className="tnum mt-1 text-lg">{posted?.auditId ?? "— not yet recorded —"}</p>
            {posted?.referral && (
              <p className="slip mt-2 text-[13px] leading-relaxed">
                Referral <span className="tnum">#{posted.referral.id}</span> opened at{" "}
                <span className="font-medium">{posted.referral.facility}</span>
                {posted.referral.etaMinutes > 0 ? ` · transport ETA ${posted.referral.etaMinutes} min` : ""}.{" "}
                <a href="#workflow" className="text-vermilion underline underline-offset-2">
                  See the referral desk →
                </a>
              </p>
            )}
            <p className="mt-3 border-t border-ink/20 pt-3 text-[13px] leading-relaxed">
              <span className="label text-warmgrey">Call-back</span>
              <br />
              {contact.consent && contact.phone.trim() ? (
                <>
                  Desk dials{" "}
                  <a href={`tel:${contact.phone}`} className="tnum text-vermilion underline underline-offset-2">
                    {contact.phone}
                  </a>
                  {contact.name ? ` (${contact.name})` : ""} — number stored against this referral.
                </>
              ) : (
                <span className="text-warmgrey">
                  No call-back number recorded, so no one can ring her. Add one in section E.
                </span>
              )}
            </p>
          </div>
          <div className="border-t border-ink/20 pt-4">
            <Stamp tone="ink" className="mb-3">
              Not a diagnosis
            </Stamp>
            <p className="text-[12.5px] leading-relaxed text-ink-soft">
              EMBER estimates risk and recommends an escalation level. It does not diagnose
              pre-eclampsia, does not prescribe, and does not rule out disease when it returns a low
              score. A trained health worker may and must override it at any time. Follow your
              national protocol (WHO / ISSHP) for magnesium sulphate and antihypertensives.
            </p>
          </div>
          <div className="border-t border-ink/20 pt-4">
            <Stamp tone="clinic" className="mb-3">
              Human override always
            </Stamp>
            <Stamp tone="ochre">Emergency? Call 108 first</Stamp>
          </div>
        </aside>
      </div>
    </div>
  );
}

export type { Band };
