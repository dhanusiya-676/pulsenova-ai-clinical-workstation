"use client";

import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, FileText, Loader2, Upload } from "lucide-react";
import { Stamp } from "./ui";

type Meta = {
  id: number;
  createdAt: string;
  cardRef: string;
  kind: string;
  caption: string;
  fileName: string;
  mimeType: string;
  byteSize: number;
  sha256: string;
  reviewed: boolean;
};

const KINDS: { key: string; label: string; hint: string }[] = [
  { key: "ultrasound", label: "Ultrasound scan", hint: "growth scan, liquor, Doppler" },
  { key: "lab", label: "Lab report", hint: "CBC, LFT, creatinine, PCR" },
  { key: "fundus", label: "Fundus photo", hint: "retinal vessel changes" },
  { key: "pallor", label: "Conjunctival photo", hint: "anaemia / pallor grading" },
  { key: "report", label: "Discharge / referral note", hint: "paper the woman carries" },
  { key: "other", label: "Other clinical image", hint: "wound, oedema, rash" },
];

const kb = (n: number) => (n > 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.round(n / 1024)} KB`);

export function ImageStore({ cardRef }: { cardRef?: string }) {
  const [list, setList] = useState<Meta[] | null>(null);
  const [kind, setKind] = useState("ultrasound");
  const [ref, setRef] = useState(cardRef ?? "");
  const [caption, setCaption] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ tone: "ok" | "bad"; text: string } | null>(null);

  const load = useCallback(() => {
    fetch("/api/images")
      .then((r) => r.json())
      .then((d) => setList(d.images ?? []))
      .catch(() => setList([]));
  }, []);
  useEffect(load, [load]);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(file.type.startsWith("image/") ? url : null);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  async function upload(e: React.FormEvent) {
    e.preventDefault();
    if (!file) {
      setMsg({ tone: "bad", text: "Choose a photograph or a PDF report first." });
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("kind", kind);
      fd.append("cardRef", ref || "ANM-0000 / ——w·d");
      fd.append("caption", caption);
      const res = await fetch("/api/images", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "upload failed");
      setMsg({ tone: "ok", text: `Stored in the database as record #${data.image.id} · ${kb(data.image.byteSize)} · sha256 ${data.image.sha256.slice(0, 12)}…` });
      setFile(null);
      setCaption("");
      load();
    } catch (err) {
      setMsg({ tone: "bad", text: err instanceof Error ? err.message : "Upload failed" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)]">
      <form onSubmit={upload} className="grain relative border border-ink/25 bg-paper px-5 py-6">
        <p className="label text-vermilion">New upload</p>
        <h3 className="mt-1 font-display text-3xl leading-tight">Attach a clinical image</h3>
        <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">
          Photographed on the same phone. The bytes go straight into the district database with a
          SHA-256 fingerprint — never to a third-party host.
        </p>

        <label className="rule-field mt-5 flex items-baseline gap-3 py-2.5">
          <span className="label shrink-0 text-ink-soft">Booklet ref</span>
          <input
            className="tnum ml-auto w-40 bg-transparent text-right text-[15px] outline-none focus:text-vermilion"
            value={ref}
            onChange={(e) => setRef(e.target.value)}
            placeholder="ANM-4471 / 31w2d"
          />
        </label>

        <div className="mt-4">
          <p className="label mb-2 text-ink-soft">What is it?</p>
          <div className="grid grid-cols-2 gap-px bg-ink/15">
            {KINDS.map((k) => (
              <button
                key={k.key}
                type="button"
                onClick={() => setKind(k.key)}
                className={`px-3 py-2.5 text-left transition-colors ${
                  kind === k.key ? "bg-ink text-paper" : "bg-paper hover:bg-stock"
                }`}
              >
                <span className="block text-[13px] font-medium leading-tight">{k.label}</span>
                <span
                  className={`mt-0.5 block text-[10.5px] leading-tight ${
                    kind === k.key ? "text-paper/70" : "text-warmgrey"
                  }`}
                >
                  {k.hint}
                </span>
              </button>
            ))}
          </div>
        </div>

        <label className="rule-field mt-4 block py-2.5">
          <span className="label block text-ink-soft">Caption (optional)</span>
          <input
            className="mt-1 w-full bg-transparent text-[15px] outline-none focus:text-vermilion"
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="e.g. 32-week growth scan, AC below 5th centile"
          />
        </label>

        <label className="mt-4 flex cursor-pointer items-center gap-4 border border-dashed border-ink/40 px-4 py-5 transition-colors hover:border-vermilion">
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="selected preview" className="h-16 w-16 object-cover" />
          ) : (
            <span className="grid h-16 w-16 place-items-center bg-stock text-warmgrey">
              {file ? <FileText className="h-6 w-6" /> : <Upload className="h-6 w-6" />}
            </span>
          )}
          <span className="text-[13px] leading-snug">
            <span className="block font-medium">{file ? file.name : "Tap to choose a file"}</span>
            <span className="block text-warmgrey">
              {file ? `${kb(file.size)} · ${file.type || "binary"}` : "JPEG, PNG, HEIC or PDF · up to 8 MB"}
            </span>
          </span>
          <input
            type="file"
            accept="image/*,application/pdf"
            className="hidden"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          />
        </label>

        <button
          type="submit"
          disabled={busy}
          className="mt-5 flex w-full items-center justify-center gap-2 bg-vermilion px-5 py-3.5 text-paper transition-colors hover:bg-deepred disabled:opacity-60"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          <span className="label text-[11px]">Store in database</span>
        </button>

        {msg && (
          <p
            className={`slip mt-4 border-l-2 px-3 py-2 text-[13px] ${
              msg.tone === "ok" ? "border-clinic bg-clinic/8 text-clinic" : "border-vermilion bg-vermilion/8 text-vermilion"
            }`}
          >
            {msg.text}
          </p>
        )}
      </form>

      <div className="border border-ink/25 bg-paper">
        <div className="flex flex-wrap items-baseline justify-between gap-3 border-b-2 border-ink px-5 py-3">
          <h3 className="font-display text-3xl leading-tight">Stored images</h3>
          <p className="label tnum text-warmgrey">{list ? `${list.length} records` : "loading…"}</p>
        </div>

        {!list || list.length === 0 ? (
          <p className="label px-5 py-12 text-center text-warmgrey">
            {list ? "Nothing stored yet — upload the first record" : "Reading the store…"}
          </p>
        ) : (
          <ul className="divide-y divide-ink/15">
            {list
              .slice()
              .reverse()
              .map((im) => (
                <li key={im.id} className="flex gap-4 px-5 py-4">
                  <a
                    href={`/api/images/${im.id}`}
                    target="_blank"
                    rel="noreferrer"
                    className="grid h-24 w-24 shrink-0 place-items-center overflow-hidden border border-ink/20 bg-stock"
                  >
                    {im.mimeType.startsWith("image/") ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={`/api/images/${im.id}`}
                        alt={im.caption || im.fileName}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <FileText className="h-7 w-7 text-warmgrey" />
                    )}
                  </a>
                  <div className="min-w-0 flex-1">
                    <p className="flex flex-wrap items-center gap-2">
                      <Stamp tone={im.reviewed ? "clinic" : "ochre"}>
                        {(KINDS.find((k) => k.key === im.kind) ?? KINDS[5]).label}
                      </Stamp>
                      {im.reviewed && <span className="label text-clinic">reviewed</span>}
                    </p>
                    <p className="mt-2 truncate text-[14px]">{im.caption || im.fileName}</p>
                    <p className="tnum mt-1 truncate text-[11px] text-warmgrey">
                      #{im.id} · {im.cardRef} · {kb(im.byteSize)} · {im.mimeType} · sha{" "}
                      {im.sha256.slice(0, 10)}…
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      await fetch("/api/images", {
                        method: "PATCH",
                        headers: { "content-type": "application/json" },
                        body: JSON.stringify({ id: im.id, reviewed: !im.reviewed }),
                      });
                      load();
                    }}
                    className="label h-fit border border-ink/30 px-2.5 py-1.5 transition-colors hover:border-clinic hover:text-clinic"
                  >
                    {im.reviewed ? "Unmark" : "Mark reviewed"}
                  </button>
                </li>
              ))}
          </ul>
        )}

        <p className="border-t border-ink/25 px-5 py-3 text-[12px] leading-relaxed text-warmgrey">
          <CheckCircle2 className="mr-1 inline h-3.5 w-3.5 align-[-2px] text-clinic" />
          Stored as <span className="text-ink">bytea</span> in the district Postgres with an
          integrity hash, so a record can be proven unaltered. Nothing is deleted from the handset
          until the server confirms the write.
        </p>
      </div>
    </div>
  );
}
