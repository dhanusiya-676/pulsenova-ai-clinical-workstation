"use client";

import { useEffect, useState } from "react";
import { Activity, Braces, FileText, Fingerprint, HeartPulse, Image as ImageIcon, LayoutGrid, Mic, ScanFace, ShieldCheck, Signal, Stethoscope, Users, WifiOff } from "lucide-react";
import { Badge, Btn, Panel } from "./ui";
import { CardioAnalyzer, ImageAnalyzer, VoiceAnalyzer, type RunResult } from "./analyzers";
import { InteropPanel, ModalityCard, PeerReviewHub, PrivacyPanel, SoapPanel } from "./panels";
import { MODEL_REGISTRY } from "@/lib/codes";
import { ReferralDesk } from "./board";

type View = "dashboard" | "xray" | "derm" | "cardio" | "voice" | "soap" | "peer" | "field" | "privacy" | "interop";

const NAV: { group: string; items: { key: View; label: string; icon: React.ReactNode; shortcut: string }[] }[] = [
  {
    group: "Modalities",
    items: [
      { key: "xray", label: "Chest X-ray", icon: <ImageIcon className="h-4 w-4" />, shortcut: "1" },
      { key: "derm", label: "Dermoscopy", icon: <ScanFace className="h-4 w-4" />, shortcut: "2" },
      { key: "cardio", label: "Cardiometabolic", icon: <HeartPulse className="h-4 w-4" />, shortcut: "3" },
      { key: "voice", label: "Vocal prosody", icon: <Mic className="h-4 w-4" />, shortcut: "4" },
    ],
  },
  {
    group: "Workflow",
    items: [
      { key: "soap", label: "SOAP notes", icon: <FileText className="h-4 w-4" />, shortcut: "5" },
      { key: "peer", label: "Peer review", icon: <Users className="h-4 w-4" />, shortcut: "6" },
      { key: "field", label: "Field tracking", icon: <Signal className="h-4 w-4" />, shortcut: "7" },
    ],
  },
  {
    group: "Trust layer",
    items: [
      { key: "privacy", label: "Privacy & DP", icon: <ShieldCheck className="h-4 w-4" />, shortcut: "8" },
      { key: "interop", label: "FHIR & codes", icon: <Braces className="h-4 w-4" />, shortcut: "9" },
    ],
  },
];

const TITLES: Record<View, { eyebrow: string; title: string; lede: string }> = {
  dashboard: { eyebrow: "Workstation", title: "Good morning, Dr. Kujur", lede: "Four modalities, one workspace. Everything below runs on-device first and syncs only pseudonymous vectors." },
  xray: { eyebrow: "Multimodal · 01", title: "Chest radiograph interpretation", lede: "ViT-B/16 patch encoder with a 14-label head. Attention rollout overlays the study so the finding can be checked against what the model looked at." },
  derm: { eyebrow: "Multimodal · 02", title: "Dermoscopic lesion analysis", lede: "Swin-T transformer with ABCD descriptors. Confidence intervals widen on poor contact or hair-bearing sites — the interval is part of the answer." },
  cardio: { eyebrow: "Multimodal · 03", title: "Cardiometabolic risk assessment", lede: "A nine-coefficient logistic model you can audit term by term. Real inference, no black box, sub-millisecond." },
  voice: { eyebrow: "Multimodal · 04", title: "Vocal acoustic prosody", lede: "F0 contour, jitter, shimmer and HNR are extracted in the browser. Raw audio is destroyed on the spot — only eleven numbers are released." },
  soap: { eyebrow: "Workflow", title: "SOAP notes & export", lede: "Structured notes with automatic ICD-10/SNOMED mapping and an HL7 FHIR v4.0.1 export in one action." },
  peer: { eyebrow: "Workflow", title: "Student clinical peer-review hub", lede: "Your read against the model's read. Disagreement is the record that improves the system." },
  field: { eyebrow: "Workflow", title: "Offline-resilient field tracking", lede: "Referrals dispatched from the field queue, with call-back numbers and status receipts that survive a dead uplink." },
  privacy: { eyebrow: "Trust layer", title: "Zero-knowledge privacy & differential privacy", lede: "Scrubbing happens in this tab before a single byte is composed into a request." },
  interop: { eyebrow: "Trust layer", title: "Clinical interoperability", lede: "HL7 FHIR v4.0.1 bundles and versioned ICD-10-CM / SNOMED CT mapping." },
};

export function Workstation() {
  const [view, setView] = useState<View>("dashboard");
  const [online, setOnline] = useState(true);
  const [lastRun, setLastRun] = useState<RunResult | null>(null);
  const [queue, setQueue] = useState(0);

  useEffect(() => {
    setOnline(navigator.onLine);
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const target = e.target as HTMLElement;
      if (target && /input|textarea|select/i.test(target.tagName)) return;
      const hit = NAV.flatMap((g) => g.items).find((i) => i.shortcut === e.key);
      if (hit) {
        e.preventDefault();
        setView(hit.key);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    fetch("/api/soap")
      .then((r) => r.json())
      .then((d) => setQueue((d.notes ?? []).length))
      .catch(() => setQueue(0));
  }, [view]);

  const t = TITLES[view];

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[248px_minmax(0,1fr)]">
      {/* ── command rail ─────────────────────────────────── */}
      <aside className="on-console sticky top-0 z-30 border-b border-white/10 bg-console text-white lg:h-screen lg:border-b-0 lg:border-r lg:border-white/10">
        <div className="flex items-center gap-3 px-5 py-4">
          <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" role="img" aria-label="PulseNova AI">
            <rect x="1.5" y="1.5" width="37" height="37" rx="10" fill="none" stroke="#4d8dff" strokeWidth="1.5" />
            <path d="M5 21 H13 L16 12 L21 29 L25 21 H35" fill="none" stroke="#7fd1c8" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <div className="leading-none">
            <p className="font-display text-[17px] font-bold tracking-tight">PulseNova AI</p>
            <p className="label mt-1 text-[#8fb6ff]">clinical workstation</p>
          </div>
        </div>

        <nav className="chip-row flex gap-1 overflow-x-auto px-3 pb-3 lg:block lg:overflow-visible lg:pb-6" aria-label="Workstation sections">
          <button
            type="button"
            onClick={() => setView("dashboard")}
            className={`flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-semibold transition-colors lg:mb-4 lg:w-full ${view === "dashboard" ? "bg-white/12 text-white" : "text-[#b9cbe4] hover:bg-white/8 hover:text-white"}`}
          >
            <LayoutGrid className="h-4 w-4" /> Overview
          </button>
          {NAV.map((g) => (
            <div key={g.group} className="lg:mb-4">
              <p className="label hidden px-3 pb-1.5 text-[#5f7ba6] lg:block">{g.group}</p>
              <div className="flex gap-1 lg:block lg:space-y-0.5">
                {g.items.map((it) => (
                  <button
                    key={it.key}
                    type="button"
                    onClick={() => setView(it.key)}
                    aria-current={view === it.key ? "page" : undefined}
                    className={`flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-semibold transition-all duration-150 lg:w-full ${view === it.key ? "bg-brand text-white" : "text-[#b9cbe4] hover:bg-white/8 hover:text-white"}`}
                  >
                    {it.icon}
                    <span className="whitespace-nowrap">{it.label}</span>
                    <kbd className="label ml-auto hidden rounded border border-white/20 px-1 py-0.5 text-[9px] text-[#8fb6ff] lg:block">
                      {it.shortcut}
                    </kbd>
                  </button>
                ))}
              </div>
            </div>
          ))}
          <a
            href="/prescription"
            className="flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-semibold text-[#b9cbe4] transition-colors hover:bg-white/8 hover:text-white lg:w-full"
          >
            <Stethoscope className="h-4 w-4" /> Prescriptions
          </a>
          <a
            href="/design"
            className="flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-semibold text-[#b9cbe4] transition-colors hover:bg-white/8 hover:text-white lg:w-full"
          >
            <Fingerprint className="h-4 w-4" /> Design system
          </a>
        </nav>
      </aside>

      {/* ── workspace ────────────────────────────────────── */}
      <div className="min-w-0">
        <header className="sticky top-0 z-20 border-b border-line-soft bg-canvas/90 backdrop-blur">
          <div className="flex flex-wrap items-center gap-3 px-5 py-3 sm:px-8">
            <div className="min-w-0">
              <p className="label text-brand">{t.eyebrow}</p>
              <h1 className="truncate font-display text-[22px] font-bold tracking-tight">{t.title}</h1>
            </div>
            <div className="ml-auto flex flex-wrap items-center gap-2">
              <Badge tone="neutral">session SN-DEMO</Badge>
              <Badge tone="neutral">booklet ANM-4471 / 31w2d</Badge>
              <Badge tone="stable">
                <ShieldCheck className="h-3 w-3" /> PII scrubbed
              </Badge>
              <Badge tone={online ? "brand" : "caution"}>
                {online ? <Activity className="h-3 w-3 live-dot" /> : <WifiOff className="h-3 w-3" />}
                {online ? "syncing" : `offline · ${queue} queued`}
              </Badge>
              <Btn variant="primary" onClick={() => setView("soap")}>
                New note
              </Btn>
            </div>
          </div>
          <p className="border-t border-line-soft px-5 py-2 text-[12.5px] leading-relaxed text-muted sm:px-8">
            {t.lede}
          </p>
        </header>

        <main className="px-5 py-6 sm:px-8">
          {view === "dashboard" && (
            <div className="space-y-6">
              <section>
                <p className="label mb-2.5 text-muted">Multimodal analyzers · press 1–4 to switch without leaving the case</p>
                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                  <ModalityCard shortcut="1" icon={<ImageIcon className="h-4 w-4" />} title="Chest X-ray" arch={MODEL_REGISTRY.xray.architecture} auc={MODEL_REGISTRY.xray.auc} latency={MODEL_REGISTRY.xray.latency} onClick={() => setView("xray")} />
                  <ModalityCard shortcut="2" icon={<ScanFace className="h-4 w-4" />} title="Dermoscopy" arch={MODEL_REGISTRY.derm.architecture} auc={MODEL_REGISTRY.derm.auc} latency={MODEL_REGISTRY.derm.latency} onClick={() => setView("derm")} />
                  <ModalityCard shortcut="3" icon={<HeartPulse className="h-4 w-4" />} title="Cardiometabolic" arch={MODEL_REGISTRY.cardio.architecture} auc={MODEL_REGISTRY.cardio.auc} latency={MODEL_REGISTRY.cardio.latency} onClick={() => setView("cardio")} />
                  <ModalityCard shortcut="4" icon={<Mic className="h-4 w-4" />} title="Vocal prosody" arch={MODEL_REGISTRY.voice.architecture} auc={MODEL_REGISTRY.voice.auc} latency={MODEL_REGISTRY.voice.latency} onClick={() => setView("voice")} />
                </div>
              </section>

              <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,24rem)]">
                <Panel eyebrow="Start here" title="Cardiometabolic assessment — the commonest desk request">
                  <CardioAnalyzer onRun={setLastRun} />
                </Panel>
                <div className="space-y-4">
                  <Panel eyebrow="Last run" title={lastRun ? lastRun.runId : "nothing yet"}>
                    {lastRun ? (
                      <>
                        <p className="text-[13.5px] font-semibold">{lastRun.top.label}</p>
                        <p className="tnum mt-1 text-[13px] text-muted">
                          {(lastRun.top.p * 100).toFixed(1)}% (95% CI {(lastRun.top.ci[0] * 100).toFixed(1)}–{(lastRun.top.ci[1] * 100).toFixed(1)}%)
                        </p>
                        <p className="mt-3 text-[12.5px] leading-relaxed text-muted">
                          {lastRun.guardrails.length} guardrail{lastRun.guardrails.length === 1 ? "" : "s"} evaluated ·{" "}
                          {lastRun.findings.reduce((n, f) => n + f.codes.length, 0)} codes mapped
                        </p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          <Btn variant="secondary" onClick={() => setView("soap")}>
                            <FileText className="h-4 w-4" /> Document
                          </Btn>
                          <Btn variant="secondary" onClick={() => setView("peer")}>
                            <Users className="h-4 w-4" /> Peer review
                          </Btn>
                        </div>
                      </>
                    ) : (
                      <p className="text-[13px] leading-relaxed text-muted">
                        Run any analyzer and its verdict, uncertainty and codes appear here, ready to
                        document or export.
                      </p>
                    )}
                  </Panel>
                  <Panel eyebrow="Safety" title="Guardrails are always on">
                    <ul className="space-y-2 text-[12.5px] leading-relaxed text-muted">
                      <li>Red-flag rules run before, during and after inference — a model score can never quiet one.</li>
                      <li>Every result carries its 95% interval; a wide interval lowers urgency rather than hiding it.</li>
                      <li>Nothing is written to the patient record without a clinician confirming it.</li>
                    </ul>
                  </Panel>
                </div>
              </div>
            </div>
          )}

          {view === "xray" && <ImageAnalyzer kind="xray" />}
          {view === "derm" && <ImageAnalyzer kind="derm" />}
          {view === "cardio" && <CardioAnalyzer onRun={setLastRun} />}
          {view === "voice" && <VoiceAnalyzer onRun={setLastRun} />}
          {view === "soap" && <SoapPanel seed={{ assessment: lastRun?.top.label }} />}
          {view === "peer" && <PeerReviewHub aiRead={lastRun ? `${lastRun.top.label} — ${(lastRun.top.p * 100).toFixed(1)}%` : undefined} />}
          {view === "field" && <ReferralDesk />}
          {view === "privacy" && <PrivacyPanel />}
          {view === "interop" && <InteropPanel lastRunId={lastRun?.runId ?? null} />}
        </main>

        <footer className="border-t border-line-soft px-5 py-6 text-[12px] leading-relaxed text-faint sm:px-8">
          PulseNova AI · prototype decision support, not a medical device. Imaging heads are simulated
          on the input hash in this build; the cardiometabolic and acoustic heads are real inference.
          Keyboard 1–9 switch tools without dropping the case context.
        </footer>
      </div>
    </div>
  );
}
