"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Braces, Copy, Download, FileText, Fingerprint, ShieldCheck, Users } from "lucide-react";
import { Badge, Btn, Field, Panel, RedFlag, StatTile, Toggle } from "./ui";

/* ── privacy: zero-knowledge PII scrubbing + differential privacy ─── */

const PII_RULES: { name: string; re: RegExp; sub: string }[] = [
  { name: "Indian mobile", re: /\b(?:\+91[- ]?)?[6-9]\d{9}\b/g, sub: "[PHONE]" },
  { name: "e-mail", re: /[\w.+-]+@[\w-]+\.[\w.]+/g, sub: "[EMAIL]" },
  { name: "Aadhaar", re: /\b\d{4}[ -]?\d{4}[ -]?\d{4}\b/g, sub: "[AADHAAR]" },
  { name: "NHS / MRN", re: /\b(?:NHS|MRN|UHID)[- :]*\d{6,10}\b/gi, sub: "[MRN]" },
  { name: "date of birth", re: /\b\d{1,2}[/-]\d{1,2}[/-](?:19|20)\d{2}\b/g, sub: "[DATE]" },
  { name: "long date", re: /\b\d{4}-\d{2}-\d{2}\b/g, sub: "[DATE]" },
  { name: "proper name (heuristic)", re: /\b(?:Mr|Mrs|Ms|Smt|Sri|Dr)\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?/g, sub: "[NAME]" },
  { name: "address line", re: /\b\d{1,3}\s+[A-Z][a-z]+\s+(?:Road|Rd|Lane|Nagar|Colony|Street)\b/g, sub: "[ADDRESS]" },
];

export function scrub(text: string) {
  let out = text;
  const hits: { name: string; count: number }[] = [];
  for (const r of PII_RULES) {
    const n = (out.match(r.re) ?? []).length;
    if (n) hits.push({ name: r.name, count: n });
    out = out.replace(r.re, r.sub);
  }
  return { out, hits };
}

export function PrivacyPanel() {
  const [raw, setRaw] = useState(
    "Mrs. Sunita Oraon, DOB 14/03/1991, mobile 9834120977, UHID-4471201.\nLives at 12 Gandhi Road, Bargaon. Contact: su.oraon@example.com\nAadhaar 4471 2019 8823. Referred for BP 168/112 at 31 weeks.",
  );
  const [dp, setDp] = useState(true);
  const [eps, setEps] = useState("0.8");
  const [counts, setCounts] = useState<{ modality: string; n: number }[]>([]);

  useEffect(() => {
    fetch("/api/analyze")
      .then((r) => r.json())
      .then((d) => {
        const map = new Map<string, number>();
        for (const a of d.analyses ?? []) map.set(a.modality, (map.get(a.modality) ?? 0) + 1);
        setCounts([...map.entries()].map(([modality, n]) => ({ modality, n })));
      })
      .catch(() => setCounts([]));
  }, []);

  const { out, hits } = useMemo(() => scrub(raw), [raw]);

  const noisy = useCallback(
    (n: number) => {
      if (!dp) return n;
      const e = Math.max(0.05, Number(eps) || 0.1);
      const u = Math.random() - 0.5;
      const noise = -(1 / e) * Math.sign(u) * Math.log(1 - 2 * Math.abs(u));
      return Math.max(0, Math.round(n + noise));
    },
    [dp, eps],
  );

  return (
    <div className="grid gap-4 xl:grid-cols-2">
      <Panel eyebrow="Zero-knowledge client-side scrubbing" title="PII never leaves the device">
        <p className="text-[13px] leading-relaxed text-muted">
          Free text is scrubbed in the browser before any request is made. Try it — the report below
          contains real-shaped identifiers.
        </p>
        <label className="mt-3 block">
          <span className="label text-muted">Raw dictation / report</span>
          <textarea
            rows={5}
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-line bg-surface px-3 py-2 text-[13px] outline-none transition-colors focus:border-brand"
          />
        </label>
        <div className="mt-3 rounded-lg border border-line-soft bg-canvas px-3 py-2.5">
          <p className="label text-stable">What is transmitted</p>
          <pre className="mt-1.5 whitespace-pre-wrap text-[12.5px] leading-relaxed">{out}</pre>
        </div>
        <ul className="mt-3 flex flex-wrap gap-2">
          {hits.length === 0 ? (
            <li>
              <Badge tone="stable">no identifiers detected</Badge>
            </li>
          ) : (
            hits.map((h) => (
              <li key={h.name}>
                <Badge tone="caution">
                  {h.name} × {h.count}
                </Badge>
              </li>
            ))
          )}
        </ul>
      </Panel>

      <div className="space-y-4">
        <Panel eyebrow="Differential privacy" title="Noisy aggregates only" actions={<Badge tone={dp ? "stable" : "neutral"}>{dp ? `ε = ${eps}` : "noise off"}</Badge>}>
          <Toggle on={dp} onChange={setDp} label="Laplace mechanism on every aggregate" hint="Turn it off to see how much the raw counts reveal." />
          <label className="mt-3 block">
            <span className="label text-muted">Privacy budget ε (lower = stronger)</span>
            <input
              type="range"
              min={0.1}
              max={4}
              step={0.1}
              value={eps}
              onChange={(e) => setEps(e.target.value)}
              className="mt-2 w-full"
              aria-label="Privacy budget epsilon"
            />
          </label>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {counts.map((c) => (
              <StatTile key={c.modality} label={`${c.modality} runs`} value={String(noisy(c.n))} sub={dp ? "released with Laplace noise" : "raw count — not releasable"} tone={dp ? "stable" : "critical"} />
            ))}
            {counts.length === 0 && <p className="label text-faint">no runs recorded yet</p>}
          </div>
          <p className="mt-3 text-[11.5px] leading-snug text-faint">
            Composition over k queries consumes k·ε of the quarterly budget (ε = 1.6 total). Images,
            audio and identifiers are never released in any form.
          </p>
        </Panel>
        <Panel eyebrow="Threat model" title="What an attacker gets from each layer">
          <ul className="space-y-2 text-[13px] leading-relaxed text-muted">
            <li><strong className="text-ink">Lost handset</strong> — encrypted store only; keys in StrongBox, never in the app sandbox.</li>
            <li><strong className="text-ink">Compromised relay</strong> — pseudonymous booklet codes and feature vectors; no names, no linkage.</li>
            <li><strong className="text-ink">Malicious insider</strong> — hash-chained audit ledger makes bulk export loud and provable.</li>
          </ul>
        </Panel>
      </div>
    </div>
  );
}

/* ── interoperability: FHIR + terminology ─────────────────────────── */

export function InteropPanel({ lastRunId }: { lastRunId: string | null }) {
  const [bundle, setBundle] = useState<Record<string, unknown> | null>(null);
  const [copied, setCopied] = useState(false);
  const [modality, setModality] = useState("cardio");

  async function build() {
    const res = await fetch("/api/fhir", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ runId: lastRunId, modality, sessionId: "SN-DEMO", patientRef: "ANM-4471 / 31w2d" }),
    });
    setBundle(await res.json());
  }

  const rows = bundle ? ((bundle as { entry?: { resource: Record<string, unknown> }[] }).entry ?? []) : [];

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,26rem)]">
      <Panel
        eyebrow="HL7 FHIR v4.0.1"
        title="Bundle builder"
        actions={
          <>
            <Btn variant="secondary" onClick={build}>
              <Braces className="h-4 w-4" /> Build bundle
            </Btn>
            <Btn
              variant="ghost"
              onClick={() => {
                if (!bundle) return;
                navigator.clipboard.writeText(JSON.stringify(bundle, null, 2));
                setCopied(true);
                setTimeout(() => setCopied(false), 1600);
              }}
            >
              <Copy className="h-4 w-4" /> {copied ? "Copied" : "Copy"}
            </Btn>
          </>
        }
      >
        <div className="mb-3 flex flex-wrap items-center gap-2">
          {["cardio", "xray", "derm", "voice"].map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setModality(m)}
              className={`label rounded-md px-2.5 py-1.5 transition-colors ${modality === m ? "bg-brand text-white" : "bg-canvas text-muted hover:text-ink"}`}
            >
              {m}
            </button>
          ))}
          {lastRunId && <Badge tone="brand">last run {lastRunId}</Badge>}
        </div>
        {bundle ? (
          <div className="overflow-x-auto rounded-lg border border-console/25 bg-console">
            <pre className="max-h-[440px] overflow-auto px-4 py-3 text-[11.5px] leading-relaxed text-[#d7e3f8]">
              {JSON.stringify(bundle, null, 2)}
            </pre>
          </div>
        ) : (
          <div className="grid-fine flex h-[300px] items-center justify-center rounded-lg border border-dashed border-line">
            <p className="label text-faint">build a bundle to see the resources</p>
          </div>
        )}
        <p className="mt-3 text-[12px] leading-relaxed text-muted">
          Resources emitted: {rows.length ? rows.map((r) => String((r.resource as { resourceType?: string }).resourceType)).join(" · ") : "Patient, DiagnosticReport, Observation×n, Flag×n"}. Patient carries a
          single pseudonymous identifier — no name, birthDate, telecom or address fields exist in the serializer.
        </p>
      </Panel>

      <Panel eyebrow="Terminology" title="ICD-10-CM / SNOMED CT auto-map">
        <ul className="space-y-2.5 text-[13px]">
          {[
            ["J18.9", "233604007", "Pneumonia, unspecified organism"],
            ["J90", "557003", "Pleural effusion"],
            ["C43.9", "372244006", "Malignant melanoma of skin"],
            ["I10", "59621000", "Essential hypertension"],
            ["E78.5", "55822004", "Hyperlipidaemia"],
            ["R47.1", "40780006", "Dysarthria"],
          ].map(([icd, snomed, display]) => (
            <li key={icd} className="border-b border-line-soft pb-2">
              <p className="flex items-center gap-2">
                <Badge tone="brand">ICD-10 {icd}</Badge>
                <Badge tone="neutral">SNOMED {snomed}</Badge>
              </p>
              <p className="mt-1 text-muted">{display}</p>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-[11.5px] leading-snug text-faint">
          Mapping table is versioned with the model; ambiguous terms are emitted as text-only
          CodeableConcept rather than a wrong code.
        </p>
      </Panel>
    </div>
  );
}

/* ── SOAP note builder ────────────────────────────────────────────── */

export function SoapPanel({ seed }: { seed?: { assessment?: string; objective?: string } }) {
  const [f, setF] = useState({ cardRef: "ANM-4471 / 31w2d", subjective: "", objective: "", assessment: "", plan: "" });
  const [saved, setSaved] = useState<{ id: number; cardRef: string; createdAt: string; assessment: string; codes: { code: string; system: string }[] }[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (seed) setF((p) => ({ ...p, assessment: seed.assessment ?? p.assessment, objective: seed.objective ?? p.objective }));
  }, [seed]);

  useEffect(() => {
    fetch("/api/soap")
      .then((r) => r.json())
      .then((d) => setSaved(d.notes ?? []))
      .catch(() => setSaved([]));
  }, []);

  async function save(format: "store" | "fhir") {
    const res = await fetch("/api/soap", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...f, sessionId: "SN-DEMO", modality: "cardio", format }),
    });
    const data = await res.json();
    if (!res.ok) return setMsg(data.error ?? "could not save");
    setMsg(
      format === "fhir"
        ? `Saved and serialised to FHIR — ${data.codes.length} codes mapped`
        : `Saved to the record — ${data.codes.length} codes auto-mapped`,
    );
    setSaved((p) => [data.note, ...p]);
    if (format === "fhir") {
      const blob = new Blob([JSON.stringify(data.bundle, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `soap-${data.note.id}.fhir.json`;
      a.click();
      URL.revokeObjectURL(a.href);
    }
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,24rem)]">
      <Panel eyebrow="Clinical documentation" title="SOAP note">
        <div className="grid gap-3">
          <Field label="Booklet ref" value={f.cardRef} onChange={(x) => setF((p) => ({ ...p, cardRef: x }))} type="text" />
          {(["subjective", "objective", "assessment", "plan"] as const).map((k) => (
            <label key={k} className="block">
              <span className="label text-muted">{k[0].toUpperCase() + k.slice(1)}</span>
              <textarea
                rows={k === "subjective" ? 3 : 2}
                value={f[k]}
                onChange={(e) => setF((p) => ({ ...p, [k]: e.target.value }))}
                placeholder={
                  k === "subjective"
                    ? "In her words — complaint, duration, what changed."
                    : k === "objective"
                      ? "Observations, vitals, examination, study quality."
                      : k === "assessment"
                        ? "Working diagnosis and the differential behind it."
                        : "What happens next, and by when."
                }
                className="mt-1.5 w-full rounded-lg border border-line bg-surface px-3 py-2 text-[13.5px] outline-none transition-colors focus:border-brand"
              />
            </label>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-2 border-t border-line-soft pt-3">
          <Btn variant="primary" onClick={() => save("store")}>
            <FileText className="h-4 w-4" /> Save note
          </Btn>
          <Btn variant="secondary" onClick={() => save("fhir")}>
            <Download className="h-4 w-4" /> Save + FHIR export
          </Btn>
          {msg && <span className="slip self-center text-[12.5px] text-stable">{msg}</span>}
        </div>
      </Panel>

      <Panel eyebrow="Recent notes" title="Stored in the record">
        {saved.length === 0 ? (
          <p className="label text-faint">no notes yet</p>
        ) : (
          <ul className="space-y-2.5">
            {saved.slice(0, 6).map((n) => (
              <li key={n.id} className="border-b border-line-soft pb-2 text-[12.5px]">
                <p className="flex items-center justify-between">
                  <span className="tnum font-semibold">#{n.id} · {n.cardRef}</span>
                  <span className="text-faint">{new Date(n.createdAt).toLocaleTimeString()}</span>
                </p>
                <p className="mt-0.5 line-clamp-2 text-muted">{n.assessment || "—"}</p>
                <p className="mt-1 flex flex-wrap gap-1">
                  {n.codes.slice(0, 3).map((c, i) => (
                    <Badge key={i} tone="neutral">{c.code}</Badge>
                  ))}
                </p>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}

/* ── student clinical peer-review hub ─────────────────────────────── */

export function PeerReviewHub({ aiRead }: { aiRead?: string }) {
  const [reviews, setReviews] = useState<{ id: number; runId: string; caseTitle: string; modality: string; aiRead: string; studentRead: string; disposition: string; reviewer: string; status: string }[] | null>(null);
  const [f, setF] = useState({ caseTitle: "", studentRead: "", reviewer: "", disposition: "agree" });
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(() => {
    fetch("/api/reviews")
      .then((r) => r.json())
      .then((d) => setReviews(d.reviews ?? []))
      .catch(() => setReviews([]));
  }, []);
  useEffect(load, [load]);

  async function submit() {
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        runId: "PN-DEMO01",
        caseTitle: f.caseTitle || "Untitled teaching case",
        modality: "cardio",
        aiRead: aiRead ?? "Model read not attached",
        studentRead: f.studentRead,
        reviewer: f.reviewer || "Anonymous student",
        disposition: f.disposition,
      }),
    });
    const data = await res.json();
    setMsg(res.ok ? "Submitted to the faculty queue" : (data.error ?? "could not submit"));
    setF((p) => ({ ...p, caseTitle: "", studentRead: "" }));
    load();
  }

  const tone = (d: string) => (d === "escalate" ? "critical" : d === "disagree" ? "caution" : "stable") as "critical" | "caution" | "stable";

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,24rem)_minmax(0,1fr)]">
      <Panel eyebrow="Learning loop" title="Submit your read">
        <p className="text-[13px] leading-relaxed text-muted">
          Disagreement with the model is the most valuable record we keep. Faculty review every
          <strong className="text-ink"> escalate</strong> case within 48 hours.
        </p>
        <div className="mt-3 grid gap-3">
          <Field label="Case title" value={f.caseTitle} onChange={(x) => setF((p) => ({ ...p, caseTitle: x }))} type="text" placeholder="e.g. 31w2d, headache, BP 168/112" />
          <label className="block">
            <span className="label text-muted">Your interpretation</span>
            <textarea
              rows={4}
              value={f.studentRead}
              onChange={(e) => setF((p) => ({ ...p, studentRead: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-line bg-surface px-3 py-2 text-[13.5px] outline-none transition-colors focus:border-brand"
              placeholder="What do you think is going on, and what would you do?"
            />
          </label>
          <Field label="Your name / roll no." value={f.reviewer} onChange={(x) => setF((p) => ({ ...p, reviewer: x }))} type="text" />
          <div className="flex flex-wrap gap-2">
            {["agree", "escalate", "disagree"].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setF((p) => ({ ...p, disposition: d }))}
                aria-pressed={f.disposition === d}
                className={`label rounded-md px-3 py-2 transition-colors ${f.disposition === d ? "bg-ink text-white" : "bg-canvas text-muted hover:text-ink"}`}
              >
                {d}
              </button>
            ))}
          </div>
          <Btn variant="primary" onClick={submit} disabled={!f.studentRead.trim()}>
            <Users className="h-4 w-4" /> Send to faculty queue
          </Btn>
          {msg && <p className="slip text-[12.5px] text-stable">{msg}</p>}
        </div>
      </Panel>

      <Panel eyebrow="Peer-review hub" title="Cases under discussion" actions={<Badge tone="brand">{reviews?.length ?? 0} cases</Badge>}>
        {!reviews || reviews.length === 0 ? (
          <p className="label text-faint">no cases yet</p>
        ) : (
          <ul className="space-y-3">
            {reviews.map((r) => (
              <li key={r.id} className="rounded-lg border border-line-soft bg-canvas/60 px-4 py-3">
                <p className="flex flex-wrap items-center gap-2">
                  <Badge tone={tone(r.disposition)}>{r.disposition}</Badge>
                  <span className="text-[13.5px] font-semibold">{r.caseTitle}</span>
                  <span className="label ml-auto text-faint">{r.status} · {r.reviewer}</span>
                </p>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">{r.studentRead}</p>
                <p className="mt-1 text-[11.5px] text-faint">AI read: {r.aiRead}</p>
                {r.status === "OPEN" && (
                  <Btn
                    variant="ghost"
                    className="mt-2"
                    onClick={async () => {
                      await fetch("/api/reviews", {
                        method: "PATCH",
                        headers: { "content-type": "application/json" },
                        body: JSON.stringify({ id: r.id, status: "REVIEWED" }),
                      });
                      load();
                    }}
                  >
                    <ShieldCheck className="h-4 w-4" /> Mark faculty-reviewed
                  </Btn>
                )}
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}

export function GuardrailLedger({ guardrails }: { guardrails: { level: string; message: string; action: string }[] }) {
  return (
    <div className="space-y-2">
      {guardrails.length === 0 ? (
        <p className="label text-faint">no guardrail fired on this run</p>
      ) : (
        guardrails.map((g, i) => (
          <RedFlag key={i} level={g.level as "red" | "amber" | "info"} message={g.message} action={g.action} />
        ))
      )}
    </div>
  );
}

export function ModalityCard({
  icon,
  title,
  arch,
  auc,
  latency,
  onClick,
  shortcut,
}: {
  icon: React.ReactNode;
  title: string;
  arch: string;
  auc: number;
  latency: string;
  onClick: () => void;
  shortcut: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex items-start gap-3 rounded-xl border border-line-soft bg-surface px-4 py-3.5 text-left shadow-panel transition-all duration-200 hover:-translate-y-0.5 hover:border-brand hover:shadow-lift"
    >
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-brand-soft text-brand-deep transition-colors group-hover:bg-brand group-hover:text-white">
        {icon}
      </span>
      <span className="min-w-0">
        <span className="flex items-center gap-2">
          <span className="font-display text-[15px] font-semibold tracking-tight">{title}</span>
          <kbd className="label rounded border border-line px-1 py-0.5 text-[9px] text-faint">{shortcut}</kbd>
        </span>
        <span className="mt-0.5 block truncate text-[12px] text-muted">{arch}</span>
        <span className="tnum mt-1 block text-[11px] text-faint">AUC {auc.toFixed(3)} · {latency}</span>
      </span>
    </button>
  );
}

export { Fingerprint };
