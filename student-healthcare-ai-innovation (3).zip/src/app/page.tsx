import { Workstation } from "@/components/workstation";

export const dynamic = "force-dynamic";

export default function Page() {
  return <Workstation />;
}
