import { Footer, Masthead, SectionHead, Stamp } from "@/components/chrome";
import { PrescriptionBuilder } from "@/components/prescription";

export const dynamic = "force-dynamic";

const STEPS = [
  ["01", "Read the chart out loud", "Point at the dots on the grid as you say the time. Most women who 'forget' were never told when."],
  ["02", "Say where", "Home, facility, or labour room only. Anything in the labour-room row is not hers to carry — it is given by a nurse."],
  ["03", "Name the food rule", "Empty stomach, after food, or never with tea and iron tablets. Say the reason once and she will repeat it to her mother-in-law."],
  ["04", "Say what happens if missed", "Four rules, printed. Vomiting within 30 minutes counts as a missed dose."],
  ["05", "Write the review date", "A chart with no return date is advice. A chart with one is a plan."],
];

export default function PrescriptionPage() {
  return (
    <div id="top">
      <Masthead />

      <section className="grid-paper relative overflow-hidden border-b border-ink/25">
        <div className="relative mx-auto max-w-[1320px] px-5 py-14 md:py-20">
          <p className="label text-vermilion">
            <a href="/" className="underline underline-offset-2">
              ← PulseNova AI workstation
            </a>{" "}
            · prescription &amp; dosing counselling
          </p>
          <h1 className="mt-5 max-w-[24ch] font-display text-[clamp(2.4rem,5vw,4.4rem)] leading-[0.92] tracking-tight">
            When, and <span className="italic text-vermilion">where</span>, to take it.
          </h1>
          <p className="mt-6 max-w-[44rem] text-[16px] leading-relaxed text-ink-soft">
            Most treatment failures in hypertensive disorders of pregnancy are not prescribing
            errors — they are <em>timing</em> errors. This page writes the prescription, prints the
            chart the woman tapes to her wall, and stores both in the database so the nurse on night
            duty can read exactly what she was told.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            <Stamp tone="vermilion">Prescriber signature required</Stamp>
            <Stamp tone="clinic">Counselling aid</Stamp>
            <Stamp tone="ochre">Never a substitute for clinical judgement</Stamp>
          </div>
        </div>
      </section>

      <SectionHead
        id="chart"
        index="01"
        kicker="Prescription builder"
        title="Write it, print it, store it"
        lede="Pick from the EMBER formulary and the dosing grid fills itself: clock slots, relation to food, and — the part everyone forgets — where the dose is actually given."
      />
      <section className="mx-auto max-w-[1320px] px-5 py-14">
        <PrescriptionBuilder />
      </section>

      <SectionHead
        index="02"
        kicker="Counselling script"
        title="Five sentences at the door"
        lede="The chart only works if it is said out loud. This is the script the ANMs who tested the tool use, in the order they say it."
      />
      <section className="mx-auto max-w-[1320px] px-5 py-14">
        <ol className="divide-y divide-ink/20 border-y border-ink/20">
          {STEPS.map(([n, h, p]) => (
            <li key={n} className="grid gap-x-8 gap-y-2 py-7 sm:grid-cols-[4rem_18rem_1fr]">
              <span className="tnum text-3xl leading-none text-vermilion">{n}</span>
              <h3 className="font-display text-2xl leading-tight">{h}</h3>
              <p className="max-w-[44rem] text-[14.5px] leading-relaxed text-ink-soft">{p}</p>
            </li>
          ))}
        </ol>
        <p className="mt-8 max-w-[52rem] text-[13px] leading-relaxed text-warmgrey">
          Formulary content follows WHO and ISSHP regimens for hypertensive disorders of pregnancy.
          Doses here are for adult pregnancy at term and must be adjusted for weight, renal function
          and local protocol by the prescriber. Nothing on this page issues a medicine: a chart
          cannot be saved without a prescriber name and registration number.
        </p>
      </section>

      <Footer />
    </div>
  );
}
