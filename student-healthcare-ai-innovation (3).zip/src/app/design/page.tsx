import { Badge, Btn, ChartTable, CodeBlock, ConfidenceBar, Panel, RedFlag, RiskDial, StatTile } from "@/components/ui";

export const dynamic = "force-dynamic";

const TOKENS = [
  ["--color-console", "#0a1628", "Command rail, code surfaces. Deep navy = institutional trust without going dark-mode."],
  ["--color-canvas", "#eef2f7", "Workspace. Cool slate so white panels read as objects, not as the page."],
  ["--color-brand", "#1d4ed8", "The only interactive blue. AAA against white (7.4:1)."],
  ["--color-critical", "#d4111e", "Reserved for red-flag guardrails and urgent findings. Never decorative."],
  ["--color-caution", "#b45309", "Amber-brown rather than yellow: 5.1:1 on white, AA-large/AAA-large compliant."],
  ["--color-stable", "#0d766e", "Verified / normal. Teal reads calmer than green under ward lighting."],
  ["--font-display", "Space Grotesk", "Headings. Technical grotesque with quirk — never Inter."],
  ["--font-sans", "IBM Plex Sans", "Body. Humanist, superb at 12–14px where clinical UI actually lives."],
  ["--font-mono", "IBM Plex Mono", "Every number, code and identifier. Tabular figures align in columns."],
];

const SNIPPETS: [string, string][] = [
  [
    "tailwind.config / CSS theme tokens (Tailwind v4)",
    `@import "tailwindcss";

@theme {
  --color-console: #0a1628;
  --color-canvas:  #eef2f7;
  --color-brand:   #1d4ed8;
  --color-critical:#d4111e;
  --color-stable:  #0d766e;
  --font-display:  "Space Grotesk", system-ui, sans-serif;
  --font-mono:     "IBM Plex Mono", ui-monospace, monospace;
  --shadow-panel:  0 1px 2px rgb(15 23 42 / .06), 0 8px 24px -12px rgb(15 23 42 / .18);
}

/* AAA focus — never remove, only restyle */
:where(a, button, input, [tabindex]):focus-visible {
  outline: 3px solid var(--color-brand);
  outline-offset: 2px;
  box-shadow: 0 0 0 6px rgb(29 78 216 / .18);
}`,
  ],
  [
    "components/ui/Panel.tsx — the only container you need",
    `export function Panel({ eyebrow, title, actions, children, tone = "plain" }) {
  const tones = {
    plain:   "bg-surface border-line-soft",
    console: "bg-console text-white border-console",
    alert:   "bg-surface border-critical/50 ring-1 ring-critical/20",
  };
  return (
    <section className={\`rounded-xl border shadow-panel \${tones[tone]}\`}>
      <header className="flex flex-wrap items-end justify-between gap-3
                         border-b border-line-soft px-5 py-3.5">
        <div>
          <p className="label text-brand">{eyebrow}</p>
          <h2 className="mt-1 font-display text-[19px] font-semibold tracking-tight">{title}</h2>
        </div>
        {actions}
      </header>
      <div className="px-5 py-4">{children}</div>
    </section>
  );
}`,
  ],
  [
    "AppShell.tsx — layout that cuts cognitive load",
    `// 3 zones: command rail (persistent) → verdict header (sticky) → workbench
<div className="min-h-screen lg:grid lg:grid-cols-[248px_minmax(0,1fr)]">
  <CommandRail />          {/* dark, stable, shortcuts 1–9, never scrolls away */}
  <div className="min-w-0">
    <header className="sticky top-0 z-20 bg-canvas/90 backdrop-blur">
      <CaseBar />            {/* session · booklet · privacy chips · connectivity */}
      <p className="text-[12.5px] text-muted">{lede}</p>  {/* one line of guidance */}
    </header>
    <main className="px-5 py-6 sm:px-8">
      {/* input 26rem | result fluid  — fixed input width stops controls drifting */}
      <div className="grid gap-4 xl:grid-cols-[minmax(0,26rem)_minmax(0,1fr)]">
        <InputPanel />
        <ResultStage />
      </div>
    </main>
  </div>
</div>`,
  ],
  [
    "ResultStage.tsx — verdict first, everything else folded",
    `{/* 1. one number the clinician can act on, with its interval in the title */}
<RiskDial value={top.p} lo={top.ci[0]} hi={top.ci[1]} title={top.label} />

{/* 2. three tiles only: certainty, urgency, study quality */}
<div className="grid gap-3 sm:grid-cols-3">
  <StatTile label="Certainty" value={confidence * 100} unit="%" tone="brand" />
  <StatTile label="Urgency"  value={urgency}            tone={tone} />
  <StatTile label="Quality"  value={quality}            tone="stable" />
</div>

{/* 3. differential + 95% whiskers, capped at five rows */}
{findings.slice(0, 5).map((f) => (
  <ConfidenceBar key={f.label} label={f.label} p={f.p} lo={f.ci[0]} hi={f.ci[1]} />
))}

{/* 4. guardrails cannot be dismissed — they are state, not toasts */}
{guardrails.map((g) => <RedFlag level={g.level} message={g.message} action={g.action} />)}`,
  ],
  [
    "ConfidenceBar.tsx — interval as a first-class element",
    `export function ConfidenceBar({ label, p, lo, hi, tone = "brand" }) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="label text-muted">{label}</span>
        <span className="tnum text-[13px] font-semibold">
          {(p * 100).toFixed(1)}%
          <span className="text-[11px] font-normal text-faint">
            CI {(lo * 100).toFixed(1)}–{(hi * 100).toFixed(1)}%
          </span>
        </span>
      </div>
      <div className="relative mt-2 h-2.5 rounded-full bg-line-soft">
        <div className="rise h-full rounded-full bg-brand" style={{ width: \`\${p * 100}%\` }} />
        {/* whiskers: cheap, honest uncertainty */}
        <span className="absolute top-1/2 h-4 w-px bg-ink/50" style={{ left: \`\${lo * 100}%\` }} />
        <span className="absolute top-1/2 h-4 w-px bg-ink/50" style={{ left: \`\${hi * 100}%\` }} />
      </div>
    </div>
  );
}`,
  ],
  [
    "a11y.ts — WCAG AAA checklist baked into components",
    `// 1. every chart ships a text alternative (1.1.1)
<ChartTable caption="Ranked findings" rows={findings.map((f) => [f.label, f.p])} />

// 2. results announce to screen readers (4.1.3 status messages)
<div role="status" aria-live="polite" aria-atomic="true">{verdict}</div>

// 3. colour is never the only signal (1.4.1) — icon + word accompany every tone
<RedFlag level="red" message="…">  // “Red flag” label + rule, not red alone

// 4. 7:1 body contrast (1.4.6): ink #0f172a on canvas #eef2f7 = 14.6:1
// 5. motion is decorative and fully parked (2.3.3)
@media (prefers-reduced-motion: reduce) { * { animation: none !important } }`,
  ],
  [
    "micro-interactions.css — 150–400 ms, one direction, no bounce loops",
    `@keyframes slip { from { opacity: 0; transform: translateY(8px) } to { opacity: 1 } }
.slip     { animation: slip 320ms cubic-bezier(.2,.7,.2,1) both }   /* results in */

@keyframes sweep { to { transform: translateY(108%) } }
.scan-sweep { animation: sweep 1100ms linear infinite }              /* inference */

@keyframes settle { 0% { transform: rotate(-28deg) } 70% { transform: rotate(calc(var(--to) + 3deg)) } }
.needle-settle { animation: settle 900ms cubic-bezier(.2,.8,.25,1) both } /* dial */

/* every button: 1px press, 150ms */
.btn { transition: all 150ms ease-out }
.btn:active { transform: translateY(1px) }`,
  ],
];

export default function DesignPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-line-soft bg-console text-white">
        <div className="mx-auto max-w-[1180px] px-6 py-12">
          <p className="label text-[#8fb6ff]">
            <a href="/" className="underline underline-offset-2">
              ← back to the workstation
            </a>{" "}
            · PulseNova AI design system v1.0
          </p>
          <h1 className="mt-4 max-w-[20ch] font-display text-[clamp(2.2rem,4.5vw,3.6rem)] font-bold leading-[0.95] tracking-tight">
            A console for high-stress decisions
          </h1>
          <p className="mt-5 max-w-[62ch] text-[15.5px] leading-relaxed text-[#c6d6ec]">
            The redesign keeps every existing capability — four analyzers, privacy architecture,
            interoperability, guardrails, prescriptions, SOAP, peer review and field tracking — and
            changes only how they are arranged, sized, animated and spoken about. Three rules govern
            every screen: <strong className="text-white">one verdict first</strong>,{" "}
            <strong className="text-white">uncertainty always visible</strong>,{" "}
            <strong className="text-white">safety never dismissible</strong>.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-[1180px] space-y-10 px-6 py-10">
        <section className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,360px)]">
          <Panel eyebrow="Component live-fire" title="Every primitive, rendered">
            <div className="grid gap-4 sm:grid-cols-3">
              <StatTile label="10-year risk" value="21.4" unit="%" sub="pooled-cohort form" tone="critical" />
              <StatTile label="Certainty" value="88" unit="%" sub="inverse CI width" tone="brand" />
              <StatTile label="Study quality" value="GOOD" sub="diagnostic quality" tone="stable" />
            </div>
            <div className="mt-4 grid gap-4 sm:grid-cols-[220px_minmax(0,1fr)]">
              <RiskDial value={0.37} lo={0.28} hi={0.47} title="Melanoma" tone="critical" caption="Swin-T dermoscopy head" />
              <div className="space-y-3.5">
                <ConfidenceBar label="Benign melanocytic naevus" p={0.42} lo={0.35} hi={0.5} />
                <ConfidenceBar label="Melanoma" p={0.37} lo={0.28} hi={0.47} tone="critical" />
                <ConfidenceBar label="Basal cell carcinoma" p={0.14} lo={0.08} hi={0.22} tone="caution" />
              </div>
            </div>
            <div className="mt-4 space-y-2">
              <RedFlag level="red" message="Melanoma at 37% — this finding must not be deferred" action="Refer for excisional biopsy within 2 weeks. Do not enter 3-month surveillance." />
              <RedFlag level="amber" message="Diabetes modifies the treatment threshold" action="Treat as high risk regardless of the calculated percentage." />
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Btn variant="primary">Primary action</Btn>
              <Btn variant="secondary">Secondary</Btn>
              <Btn variant="danger">Escalate</Btn>
              <Btn variant="ghost">Ghost</Btn>
              <Badge tone="brand">ICD-10 C43.9</Badge>
              <Badge tone="stable">verified</Badge>
            </div>
            <ChartTable caption="sample" rows={[["a", 1]]} />
          </Panel>

          <Panel eyebrow="Palette" title="Clinical trust, safety accents">
            <ul className="space-y-2.5">
              {TOKENS.map(([token, value, note]) => (
                <li key={token} className="border-b border-line-soft pb-2">
                  <p className="flex items-center gap-2">
                    <span className="h-4 w-4 rounded-sm border border-line" style={{ background: value.startsWith("#") ? value : "transparent" }} />
                    <code className="tnum text-[12px] font-semibold">{token}</code>
                    <span className="tnum ml-auto text-[11px] text-faint">{value}</span>
                  </p>
                  <p className="mt-1 text-[12px] leading-snug text-muted">{note}</p>
                </li>
              ))}
            </ul>
          </Panel>
        </section>

        <section>
          <h2 className="font-display text-[26px] font-bold tracking-tight">Component-by-component redesign</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {[
              ["Multimodal analyzers", "Merge into one workspace with a persistent case bar. A single 26rem input column never moves between modalities; only its fields change. Keyboard 1–4 switches the head without dropping the case."],
              ["Risk score & confidence", "Replace percentage cards with an arc dial (needle settles) plus interval whiskers on every bar. The CI is printed next to the number — never behind a tooltip."],
              ["Acoustic graphs", "Waveform and F0 contour on a light plot grid with an sr-only table of samples. A 12-bar level meter beside the record button tells the user the mic is alive."],
              ["Red-flag guardrails", "From toast to permanent component: level chip + what happened + what to do. They sit above results and cannot be dismissed, only acknowledged by action."],
              ["FHIR / terminology", "Bundle builder with a monospace preview on the console surface, resource chips, and copy-to-clipboard. Codes appear beside the finding that produced them."],
              ["Prescription schedules", "Kept intact; restyled onto the same Panel/StatTile set with the dot-grid clock chart and the print-only `.print-area` card."],
              ["SOAP note export", "Four-field progressive disclosure with placeholder guidance in clinical voice, and a one-click Save + FHIR export."],
              ["Peer-review hub", "Disposition chips (agree / escalate / disagree) colour-coded but always worded, with an AI-vs-student read pairing."],
              ["Field tracking", "Unchanged behaviour, calmer table: status advances one step per click, missing call-back numbers flagged amber with inline fix."],
              ["Privacy & DP", "A live scrubber you can type into, plus an ε slider that visibly changes released counts — the policy becomes a toy you can feel."],
              ["Navigation", "One rail, three groups, one page, sticky case bar. Nothing is more than one click away and nothing loses case context."],
              ["Motion", "150ms state changes, 320ms result slip-in, 900ms dial settle. All parked under prefers-reduced-motion."],
            ].map(([h, p]) => (
              <article key={h} className="rounded-xl border border-line-soft bg-surface px-5 py-4 shadow-panel">
                <h3 className="font-display text-[16px] font-semibold tracking-tight">{h}</h3>
                <p className="mt-2 text-[13px] leading-relaxed text-muted">{p}</p>
              </article>
            ))}
          </div>
        </section>

        <section>
          <h2 className="font-display text-[26px] font-bold tracking-tight">Tailwind / shadcn snippets</h2>
          <p className="mt-2 max-w-[70ch] text-[14px] leading-relaxed text-muted">
            Drop-in code for the pieces that carry the redesign. The primitives above are plain
            Tailwind — the same shapes map 1:1 onto shadcn/ui (<code className="tnum">Card</code>,{" "}
            <code className="tnum">Badge</code>, <code className="tnum">Switch</code>,{" "}
            <code className="tnum">Tabs</code>) by swapping the class strings into{" "}
            <code className="tnum">cva</code> variants.
          </p>
          <div className="mt-5 grid gap-5 xl:grid-cols-2">
            {SNIPPETS.map(([title, code]) => (
              <CodeBlock key={title} title={title} code={code} />
            ))}
          </div>
        </section>

        <section className="rounded-xl border border-line-soft bg-surface px-6 py-5 shadow-panel">
          <h2 className="font-display text-[22px] font-bold tracking-tight">Accessibility contract (WCAG AAA)</h2>
          <ul className="mt-3 grid gap-2 text-[13.5px] leading-relaxed text-muted sm:grid-cols-2">
            <li>Body text contrast 14.6:1; muted text 8.2:1 — both clear AAA (7:1).</li>
            <li>Focus rings are 3px with a halo, in the brand blue (white-on-console gets amber).</li>
            <li>Every chart has a <code className="tnum">ChartTable</code> text alternative; every gauge carries a full sentence in <code className="tnum">&lt;title&gt;</code>.</li>
            <li>Results are announced with <code className="tnum">role=&quot;status&quot;</code> and <code className="tnum">aria-live=&quot;polite&quot;</code>.</li>
            <li>Tone is never load-bearing: level chip + word + rule accompany every colour.</li>
            <li>Targets are ≥ 44px tall on the rail and ≥ 40px in tables; shortcuts are also reachable by Tab.</li>
            <li>Motion is purely decorative and fully disabled under <code className="tnum">prefers-reduced-motion</code>.</li>
            <li>Forms use real labels; toggles are <code className="tnum">role=&quot;switch&quot;</code> with <code className="tnum">aria-checked</code>.</li>
          </ul>
          <div className="mt-4 flex items-start gap-3">
            <span className="mt-0.5 h-5 w-9 shrink-0 rounded-full bg-stable p-0.5" aria-hidden>
              <span className="block h-4 w-4 translate-x-4 rounded-full bg-white shadow" />
            </span>
            <span>
              <span className="block text-[13px] font-semibold leading-tight">
                Reduced motion is respected automatically
              </span>
              <span className="mt-0.5 block text-[11.5px] leading-snug text-faint">
                The operating-system setting is the single source of truth for every animation.
              </span>
            </span>
          </div>
        </section>
      </main>

      <footer className="border-t border-line-soft px-6 py-8 text-center text-[12px] text-faint">
        PulseNova AI design system · deep navy and slate for trust, one blue for action, three safety
        accents held in reserve for clinical meaning only.
      </footer>
    </div>
  );
}
