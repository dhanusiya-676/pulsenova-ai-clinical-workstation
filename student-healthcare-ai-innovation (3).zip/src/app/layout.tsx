import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PulseNova AI — multimodal clinical workstation",
  description:
    "Chest X-ray, dermoscopy, cardiometabolic and vocal-prosody analyzers with clinical guardrails, zero-knowledge privacy, HL7 FHIR v4.0.1 export and ICD-10/SNOMED-CT auto-mapping.",
  keywords: ["multimodal AI", "medical imaging", "FHIR", "clinical decision support", "differential privacy"],
};

export const viewport: Viewport = {
  themeColor: "#0a1628",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600;700&family=Instrument+Serif:ital@0;1&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
