import { NextResponse } from "next/server";
import { createHash } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses, medicalImages } from "@/db/schema";
import { analyse, MODEL_REGISTRY } from "@/lib/codes";
import type { AnalysisInput, CardioInput, VoiceFeatures } from "@/lib/codes";

export const dynamic = "force-dynamic";

function runCode() {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += A.charAt(Math.floor(Math.random() * A.length));
  return "PN-" + s;
}

export async function GET() {
  const rows = await db.select().from(analyses).orderBy(analyses.createdAt);
  return NextResponse.json({ analyses: rows });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const modality = String(body.modality ?? "cardio") as AnalysisInput["modality"];
  if (!MODEL_REGISTRY[modality])
    return NextResponse.json({ error: "unknown modality" }, { status: 400 });

  const input: AnalysisInput = { modality };
  const features: Record<string, number> = {};
  let inputRef: string | null = null;
  let contentHash = String(body.seed ?? "pulse-nova");

  if ((modality === "xray" || modality === "derm") && body.imageId) {
    const rows = await db.select().from(medicalImages).where(eq(medicalImages.id, Number(body.imageId)));
    const img = rows[0];
    if (!img) return NextResponse.json({ error: "image not found" }, { status: 404 });
    contentHash = img.sha256;
    inputRef = `imaging/${img.id}`;
  } else if (modality === "voice" && body.voice) {
    const v = body.voice as VoiceFeatures;
    input.voice = {
      f0Mean: Number(v.f0Mean) || 0,
      f0Sd: Number(v.f0Sd) || 0,
      jitter: Number(v.jitter) || 0,
      shimmer: Number(v.shimmer) || 0,
      hnr: Number(v.hnr) || 0,
      rate: Number(v.rate) || 0,
      pauseRatio: Number(v.pauseRatio) || 0,
      rms: Number(v.rms) || 0,
    };
    Object.assign(features, input.voice);
    contentHash = createHash("sha256").update(JSON.stringify(input.voice)).digest("hex");
    inputRef = `acoustic/${contentHash.slice(0, 12)}`;
  } else if (modality === "cardio") {
    const c = body.cardio as CardioInput;
    input.cardio = {
      age: Number(c.age) || 50,
      sex: c.sex === "male" ? "male" : "female",
      sbp: Number(c.sbp) || 130,
      totalChol: Number(c.totalChol) || 200,
      hdl: Number(c.hdl) || 50,
      smoker: !!c.smoker,
      diabetes: !!c.diabetes,
      bmi: Number(c.bmi) || 25,
    };
    Object.assign(features, input.cardio as unknown as Record<string, number>);
  }

  if (body.vitals) {
    input.vitals = {
      sbp: Number(body.vitals.sbp) || 0,
      dbp: Number(body.vitals.dbp) || 0,
      hr: Number(body.vitals.hr) || 0,
      spo2: Number(body.vitals.spo2) || 100,
    };
    Object.assign(features, input.vitals);
  }

  const out = analyse(input);
  const runId = runCode();

  await db.insert(analyses).values({
    runId,
    modality,
    sessionId: String(body.sessionId ?? "SN-DEMO"),
    topLabel: out.top.label,
    probability: out.top.p,
    ciLow: out.top.ci[0],
    ciHigh: out.top.ci[1],
    urgency: out.top.urgency,
    codes: out.findings.slice(0, 5).flatMap((f) => f.codes),
    guardrails: out.guardrails,
    featureVector: features,
    modelVersion: out.model.version,
    inputRef,
  });

  return NextResponse.json({ runId, ...out }, { status: 201 });
}
