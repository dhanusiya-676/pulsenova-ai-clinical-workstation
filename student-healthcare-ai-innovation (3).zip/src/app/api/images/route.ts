import { NextResponse } from "next/server";
import { createHash } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { medicalImages } from "@/db/schema";

export const dynamic = "force-dynamic";

const MAX_BYTES = 8 * 1024 * 1024;
export const KINDS = ["ultrasound", "lab", "fundus", "pallor", "report", "other"] as const;

/** Metadata only — bytes are served from /api/images/[id]. */
function meta(row: {
  id: number;
  createdAt: Date;
  cardRef: string;
  kind: string;
  caption: string;
  fileName: string;
  mimeType: string;
  byteSize: number;
  sha256: string;
  reviewed: boolean;
  auditId: string | null;
}) {
  return {
    id: row.id,
    createdAt: row.createdAt,
    cardRef: row.cardRef,
    kind: row.kind,
    caption: row.caption,
    fileName: row.fileName,
    mimeType: row.mimeType,
    byteSize: row.byteSize,
    sha256: row.sha256,
    reviewed: row.reviewed,
    auditId: row.auditId,
  };
}

export async function GET() {
  const rows = await db.select().from(medicalImages).orderBy(medicalImages.createdAt);
  return NextResponse.json({ images: rows.map(meta) });
}

export async function POST(req: Request) {
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "expected multipart/form-data" }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "no file in field 'file'" }, { status: 400 });
  }
  if (file.size === 0) return NextResponse.json({ error: "empty file" }, { status: 400 });
  if (file.size > MAX_BYTES)
    return NextResponse.json({ error: "file larger than 8 MB" }, { status: 413 });

  const mime = file.type || "application/octet-stream";
  const okType = mime.startsWith("image/") || mime === "application/pdf";
  if (!okType)
    return NextResponse.json({ error: "only images or PDF reports are accepted" }, { status: 415 });

  const buf = Buffer.from(await file.arrayBuffer());
  const kind = String(form.get("kind") ?? "other");
  const row = (
    await db
      .insert(medicalImages)
      .values({
        cardRef: String(form.get("cardRef") || "ANM-0000 / ——w·d").slice(0, 40),
        kind: (KINDS as readonly string[]).includes(kind) ? kind : "other",
        caption: String(form.get("caption") ?? "").slice(0, 240),
        fileName: file.name.slice(0, 120),
        mimeType: mime,
        byteSize: buf.length,
        sha256: createHash("sha256").update(buf).digest("hex"),
        auditId: form.get("auditId") ? String(form.get("auditId")) : null,
        bytes: buf,
      })
      .returning()
  )[0];

  return NextResponse.json({ image: meta(row) }, { status: 201 });
}

export async function PATCH(req: Request) {
  const body = await req.json().catch(() => ({}));
  const id = Number(body.id);
  if (!Number.isFinite(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const updated = await db
    .update(medicalImages)
    .set({ reviewed: body.reviewed === true })
    .where(eq(medicalImages.id, id))
    .returning();
  return NextResponse.json({ image: updated[0] ? meta(updated[0]) : null });
}
