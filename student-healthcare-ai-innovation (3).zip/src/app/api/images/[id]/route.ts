import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { medicalImages } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const id = Number((await params).id);
  if (!Number.isFinite(id)) return new NextResponse("bad id", { status: 400 });

  const rows = await db.select().from(medicalImages).where(eq(medicalImages.id, id)).limit(1);
  const row = rows[0];
  if (!row) return new NextResponse("not found", { status: 404 });

  return new NextResponse(new Uint8Array(row.bytes), {
    headers: {
      "content-type": row.mimeType,
      "content-length": String(row.byteSize),
      "cache-control": "private, max-age=3600",
      "x-content-type-options": "nosniff",
    },
  });
}
