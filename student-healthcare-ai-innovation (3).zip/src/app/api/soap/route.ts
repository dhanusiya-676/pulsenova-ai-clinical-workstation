import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { soapNotes } from "@/db/schema";
import { analyse, mapTerms } from "@/lib/codes";
import type { AnalysisInput, CardioInput } from "@/lib/codes";
import { buildFhirBundle } from "@/lib/fhir";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(soapNotes).orderBy(desc(soapNotes.createdAt));
  return NextResponse.json({ notes: rows });
}

export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  const sessionId = String(b.sessionId ?? "SN-DEMO");

  // terminology auto-mapping: run the same interpretation head over the session
  const input: AnalysisInput = {
    modality: (b.modality ?? "cardio") as AnalysisInput["modality"],
  };
  input.cardio = (b.cardio as CardioInput) ?? {
    age: 55,
    sex: "female",
    sbp: 130,
    totalChol: 200,
    hdl: 50,
    smoker: false,
    diabetes: false,
    bmi: 25,
  };
  if (b.voice) input.voice = b.voice;
  if (b.contentHash) input.contentHash = String(b.contentHash);
  const out = analyse(input);
  const noteText = [b.subjective, b.objective, b.assessment, b.plan].join(" ");
  const modelCodes = out.findings.slice(0, 4).flatMap((f) => f.codes);
  const merged = new Map<string, { system: string; code: string; display: string }>();
  for (const c of [...modelCodes, ...mapTerms(noteText)]) merged.set(c.system + c.code, c);
  const codes = [...merged.values()];

  const row = (
    await db
      .insert(soapNotes)
      .values({
        sessionId,
        cardRef: String(b.cardRef ?? "ANM-0000 / ——w·d").slice(0, 40),
        subjective: String(b.subjective ?? "").slice(0, 2000),
        objective: String(b.objective ?? "").slice(0, 2000),
        assessment: String(b.assessment ?? "").slice(0, 2000),
        plan: String(b.plan ?? "").slice(0, 2000),
        codes,
      })
      .returning()
  )[0];

  if (String(b.format ?? "") === "fhir") {
    const bundle = buildFhirBundle({
      runId: `SOAP${row.id}`,
      sessionId,
      patientRef: row.cardRef,
      modality: input.modality,
      performedAt: row.createdAt.toISOString(),
      findings: out.findings,
      guardrails: out.guardrails,
      device: out.model.version,
    });
    return NextResponse.json({ note: row, codes, bundle }, { status: 201 });
  }

  return NextResponse.json({ note: row, codes }, { status: 201 });
}
