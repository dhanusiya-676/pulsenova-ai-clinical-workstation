import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { peerReviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(peerReviews).orderBy(desc(peerReviews.createdAt));
  return NextResponse.json({ reviews: rows });
}

export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  if (!b.runId || !b.studentRead || !b.reviewer)
    return NextResponse.json({ error: "runId, studentRead and reviewer are required" }, { status: 400 });
  const dispositions = ["agree", "escalate", "disagree"];
  const row = (
    await db
      .insert(peerReviews)
      .values({
        runId: String(b.runId).slice(0, 24),
        caseTitle: String(b.caseTitle ?? "Untitled case").slice(0, 120),
        modality: String(b.modality ?? "cardio").slice(0, 12),
        aiRead: String(b.aiRead ?? "").slice(0, 400),
        studentRead: String(b.studentRead).slice(0, 800),
        disposition: dispositions.includes(b.disposition) ? b.disposition : "agree",
        reviewer: String(b.reviewer).slice(0, 60),
        facultyNote: String(b.facultyNote ?? "").slice(0, 400),
        status: "OPEN",
      })
      .returning()
  )[0];
  return NextResponse.json({ review: row }, { status: 201 });
}

export async function PATCH(req: Request) {
  const b = await req.json().catch(() => ({}));
  const id = Number(b.id);
  if (!Number.isFinite(id)) return NextResponse.json({ error: "bad id" }, { status: 400 });
  const patch: Partial<typeof peerReviews.$inferInsert> = {};
  if (b.status) patch.status = String(b.status) === "REVIEWED" ? "REVIEWED" : "OPEN";
  if (b.facultyNote !== undefined) patch.facultyNote = String(b.facultyNote).slice(0, 400);
  const row = (await db.update(peerReviews).set(patch).where(eq(peerReviews.id, id)).returning())[0];
  return NextResponse.json({ review: row ?? null });
}
