import { NextResponse } from "next/server";
import { db } from "@/db";
import { assessments, referrals } from "@/db/schema";
import { predict, MODEL_VERSION, type Inputs } from "@/lib/model";

export const dynamic = "force-dynamic";

const FACILITIES = ["CHC Bargaon", "SDH Kusunda", "District Hospital"];
const WORKERS = ["R. Oraon, ASHA", "S. Munda, ANM", "P. Kerketta, LHV"];

function auditCode() {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const pick = (n: number) =>
    Array.from({ length: n }, () => A[Math.floor(Math.random() * A.length)]).join("");
  return `EMB-${pick(6)}-${pick(4)}`;
}

function cardRef(i: Inputs) {
  const w = Math.floor(i.gestAge);
  const d = Math.round((i.gestAge - w) * 7);
  return `ANM-${1000 + ((i.age * 37 + i.sbp + i.gestAge * 11) % 8999) | 0} / ${w}w${d}d`;
}

const num = (v: unknown, lo: number, hi: number, dflt: number) => {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
};
const bool = (v: unknown) => v === true || v === "true" || v === 1;
const nullable = (v: unknown, lo: number, hi: number) => {
  if (v === null || v === undefined || v === "" || v === "null") return null;
  return num(v, lo, hi, 0);
};

export async function POST(req: Request) {
  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    /* fall through to defaults */
  }

  const input: Inputs = {
    gestAge: num(body.gestAge, 20, 42, 34),
    sbp: num(body.sbp, 70, 260, 120),
    dbp: num(body.dbp, 30, 180, 80),
    spo2: num(body.spo2, 70, 100, 98),
    platelets: nullable(body.platelets, 20, 600),
    creatinine: nullable(body.creatinine, 20, 400),
    ast: nullable(body.ast, 5, 500),
    headache: bool(body.headache),
    visual: bool(body.visual),
    chestPain: bool(body.chestPain),
    dyspnea: bool(body.dyspnea),
    epigastric: bool(body.epigastric),
    bleeding: bool(body.bleeding),
    reducedFetal: bool(body.reducedFetal),
    seizure: bool(body.seizure),
    proteinuria: (num(body.proteinuria, 0, 3, 0) as 0 | 1 | 2 | 3),
    age: num(body.age, 12, 55, 26),
    parity: num(body.parity, 0, 8, 1),
    rural: bool(body.rural),
  };

  const result = predict(input);
  const auditId = auditCode();

  await db.insert(assessments).values({
    auditId,
    risk: result.risk,
    band: result.band,
    overridden: result.overridden,
    dangerSigns: result.dangerSigns,
    labMode: result.labMode,
    featureVector: result.featureVector,
    modelVersion: MODEL_VERSION,
  });

  let referral: (typeof referrals.$inferSelect) | null = null;
  if (result.band !== "ROUTINE") {
    const facility =
      result.band === "EMERGENCY"
        ? "District Hospital"
        : input.rural
          ? FACILITIES[0]
          : FACILITIES[1];
    const eta =
      result.band === "EMERGENCY"
        ? 15 + Math.floor(Math.random() * 15)
        : result.band === "URGENT"
          ? 40 + Math.floor(Math.random() * 35)
          : 0;
    const inserted = await db
      .insert(referrals)
      .values({
        auditId,
        cardRef: cardRef(input),
        facility,
        band: result.band,
        risk: result.risk,
        etaMinutes: eta,
        status: body.consentToCall && body.phone ? "CALLED" : "QUEUED",
        openedBy: WORKERS[Math.floor(Math.random() * WORKERS.length)],
        contactName: body.contactName ? String(body.contactName).slice(0, 60) : null,
        phone: body.consentToCall && body.phone ? String(body.phone).replace(/[^\d+]/g, "").slice(0, 18) : null,
        consentToCall: body.consentToCall === true,
        callNote: body.callNote ? String(body.callNote).slice(0, 240) : null,
      })
      .returning();
    referral = inserted[0] ?? null;
  }

  return NextResponse.json({ auditId, result, referral });
}
