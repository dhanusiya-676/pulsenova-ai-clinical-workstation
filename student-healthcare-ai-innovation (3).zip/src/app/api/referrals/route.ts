import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { referrals } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(referrals).orderBy(referrals.createdAt);
  const order = { EMERGENCY: 0, URGENT: 1, WATCH: 2, ROUTINE: 3 } as Record<string, number>;
  rows.sort((a, b) => (order[a.band] ?? 9) - (order[b.band] ?? 9));
  return NextResponse.json({ referrals: rows });
}

export async function PATCH(req: Request) {
  const body = await req.json().catch(() => ({}));
  const id = Number(body.id);
  const status = String(body.status ?? "");
  if (!Number.isFinite(id) || !["QUEUED", "CALLED", "TRANSFERRED", "CLOSED"].includes(status)) {
    return NextResponse.json({ error: "bad request" }, { status: 400 });
  }
  const patch: Partial<typeof referrals.$inferInsert> = { status };
  if (body.callNote !== undefined) patch.callNote = String(body.callNote).slice(0, 240);
  if (body.contactName !== undefined) patch.contactName = String(body.contactName).slice(0, 60);
  if (body.phone !== undefined) patch.phone = String(body.phone).replace(/[^\d+]/g, "").slice(0, 18);
  if (body.consentToCall !== undefined) patch.consentToCall = body.consentToCall === true;
  const updated = await db.update(referrals).set(patch).where(eq(referrals.id, id)).returning();
  return NextResponse.json({ referral: updated[0] ?? null });
}
