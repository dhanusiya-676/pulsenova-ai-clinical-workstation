import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { prescriptionItems, prescriptions } from "@/db/schema";
import { FORMULARY, PLACE, type Slot } from "@/lib/meds";

export const dynamic = "force-dynamic";

export type RxItemInput = {
  drug: string;
  strength?: string;
  dose?: string;
  route?: string;
  slots?: string[];
  food?: string;
  place?: string;
  duration?: string;
  note?: string;
};

function rxCode() {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(
    d.getDate(),
  ).padStart(2, "0")}`;
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const tail = Array.from({ length: 4 }, () => A[Math.floor(Math.random() * A.length)]).join("");
  return `RX-${ymd}-${tail}`;
}

export async function GET() {
  const heads = await db.select().from(prescriptions).orderBy(desc(prescriptions.createdAt));
  const items = await db.select().from(prescriptionItems);
  const grouped = heads.map((h) => ({
    ...h,
    items: items.filter((i) => i.prescriptionId === h.id),
  }));
  return NextResponse.json({ prescriptions: grouped });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const rawItems: RxItemInput[] = Array.isArray(body.items) ? body.items : [];
  if (!rawItems.length)
    return NextResponse.json({ error: "at least one medicine is required" }, { status: 400 });
  if (!body.prescriber || !body.regNo)
    return NextResponse.json(
      { error: "a registered prescriber and registration number are required" },
      { status: 400 },
    );

  const normalised = rawItems.map((it) => {
    const known = FORMULARY.find((m) => m.id === it.drug || m.name === it.drug);
    const slots = (it.slots ?? known?.slots ?? ["morning"]) as Slot[];
    return {
      drug: known?.name ?? String(it.drug ?? "").slice(0, 80),
      strength: it.strength ?? known?.strength ?? "",
      dose: it.dose ?? known?.dose ?? "",
      route: it.route ?? known?.route ?? "Oral",
      slots: slots.map(String),
      food: it.food ?? known?.food ?? "After food",
      place: it.place ?? known?.place ?? PLACE.home,
      duration: it.duration ?? known?.duration ?? "as directed",
      note: it.note ?? known?.warn ?? "",
    };
  });

  const head = (
    await db
      .insert(prescriptions)
      .values({
        rxCode: rxCode(),
        cardRef: String(body.cardRef || "ANM-0000 / ——w·d").slice(0, 40),
        contactName: body.contactName ? String(body.contactName).slice(0, 60) : null,
        phone: body.phone ? String(body.phone).replace(/[^\d+]/g, "").slice(0, 18) : null,
        gestAge: body.gestAge ? Number(body.gestAge) : null,
        diagnosis: String(body.diagnosis || "Hypertensive disorder of pregnancy").slice(0, 160),
        prescriber: String(body.prescriber).slice(0, 80),
        regNo: String(body.regNo).slice(0, 40),
        facility: String(body.facility || "CHC Bargaon").slice(0, 80),
        reviewInDays: Number(body.reviewInDays) || 7,
        notes: String(body.notes ?? "").slice(0, 800),
      })
      .returning()
  )[0];

  await db.insert(prescriptionItems).values(
    normalised.map((i) => ({
      prescriptionId: head.id,
      drug: i.drug,
      strength: i.strength,
      dose: i.dose,
      route: i.route,
      slots: i.slots,
      food: i.food,
      place: i.place,
      duration: i.duration,
      note: i.note,
    })),
  );

  const items = await db
    .select()
    .from(prescriptionItems)
    .where(eq(prescriptionItems.prescriptionId, head.id));

  return NextResponse.json({ prescription: { ...head, items } }, { status: 201 });
}
