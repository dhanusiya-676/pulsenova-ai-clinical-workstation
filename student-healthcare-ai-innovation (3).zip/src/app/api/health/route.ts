import { NextResponse } from "next/server";
import { pool } from "@/db";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await pool.query("select 1");
    return NextResponse.json({
      ok: true,
      service: "ember-triage",
      model: "ember-lr/0.4.2",
      inference: "on-device",
      phiEgress: false,
    });
  } catch {
    return NextResponse.json({ ok: false }, { status: 503 });
  }
}
