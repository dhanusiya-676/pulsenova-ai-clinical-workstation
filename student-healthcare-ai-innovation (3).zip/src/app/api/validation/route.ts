import { NextResponse } from "next/server";
import { db } from "@/db";
import { cohortPatients, type CohortPatient } from "@/db/schema";
import { BASELINES, type SimRow } from "@/lib/cohort";
import { predict, OPERATING_THRESHOLD, type Inputs } from "@/lib/model";
import {
  auc,
  bootstrapCI,
  calibrationBins,
  calibrationFit,
  confusion,
  rocPoints,
  thresholdAtSensitivity,
} from "@/lib/stats";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

function toInput(p: CohortPatient): Inputs {
  return {
    gestAge: p.gestAge,
    sbp: p.sbp,
    dbp: p.dbp,
    spo2: p.spo2,
    platelets: p.platelets,
    creatinine: p.creatinine,
    ast: p.ast,
    headache: p.headache,
    visual: p.visual,
    chestPain: p.chestPain,
    dyspnea: p.dyspnea,
    epigastric: p.epigastric,
    bleeding: p.bleeding,
    reducedFetal: p.reducedFetal,
    seizure: p.seizure,
    proteinuria: p.proteinuria as 0 | 1 | 2 | 3,
    age: p.age,
    parity: p.parity,
    rural: p.rural,
  };
}

export async function GET() {
  await ensureSeeded();
  const all = await db.select().from(cohortPatients);
  const dev = all.filter((r) => r.split === "dev");
  const test = all.filter((r) => r.split === "test");

  const score = (p: CohortPatient) => predict(toInput(p)).risk;
  const rows = (list: CohortPatient[], s: (p: CohortPatient) => number) =>
    list.map((p) => ({ score: s(p), y: p.outcome }));

  const devRows = rows(dev, score);
  const testRows = rows(test, score);

  // Operating point chosen on the development split, frozen and applied to test.
  const threshold = thresholdAtSensitivity(devRows, 0.95);
  void OPERATING_THRESHOLD;
  const c = confusion(testRows, threshold);

  const modelAuc = auc(testRows);
  const ci = bootstrapCI(testRows, auc, 400, 11);

  const baselines = BASELINES.map((b) => {
    const s = (p: CohortPatient) => b.score(toInput(p)) as number;
    const r = rows(test, s);
    const cm = confusion(r, 0.5);
    return {
      key: b.key,
      label: b.label,
      citation: b.citation,
      auc: auc(r),
      aucCI: bootstrapCI(r, auc, 200, 23),
      ...cm,
    };
  });

  const cal = calibrationBins(testRows, 10);
  const calFit = calibrationFit(testRows);

  const strataOf = (p: CohortPatient): Record<string, boolean> => ({
    rural: p.rural,
    adolescent: p.age < 20,
    nulliparous: p.parity === 0,
    labFree: !p.labAvailable,
  });

  const groups: { key: string; label: string }[] = [
    { key: "rural", label: "Rural residence" },
    { key: "adolescent", label: "Adolescent (<20 y)" },
    { key: "nulliparous", label: "Nulliparous" },
    { key: "labFree", label: "Lab-free handset mode" },
  ];

  const subgroup = groups.map((g) => {
    const inG = test.filter((p) => strataOf(p)[g.key]);
    const outG = test.filter((p) => !strataOf(p)[g.key]);
    const rg = rows(inG, score);
    const ro = rows(outG, score);
    const tprG = confusion(rg, threshold).sens;
    const tprO = confusion(ro, threshold).sens;
    return {
      label: g.label,
      n: inG.length,
      positives: inG.filter((p) => p.outcome).length,
      auc: auc(rg),
      aucCI: bootstrapCI(rg, auc, 200, 31),
      tpr: tprG,
      tprComparator: tprO,
      tprGap: tprG - tprO,
    };
  });

  // Lab-free handicap: mask labs the way a field handset would, then re-score.
  const labFreeRows = test.map((p) => ({
    score: predict({ ...toInput(p), platelets: null, creatinine: null, ast: null }).risk,
    y: p.outcome,
  }));

  return NextResponse.json({
    generatedAt: new Date().toISOString(),
    cohort: {
      total: all.length,
      dev: dev.length,
      test: test.length,
      positives: test.filter((p) => p.outcome).length,
      prevalence: test.filter((p) => p.outcome).length / test.length,
    },
    model: {
      key: "ember",
      label: "EMBER logistic risk model",
      auc: modelAuc,
      aucCI: ci,
      threshold,
      ...c,
    },
    labFree: { auc: auc(labFreeRows), ...confusion(labFreeRows, threshold) },
    baselines,
    calibration: cal,
    calibrationFit: calFit,
    roc: rocPoints(testRows, 90),
    subgroup,
  });
}

export type ValidationPayload = {
  cohort: { total: number; dev: number; test: number; positives: number; prevalence: number };
  model: ReturnType<typeof confusion> & {
    label: string;
    auc: number;
    aucCI: [number, number];
    threshold: number;
  };
  labFree: ReturnType<typeof confusion> & { auc: number };
  baselines: (ReturnType<typeof confusion> & {
    key: string;
    label: string;
    citation: string;
    auc: number;
    aucCI: [number, number];
  })[];
  calibration: { lo: number; hi: number; pred: number; obs: number; n: number }[];
  calibrationFit: { intercept: number; slope: number };
  roc: { fpr: number; tpr: number; threshold: number }[];
  subgroup: {
    label: string;
    n: number;
    positives: number;
    auc: number;
    aucCI: [number, number];
    tpr: number;
    tprComparator: number;
    tprGap: number;
  }[];
};

export type { SimRow };
