import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses } from "@/db/schema";
import { analyse, MODEL_REGISTRY } from "@/lib/codes";
import type { AnalysisInput, CardioInput, VoiceFeatures } from "@/lib/codes";
import { buildFhirBundle } from "@/lib/fhir";

export const dynamic = "force-dynamic";

/** POST: build an HL7 FHIR v4.0.1 bundle for a stored run (or for a raw payload). */
export async function POST(req: Request) {
  const b = await req.json().catch(() => ({}));
  const sessionId = String(b.sessionId ?? "SN-DEMO");
  const patientRef = String(b.patientRef ?? "ANM-0000 / ——w·d").slice(0, 40);
  const modality = (b.modality ?? "cardio") as AnalysisInput["modality"];
  if (!MODEL_REGISTRY[modality])
    return NextResponse.json({ error: "unknown modality" }, { status: 400 });

  let runId = String(b.runId ?? "");
  let performedAt = new Date().toISOString();
  let findings: ReturnType<typeof analyse>["findings"] = [];
  let guardrails: ReturnType<typeof analyse>["guardrails"] = [];

  if (runId) {
    const rows = await db.select().from(analyses).where(eq(analyses.runId, runId));
    const row = rows[0];
    if (!row) return NextResponse.json({ error: "run not found" }, { status: 404 });
    performedAt = row.createdAt.toISOString();
    const input: AnalysisInput = { modality: row.modality as AnalysisInput["modality"] };
    if (row.inputRef?.startsWith("acoustic/")) input.voice = row.featureVector as unknown as VoiceFeatures;
    if (row.modality === "cardio") input.cardio = row.featureVector as unknown as CardioInput;
    if (row.inputRef?.startsWith("imaging/")) input.contentHash = row.inputRef;
    const out = analyse(input);
    findings = out.findings;
    guardrails = row.guardrails as unknown as ReturnType<typeof analyse>["guardrails"];
  } else {
    runId = `ONESHOT-${Date.now().toString(36).toUpperCase()}`;
    const input: AnalysisInput = { modality };
    if (b.cardio) input.cardio = b.cardio as CardioInput;
    if (b.voice) input.voice = b.voice as VoiceFeatures;
    if (b.seed) input.contentHash = String(b.seed);
    const out = analyse(input);
    findings = out.findings;
    guardrails = out.guardrails;
  }

  const bundle = buildFhirBundle({
    runId,
    sessionId,
    patientRef,
    modality,
    performedAt,
    findings,
    guardrails,
    device: MODEL_REGISTRY[modality].version,
  });

  return NextResponse.json(bundle);
}
